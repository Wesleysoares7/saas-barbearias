﻿# Contexto Unificado do Projeto

Gerado em: 2026-08-06 09:51:19 -03:00
Raiz: E:\meusProjetos\app's\saas-barbearias
Modo: lite
Arquivos incluidos: 99
Observacao: arquivos .env* e binarios foram excluidos por seguranca.

## Estrutura (arquivos incluidos)

- AGENTS.md
- CLAUDE.md
- components.json
- docs/changelog.md
- docs/database.md
- docs/database/001_etapa3_schema_rls.sql
- docs/database/002_etapa6_conflito_agendamentos.sql
- docs/database/003_etapa11_convites_auditoria.sql
- docs/database/004_etapa12_notificacoes.sql
- docs/database/005_etapa13_clientes.sql
- docs/database/006_etapa13_agendamentos_clientes.sql
- docs/database/009_etapa16_master_plataforma.sql
- docs/database/etapa3_como_executar.md
- docs/database/etapa6_testes_basicos.md
- docs/database/README.md
- docs/manual-de-uso.md
- docs/prompts/README.md
- docs/roadmap.md
- docs/rules.md
- eslint.config.mjs
- middleware.ts
- next.config.ts
- package.json
- postcss.config.mjs
- README.md
- src/app/api/reports/appointments/pdf/route.ts
- src/app/api/reports/appointments/route.ts
- src/app/api/reports/auditoria/pdf/route.ts
- src/app/api/reports/auditoria/route.ts
- src/app/api/reports/payments/pdf/route.ts
- src/app/api/reports/payments/route.ts
- src/app/api/test-supabase/route.ts
- src/app/auth/atualizar-senha/page.tsx
- src/app/auth/confirm/route.ts
- src/app/convites/[token]/actions.ts
- src/app/convites/[token]/page.tsx
- src/app/globals.css
- src/app/layout.tsx
- src/app/login/page.tsx
- src/app/master/actions.ts
- src/app/master/empresas/page.tsx
- src/app/master/page.tsx
- src/app/master/relatorios/page.tsx
- src/app/onboarding/actions.ts
- src/app/onboarding/page.tsx
- src/app/page.tsx
- src/app/painel/actions.ts
- src/app/painel/agendamentos/actions.ts
- src/app/painel/agendamentos/page.tsx
- src/app/painel/auditoria/page.tsx
- src/app/painel/clientes/[id]/page.tsx
- src/app/painel/clientes/actions.ts
- src/app/painel/clientes/page.tsx
- src/app/painel/equipe/actions.ts
- src/app/painel/equipe/page.tsx
- src/app/painel/financeiro/actions.ts
- src/app/painel/financeiro/page.tsx
- src/app/painel/funcionarios/actions.ts
- src/app/painel/funcionarios/page.tsx
- src/app/painel/layout.tsx
- src/app/painel/notificacoes/actions.ts
- src/app/painel/notificacoes/page.tsx
- src/app/painel/page.tsx
- src/app/painel/relatorios/page.tsx
- src/app/painel/servicos/actions.ts
- src/app/painel/servicos/page.tsx
- src/components/auth/login-form.tsx
- src/components/invites/accept-team-invite-form.tsx
- src/components/onboarding/onboarding-form.tsx
- src/components/painel/agendamentos/appointment-item-form.tsx
- src/components/painel/agendamentos/create-appointment-form.tsx
- src/components/painel/clientes/create-customer-form.tsx
- src/components/painel/clientes/customer-item-form.tsx
- src/components/painel/equipe/create-team-invite-form.tsx
- src/components/painel/equipe/team-invite-item.tsx
- src/components/painel/equipe/team-member-role-form.tsx
- src/components/painel/financeiro/create-payment-form.tsx
- src/components/painel/financeiro/payment-item-form.tsx
- src/components/painel/funcionarios/create-employee-form.tsx
- src/components/painel/funcionarios/employee-item-form.tsx
- src/components/painel/mobile-sidebar-menu.tsx
- src/components/painel/servicos/create-service-form.tsx
- src/components/painel/servicos/service-item-form.tsx
- src/components/painel/sidebar-nav.tsx
- src/components/ui/button.tsx
- src/lib/appointments/conflict.ts
- src/lib/auth/access.ts
- src/lib/notifications/sensitive-events.ts
- src/lib/reports/pdf.ts
- src/lib/supabase/admin.ts
- src/lib/supabase/client.ts
- src/lib/supabase/env.ts
- src/lib/supabase/middleware.ts
- src/lib/supabase/server.ts
- src/lib/utils.ts
- src/types/appointments.ts
- src/types/customers.ts
- src/types/index.ts
- tsconfig.json

## Conteudo dos arquivos

### Arquivo: AGENTS.md
```
<!-- BEGIN:nextjs-agent-rules -->
# This is NOT the Next.js you know

This version has breaking changes — APIs, conventions, and file structure may all differ from your training data. Read the relevant guide in `node_modules/next/dist/docs/` before writing any code. Heed deprecation notices.
<!-- END:nextjs-agent-rules -->

```

### Arquivo: CLAUDE.md
```
@AGENTS.md

```

### Arquivo: components.json
```
{
  "$schema": "https://ui.shadcn.com/schema.json",
  "style": "radix-nova",
  "rsc": true,
  "tsx": true,
  "tailwind": {
    "config": "",
    "css": "src/app/globals.css",
    "baseColor": "neutral",
    "cssVariables": true,
    "prefix": ""
  },
  "iconLibrary": "lucide",
  "rtl": false,
  "aliases": {
    "components": "@/components",
    "utils": "@/lib/utils",
    "ui": "@/components/ui",
    "lib": "@/lib",
    "hooks": "@/hooks"
  },
  "menuColor": "default",
  "menuAccent": "subtle",
  "registries": {}
}

```

### Arquivo: docs/changelog.md
```
# Changelog

## 2026-08-06 - Etapa 17: Permissoes totais na area master
### Adicionado
- Client administrativo `src/lib/supabase/admin.ts` usando `SUPABASE_SERVICE_ROLE_KEY` para operacoes globais controladas da plataforma.
- Server actions em `src/app/master/actions.ts` para incluir, alterar e excluir empresas na area master.
- Pagina `src/app/master/relatorios/page.tsx` com consolidado de faturamento, comissao e agendamentos por empresa.
- Filtro por empresa na tela `src/app/master/relatorios/page.tsx` para analisar uma empresa especifica sem perder o consolidado global quando desejar limpar o filtro.
- Filtro evoluido para busca digitavel por nome da empresa com sugestoes e correspondencia parcial.

### Alterado
- Tela `src/app/master/empresas/page.tsx` evoluida para administracao completa de empresas (CRUD).
- Redirecionamento de login refinado para enviar usuario master para `/master/empresas` quando aplicavel.
- Manual atualizado para incluir menus e permissoes da area master.

## 2026-08-05 - Etapa 16: Acesso master de plataforma
### Adicionado
- Script `docs/database/009_etapa16_master_plataforma.sql` com tabela `platform_admins`, funcao `is_platform_admin()` e policy para leitura global de `companies` por usuario master.
- Nova area master em `/master/empresas` para listar todas as empresas cadastradas na plataforma.

### Alterado
- Regras de acesso atualizadas para redirecionar usuario master para a area global quando nao houver `company_id`.
- Middleware atualizado para proteger rotas `/master/*` e redirecionar login para a area master quando aplicavel.
- Onboarding ajustado para nao bloquear usuario master em fluxo de empresa.
- Redirecionamento do formulario de login ajustado para enviar usuario master a `/master/empresas` quando nao houver parametro `next`.
- Documentacao de banco e manual de uso atualizados com o novo perfil master.

## 2026-08-05 - Ajuste de redirect de autenticacao em producao
### Alterado
- Cadastro passou a enviar `emailRedirectTo` com base em `NEXT_PUBLIC_APP_URL`, evitando links para localhost em ambiente publicado.
- Fluxo de confirmacao de cadastro direcionado para `/auth/confirm`, que processa o `code` e redireciona para `/login` com status de confirmacao.
- Recuperacao de senha passou a usar URL publica configuravel para `redirectTo`.
- Fallback de URL publica definido para `https://saas-barbearias.vercel.app` quando `NEXT_PUBLIC_APP_URL` nao estiver configurada.
- Manual atualizado com passos de configuracao da Vercel e URL Configuration no Supabase Auth.

## 2026-08-04 - Nome generico para multiplos negocios
### Alterado
- Titulo principal da aplicacao atualizado para `SaaS Agenda de Servicos`.
- Textos de apoio do login ajustados para contexto generico de negocio.
- Cabecalho do painel atualizado para refletir o novo nome.
- Manual de uso atualizado para posicionar a plataforma para negocios de servicos em geral.

## 2026-08-04 - Manual de uso da aplicacao
### Adicionado
- Documento `docs/manual-de-uso.md` com guia completo de configuracao, primeiro acesso, operacao por modulo, permissoes e resolucao de erros comuns.

### Alterado
- `README.md` atualizado com link para o manual de uso.

## 2026-08-04 - Organizacao de tipos compartilhados
### Adicionado
- Pasta `src/types` com arquivos `appointments.ts`, `customers.ts` e `index.ts` para centralizar tipos reutilizados.

### Alterado
- Tipos duplicados movidos das paginas `painel`, `agendamentos`, `clientes` e `clientes/[id]` para imports compartilhados.

## 2026-08-04 - Estrutura com menu lateral vertical no painel
### Adicionado
- Layout compartilhado do painel em `src/app/painel/layout.tsx` com menu lateral vertical para desktop e menu horizontal para mobile.
- Componente de navegacao com destaque de rota ativa em `src/components/painel/sidebar-nav.tsx`.
- Menu mobile retratil (abrir/fechar) no topo do painel com acesso aos modulos e acao de sair da conta.

### Alterado
- Home do painel em `src/app/painel/page.tsx` ajustada para exibir o dashboard dentro da nova area de conteudo do layout.
- Modulos `agendamentos`, `funcionarios`, `servicos`, `clientes`, `clientes/[id]`, `financeiro`, `equipe`, `auditoria`, `notificacoes` e `relatorios` ajustados para usar apenas conteudo interno no novo shell lateral.
- Remocao dos botoes `Voltar ao painel` nas telas de modulos, reduzindo redundancia de navegacao.
- Sidebar refinada com icones e agrupamento por secoes para leitura mais rapida da navegacao.
- No mobile, o menu retratil agora fecha automaticamente ao selecionar um item.
- Menu mobile ganhou animacao suave de abrir/fechar e indicador visual da tela ativa no titulo do retratil.

### Observacoes
- A navegacao por modulos agora fica centralizada no layout do painel, exibindo cada tela no conteudo ao lado do menu.

## 2026-08-04 - Atualizacao visual moderna e vibrante
### Alterado
- Tema global atualizado em `src/app/globals.css` com nova paleta vibrante, contrastes mais fortes e fundo atmosférico com gradientes.
- Botao base atualizado em `src/components/ui/button.tsx` com visual mais moderno, bordas mais suaves, sombras e destaque de hover.

### Validado
- `npm run lint` sem erros.
- `npm run build` concluido com sucesso.

## 2026-08-04 - Correcao dos checks de CI
### Alterado
- Pagina de atualizacao de senha ajustada para nao ler variaveis do Supabase durante o prerender do build.
- `next` e `eslint-config-next` atualizados para `16.3.0` para corrigir vulnerabilidades reportadas pelo `npm audit`.
- Workflows do GitHub Actions atualizados para Node.js 22 em `.github/workflows/ci.yml` e `.github/workflows/security.yml`.

### Validado
- `npm audit --audit-level=high` sem vulnerabilidades.
- `npm run lint` sem erros.
- `npm run build` validado sem `.env.local`, reproduzindo o ambiente do GitHub Actions.

## 2026-08-04 - Teste de protecao de branch
### Observacoes
- Branch temporaria criada para validar Pull Request, GitHub Actions e protecao da `main`.

## 2026-08-04 - Rotina de seguranca no GitHub
### Adicionado
- Workflow de qualidade em `.github/workflows/ci.yml` para lint e build em Pull Request para `main`.
- Workflow de seguranca em `.github/workflows/security.yml` com `npm audit` para vulnerabilidades altas e criticas.
- Workflow de analise estatica em `.github/workflows/codeql.yml` para verificacoes de seguranca no codigo.
- Configuracao do Dependabot em `.github/dependabot.yml` para atualizar dependencias de `npm` e GitHub Actions.
- Arquivo `.github/CODEOWNERS` com dono do codigo para exigencia de revisao.

### Objetivo
- Impedir merge direto em `main` sem aprovacao e sem passar nas verificacoes automatizadas de qualidade e seguranca.

## 2026-08-04 - Visao financeira por funcionario
### Adicionado
- Resumo de faturamento total e comissao total na tela financeira.
- Listagem de faturamento por funcionario com base nos pagamentos concluidos.
- Exibicao do valor faturado, total de comissao e quantidade de pagamentos por funcionario.

### Alterado
- Tela `Financeiro` agora mostra a visao consolidada antes da lista de pagamentos.

## 2026-07-04 - Etapa 1
### Adicionado
- Projeto Next.js com App Router, TypeScript e TailwindCSS.
- shadcn/ui inicializado com preset Nova.
- Dependencias do Supabase instaladas (`@supabase/supabase-js` e `@supabase/ssr`).
- Estrutura obrigatoria de pastas: `docs`, `docs/prompts`, `docs/database`, `src`.
- Tela inicial de login em `/login` com validacao, loading e tratamento de erro.
- Clientes Supabase para browser e server em `src/lib/supabase`.
- Rota de teste em `/api/test-supabase` para validar conexao com Auth e PostgREST.
- Arquivo `.env.example` com variaveis obrigatorias.
- Documentacao inicial: `roadmap.md`, `rules.md`, `database.md` e `changelog.md`.

### Alterado
- Rota raiz `/` agora redireciona para `/login`.
- Metadados da aplicacao atualizados para o contexto SaaS de agendamentos de servicos.
- Rota `/api/test-supabase` ajustada para evitar falso negativo quando o endpoint raiz do PostgREST retorna 404.

### Observacoes
- Esquema SQL e politicas RLS ainda nao foram implementados nesta etapa.

## 2026-07-04 - Etapa 2
### Adicionado
- Fluxo real de autenticacao no formulario com modos de login, cadastro e recuperacao.
- Pagina de atualizacao de senha em `/auth/atualizar-senha`.
- Rota protegida de validacao em `/painel`.
- Middleware de autenticacao para proteger rotas e redirecionar usuarios.

### Alterado
- Formulario de login conectado ao Supabase Auth com mensagens de erro e sucesso em portugues.
- Login agora respeita parametro de retorno (`next`) ao acessar rotas protegidas.

### Observacoes
- Confirmacao de e-mail depende da configuracao do projeto Supabase Auth.

## 2026-07-04 - Ajuste local de ambiente
### Alterado
- Tela de login nao quebra mais quando variaveis de ambiente do Supabase estao ausentes; o erro agora aparece de forma tratada ao tentar autenticar.
- Middleware de autenticacao ganhou fallback para nao derrubar a aplicacao inteira em ambiente local sem `.env.local` configurado.
- Correcao da `NEXT_PUBLIC_SUPABASE_URL` para usar apenas o dominio base do projeto (sem `/rest/v1`), restaurando login e cadastro.
- Validacao no `getSupabaseEnv` para impedir URL com sufixos incorretos (`/rest/v1` e `/auth/v1`).
- Leitura das variaveis `NEXT_PUBLIC_*` alterada para acesso estatico em `process.env`, corrigindo indisponibilidade no client-side do Next.js.

### Adicionado
- Criacao orientada do arquivo `.env.local` a partir do `.env.example`.

## 2026-07-04 - Etapa 3
### Adicionado
- Script SQL inicial da modelagem multi-tenant com tabelas obrigatorias em `docs/database/001_etapa3_schema_rls.sql`.
- Guia de execucao da etapa em `docs/database/etapa3_como_executar.md`.
- Funcao `current_company_id()` para suportar filtros de tenant nas policies.
- Politicas RLS para isolamento por empresa em `companies`, `profiles`, `employees`, `services`, `appointments` e `payments`.

### Alterado
- Documentacao de banco atualizada para refletir o status da Etapa 3.
- Roadmap atualizado com Etapa 3 concluida e proxima etapa proposta.

### Observacoes
- O SQL desta etapa foi preparado e documentado; a aplicacao no banco deve ser feita no Supabase SQL Editor.
- Ajuste aplicado no script: funcao `current_company_id()` movida para depois da criacao da tabela `profiles` para evitar erro `relation does not exist`.

## 2026-07-04 - Etapa 4
### Adicionado
- Rota de onboarding em `/onboarding` para bootstrap do primeiro acesso.
- Action server-side para criar empresa inicial e perfil admin vinculado ao usuario autenticado.
- Formulario de onboarding com validacao e estado de carregamento.

### Alterado
- Rota `/painel` agora redireciona para `/onboarding` quando o usuario ainda nao possui empresa/perfil.
- Middleware atualizado para tratar `/onboarding` como rota protegida.

### Observacoes
- O bootstrap depende do script SQL da Etapa 3 ja aplicado no Supabase (tabelas e policies).

## 2026-07-04 - Correcao onboarding
### Alterado
- Ajuste no arquivo `src/app/onboarding/actions.ts` para obedecer a regra do Next.js em `use server` (somente funcoes async podem ser exportadas em runtime).
- Estado inicial do formulario de onboarding movido para `src/components/onboarding/onboarding-form.tsx`.
- Bootstrap da empresa ajustado para inserir `companies` sem `select` de retorno, evitando conflito com RLS no primeiro cadastro.

### Observacoes
- Erro corrigido: `A "use server" file can only export async functions, found object.` ao finalizar cadastro da empresa.

## 2026-07-04 - Etapa 5
### Adicionado
- CRUD de funcionarios em `/painel/funcionarios` com create, update e delete.
- CRUD de servicos em `/painel/servicos` com create, update e delete.
- Componentes de formulario com loading state e feedback de sucesso/erro.

### Alterado
- Painel principal ganhou links para os modulos de funcionarios e servicos.

### Observacoes
- Todas as operacoes usam sessao autenticada e `company_id` para manter isolamento multi-tenant com RLS.

## 2026-07-04 - Melhoria UX servicos
### Alterado
- Feedback de criacao/erro de servicos trocado de mensagem fixa para notificacao temporaria no topo da tela.
- Formulario de novo servico agora limpa automaticamente os campos apos criacao com sucesso.

## 2026-07-04 - Melhoria UX funcionarios
### Alterado
- Feedback de criacao/erro de funcionarios trocado de mensagem fixa para notificacao no topo da tela, seguindo o mesmo padrao visual do modulo de servicos.

## 2026-07-04 - Padronizacao de feedback em lista
### Alterado
- Formularios de edicao e exclusao dos itens em funcionarios e servicos agora usam notificacao no topo do card, removendo mensagens fixas ao lado dos botoes.

## 2026-07-04 - Etapa 6
### Adicionado
- CRUD de agendamentos em `/painel/agendamentos` com create, update e delete.
- Vinculacao obrigatoria de agendamento com funcionario e servico da mesma empresa.
- Validacoes de status, data/hora e referencias de funcionario/servico.
- Componentes de formulario com loading state e notificacoes de feedback.

### Alterado
- Painel principal recebeu acesso ao modulo de agendamentos.

### Observacoes
- O modulo de agendamentos depende de funcionarios e servicos ativos para novos cadastros.

## 2026-07-04 - Correcao critica de conflito em agendamentos
### Adicionado
- Script `docs/database/002_etapa6_conflito_agendamentos.sql` com campo `data_hora_fim`, indices e constraint de sobreposicao.
- Documento `docs/database/etapa6_testes_basicos.md` com cenarios de validacao.

### Alterado
- Backend de agendamentos agora calcula `data_hora_fim` automaticamente com base na duracao do servico.
- Backend bloqueia conflitos para o mesmo funcionario quando status for `agendado`.
- Frontend de criacao e edicao de agendamento ganhou validacao previa de conflito para feedback imediato.

### Regras de conflito aplicadas
- Conflito quando: `novo_inicio < existente_fim` e `novo_fim > existente_inicio`.
- Agendamentos `cancelado` nao entram no bloqueio de conflito.

## 2026-07-04 - Correcao de inicializacao
### Alterado
- Ajuste em `src/lib/supabase/server.ts` para evitar tentativa invalida de escrita de cookies em Server Components no Next.js.

### Observacoes
- Erro corrigido: `Cookies can only be modified in a Server Action or Route Handler`.

## 2026-07-04 - Etapa 7
### Adicionado
- CRUD de pagamentos em `/painel/financeiro` com create, update e delete.
- Formulario de criacao com selecao de agendamentos concluidos sem pagamento.
- Validacoes de seguranca no backend para bloquear pagamento fora da empresa, agendamento nao concluido e duplicidade por agendamento.
- Calculo automatico de `valor_comissao` com base em `valor` e `percentual_comissao`.

### Alterado
- Painel principal recebeu acesso ao modulo de financeiro.
- Feedback de sucesso/erro no modulo financeiro segue o padrao de notificacao temporaria usado nos outros modulos.

### Observacoes
- O modulo de financeiro reutiliza o isolamento multi-tenant por `company_id` com RLS.

## 2026-07-04 - Etapa 8
### Adicionado
- Dashboard inicial em `/painel` com bloco de Agenda do dia.
- Contadores visuais de agendamentos do dia por status (agendado, concluido, cancelado).
- Lista dos proximos atendimentos pendentes do dia no topo do painel.
- Indicador de faturamento do dia com base em pagamentos registrados no dia.
- Ranking de servicos mais vendidos no mes atual com base em agendamentos concluidos.

### Alterado
- Layout do painel evoluido de tela de validacao para visao de acompanhamento operacional.

### Observacoes
- Etapa 8 concluida com dashboard operacional inicial no painel principal.

## 2026-07-04 - Etapa 9
### Adicionado
- Modulo de relatorios em `/painel/relatorios` com filtro de periodo.
- Endpoint `/api/reports/appointments` para exportacao CSV de agendamentos.
- Endpoint `/api/reports/payments` para exportacao CSV de financeiro.
- Endpoint `/api/reports/appointments/pdf` para exportacao PDF de agendamentos.
- Endpoint `/api/reports/payments/pdf` para exportacao PDF de financeiro.
- Utilitario `src/lib/reports/pdf.ts` para geracao padronizada de PDFs.
- Links de exportacao no painel principal para acesso rapido ao modulo.

### Regras aplicadas
- Exportacao protegida por autenticacao e escopo de empresa (`company_id`).
- CSV gerado com colunas de referencia (cliente, servico, funcionario e comissao).
- PDF gerado no backend com periodo e total de registros, preservando escopo por empresa.

### Observacoes
- Etapa 9 concluida com exportacao em CSV e PDF para agendamentos e financeiro.

## 2026-07-04 - Etapa 10
### Adicionado
- Utilitario de acesso em `src/lib/auth/access.ts` para resolver papel do usuario e permissoes por modulo.
- Exibicao do papel atual no painel (`Administrador` ou `Equipe`).
- Modulo `/painel/equipe` para gestao de papeis dos membros da empresa.
- Action de troca de papel com regra de seguranca para manter ao menos um admin.

### Alterado
- Modulos `funcionarios`, `servicos` e `financeiro` agora exigem papel `admin` na renderizacao das paginas.
- Server actions desses modulos agora validam permissao de admin antes de criar/editar/excluir.
- Painel principal oculta links de modulos restritos para usuarios de equipe.
- Agendamentos agora usam permissao granular: equipe pode criar/editar, mas nao pode excluir.

### Observacoes
- Etapa 10 concluida com controle de acesso por papel, regra granular por operacao e gestao de papeis da equipe.

## 2026-07-04 - Etapa 11
### Adicionado
- Convites por e-mail no modulo de equipe (criar, listar e revogar) para administradores.
- Script `docs/database/003_etapa11_convites_auditoria.sql` com tabelas `team_invites` e `audit_logs`.
- Registro de eventos sensiveis da equipe em `audit_logs` (melhor esforco, sem bloquear fluxo principal).
- Fluxo de aceite de convite por token em `/convites/[token]`.
- Tela de auditoria em `/painel/auditoria` para administradores.
- Policies de convite ajustadas para permitir leitura/aceite pelo e-mail convidado autenticado.

### Alterado
- Pagina de equipe evoluiu para "Equipe, convites e papeis" com secao dedicada de convites.
- Acoes de agendamento agora seguem permissao granular por operacao (`create`, `update`, `delete`).
- Painel principal recebeu atalho para trilhas de auditoria (admin).

### Observacoes
- Se voce ja executou uma versao anterior do SQL da Etapa 11, reexecute `003_etapa11_convites_auditoria.sql` para aplicar as policies novas de aceite por token.
- Etapa 11 concluida com convites por token e trilha de auditoria no painel.

## 2026-07-04 - Etapa 12
### Adicionado
- Filtros avancados na tela de auditoria por periodo, acao, entidade e busca textual.
- Contador de resultados filtrados e acao de limpar filtros.
- Endpoint `/api/reports/auditoria` para exportacao CSV da auditoria com filtros.
- Endpoint `/api/reports/auditoria/pdf` para exportacao PDF da auditoria com filtros.
- Botoes de exportacao CSV/PDF na pagina de auditoria reaproveitando os filtros ativos.
- Script `docs/database/004_etapa12_notificacoes.sql` com tabela `security_notifications` e policies RLS.
- Automacao de notificacao para eventos sensiveis de equipe/convites.
- Caixa de notificacoes em `/painel/notificacoes` com filtro de nao lidas.
- Acoes para marcar notificacao individual ou todas como lidas.
- Atalho no dashboard para notificacoes sensiveis.

### Alterado
- Consulta da auditoria passou a respeitar filtros server-side para periodo, acao e entidade.
- Fluxos de equipe e aceite de convite agora disparam notificacoes para administradores, sem bloquear fluxo principal.

### Observacoes
- Etapa 12 concluida com filtros/exportacao de auditoria e automacoes de notificacao para eventos sensiveis.

## 2026-07-04 - Etapa 13 (inicio)
### Adicionado
- Script `docs/database/005_etapa13_clientes.sql` com tabela `customers`, indices e policies RLS.
- Modulo `/painel/clientes` com CRUD inicial (criar, listar, editar e excluir clientes).
- Componentes de formulario para cadastro e manutencao de clientes.
- Atalho no dashboard para gerenciamento de clientes.
- Script `docs/database/006_etapa13_agendamentos_clientes.sql` para vincular agendamentos a clientes por `customer_id`.
- Selecao de cliente cadastrado no create/update de agendamentos (vinculo opcional).
- Tela de historico por cliente em `/painel/clientes/[id]` com linha do tempo de atendimentos e pagamentos.
- Atalho "Ver historico" em cada item do modulo de clientes.

### Observacoes
- Etapa 13 concluida com cadastro de clientes, integracao a agendamentos e historico de atendimentos por cliente.

```

### Arquivo: docs/database.md
```
# Database

## Objetivo
Banco PostgreSQL no Supabase com arquitetura multi-tenant por empresa.

## Tabelas implementadas na Etapa 3
- companies
- profiles
- employees
- services
- appointments
- payments

## Arquivos SQL e guia
- `docs/database/001_etapa3_schema_rls.sql`
- `docs/database/etapa3_como_executar.md`
- `docs/database/002_etapa6_conflito_agendamentos.sql`
- `docs/database/etapa6_testes_basicos.md`
- `docs/database/003_etapa11_convites_auditoria.sql`
- `docs/database/004_etapa12_notificacoes.sql`
- `docs/database/005_etapa13_clientes.sql`
- `docs/database/006_etapa13_agendamentos_clientes.sql`
- `docs/database/007_etapa14_logo_empresa_storage.sql`
- `docs/database/008_etapa15_agendamento_publico.sql`
- `docs/database/009_etapa16_master_plataforma.sql`

## Estrategia multi-tenant
- Todas as tabelas de dominio terao company_id.
- O acesso sera isolado por RLS no Supabase.
- Usuarios autenticados so poderao acessar dados da propria empresa.

## Regras aplicadas no SQL
- Tipos enum para `role` e `status`.
- Constraints de validacao (percentuais, valores e duracao).
- Integridade multi-tenant com chaves compostas para impedir vinculos entre empresas diferentes.
- Funcao `current_company_id()` para centralizar filtros de tenant nas policies.
- RLS habilitado em todas as tabelas de dominio.

## Status
- Etapa 1: Conexao inicial com Supabase configurada no codigo.
- Etapa 2: Autenticacao implementada no app.
- Etapa 3: Script SQL com modelagem inicial e RLS criado e documentado.
- Etapa 4: Bootstrap de empresa e perfil admin implementado no app para primeiro acesso.
- Etapa 5: CRUD inicial de funcionarios e servicos implementado no painel com isolamento por empresa.
- Etapa 6: CRUD inicial de agendamentos implementado com vinculacao de funcionario e servico da mesma empresa.
- Etapa 7: CRUD inicial de pagamentos implementado no painel, vinculado a agendamentos concluidos.
- Etapa 11: Convites por e-mail e trilha de auditoria implementados no app com aceite por token.
- Etapa 12: Automacoes de notificacao para eventos sensiveis implementadas com caixa de notificacoes no painel.
- Etapa 13: Cadastro inicial de clientes implementado no app com CRUD em `/painel/clientes`.
- Etapa 16: Estrutura de acesso master implementada para visao global de empresas em `/master/empresas`.

## Reforco de conflito de horarios (Etapa 6)
- Campo `data_hora_fim` adicionado em `appointments`.
- Indices adicionados para consultas de disponibilidade.
- Regra de conflito reforcada no banco com exclusion constraint para o mesmo funcionario em status `agendado`.
- Validacao de conflito implementada no backend e no frontend.

## Regras de financeiro (Etapa 7)
- Pagamentos sao vinculados por `appointment_id` com unicidade (um pagamento por agendamento).
- Cadastro de pagamento permitido apenas para agendamento em status `concluido`.
- `valor_comissao` e persistido a partir de `valor` e `percentual_comissao`.
- Operacoes seguem isolamento por empresa via `company_id` e RLS.

## Convites e auditoria (Etapa 11)
- `team_invites` armazena convites com token, papel, expiracao e status (`pending`, `accepted`, `revoked`, `expired`).
- `audit_logs` armazena eventos sensiveis por empresa (ator, acao, entidade e metadata).
- Policies de `team_invites` permitem select na mesma empresa e escrita apenas por admin.
- Policies de `audit_logs` permitem leitura e escrita no escopo da empresa via `current_company_id()`.
- Policies adicionais de `team_invites` permitem que o usuario autenticado aceite o proprio convite por e-mail/token.

## Nota de migracao
- Se o script `003_etapa11_convites_auditoria.sql` foi executado antes desta versao, reexecute o script para atualizar as policies de aceite por token.
- Para habilitar notificacoes sensiveis, execute `004_etapa12_notificacoes.sql` no Supabase SQL Editor.
- Para habilitar cadastro de clientes, execute `005_etapa13_clientes.sql` no Supabase SQL Editor.
- Para integrar clientes aos agendamentos, execute `006_etapa13_agendamentos_clientes.sql` no Supabase SQL Editor.
- Para habilitar acesso master global, execute `009_etapa16_master_plataforma.sql` no Supabase SQL Editor e inclua o `user_id` desejado em `public.platform_admins`.

```

### Arquivo: docs/database/001_etapa3_schema_rls.sql
```
-- Etapa 3: Modelagem inicial com RLS multi-tenant
-- Execute no Supabase SQL Editor.

-- Extensao para UUID
create extension if not exists "pgcrypto";

-- Enumeracoes
create type public.user_role as enum ('admin', 'employee');
create type public.appointment_status as enum ('agendado', 'concluido', 'cancelado');

-- Tabela de empresas
create table if not exists public.companies (
  id uuid primary key default gen_random_uuid(),
  nome text not null,
  logo text,
  cor_primaria text default '#000000',
  cor_secundaria text default '#D4AF37',
  telefone text,
  endereco text,
  created_at timestamptz not null default now()
);

-- Perfis (1 para 1 com auth.users)
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  company_id uuid not null references public.companies(id) on delete restrict,
  nome text not null,
  email text not null,
  role public.user_role not null default 'employee',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint profiles_email_unique unique (email),
  constraint profiles_email_lower check (email = lower(email))
);

-- Funcao helper para obter a empresa do usuario logado
create or replace function public.current_company_id()
returns uuid
language sql
stable
security definer
set search_path = public
as $$
  select p.company_id
  from public.profiles as p
  where p.id = auth.uid()
  limit 1;
$$;

revoke all on function public.current_company_id() from public;
grant execute on function public.current_company_id() to authenticated;

-- Funcionarios
create table if not exists public.employees (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  nome text not null,
  telefone text,
  percentual_comissao numeric(5,2) not null default 0,
  ativo boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint employees_percentual_comissao_range check (
    percentual_comissao >= 0 and percentual_comissao <= 100
  ),
  constraint employees_id_company_unique unique (id, company_id)
);

-- Servicos
create table if not exists public.services (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  nome text not null,
  duracao integer not null,
  valor numeric(10,2) not null,
  ativo boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint services_duracao_positive check (duracao > 0),
  constraint services_valor_positive check (valor >= 0),
  constraint services_id_company_unique unique (id, company_id)
);

-- Agendamentos
create table if not exists public.appointments (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  cliente_nome text not null,
  cliente_telefone text,
  employee_id uuid not null,
  service_id uuid not null,
  data_hora timestamptz not null,
  status public.appointment_status not null default 'agendado',
  observacoes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint appointments_id_company_unique unique (id, company_id),
  constraint appointments_employee_company_fk
    foreign key (employee_id, company_id)
    references public.employees (id, company_id)
    on delete restrict,
  constraint appointments_service_company_fk
    foreign key (service_id, company_id)
    references public.services (id, company_id)
    on delete restrict
);

-- Financeiro
create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  appointment_id uuid not null,
  valor numeric(10,2) not null,
  forma_pagamento text not null,
  percentual_comissao numeric(5,2) not null,
  valor_comissao numeric(10,2) not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint payments_appointment_unique unique (appointment_id),
  constraint payments_valor_positive check (valor >= 0),
  constraint payments_percentual_comissao_range check (
    percentual_comissao >= 0 and percentual_comissao <= 100
  ),
  constraint payments_valor_comissao_positive check (valor_comissao >= 0),
  constraint payments_appointment_company_fk
    foreign key (appointment_id, company_id)
    references public.appointments (id, company_id)
    on delete cascade
);

-- Indices principais
create index if not exists idx_profiles_company_id on public.profiles (company_id);
create index if not exists idx_employees_company_id on public.employees (company_id);
create index if not exists idx_services_company_id on public.services (company_id);
create index if not exists idx_appointments_company_id on public.appointments (company_id);
create index if not exists idx_appointments_data_hora on public.appointments (data_hora);
create index if not exists idx_payments_company_id on public.payments (company_id);
create index if not exists idx_payments_created_at on public.payments (created_at);

-- Trigger generico para updated_at
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- Recria triggers de updated_at para evitar duplicidade

drop trigger if exists trg_profiles_updated_at on public.profiles;
create trigger trg_profiles_updated_at
before update on public.profiles
for each row
execute function public.set_updated_at();

drop trigger if exists trg_employees_updated_at on public.employees;
create trigger trg_employees_updated_at
before update on public.employees
for each row
execute function public.set_updated_at();

drop trigger if exists trg_services_updated_at on public.services;
create trigger trg_services_updated_at
before update on public.services
for each row
execute function public.set_updated_at();

drop trigger if exists trg_appointments_updated_at on public.appointments;
create trigger trg_appointments_updated_at
before update on public.appointments
for each row
execute function public.set_updated_at();

drop trigger if exists trg_payments_updated_at on public.payments;
create trigger trg_payments_updated_at
before update on public.payments
for each row
execute function public.set_updated_at();

-- Habilita RLS
alter table public.companies enable row level security;
alter table public.profiles enable row level security;
alter table public.employees enable row level security;
alter table public.services enable row level security;
alter table public.appointments enable row level security;
alter table public.payments enable row level security;

-- Remove politicas antigas (seguro para reexecucao)
drop policy if exists companies_select_own on public.companies;
drop policy if exists companies_insert_authenticated on public.companies;
drop policy if exists companies_update_admin on public.companies;

drop policy if exists profiles_select_own_company on public.profiles;
drop policy if exists profiles_insert_self_bootstrap on public.profiles;
drop policy if exists profiles_insert_admin_same_company on public.profiles;
drop policy if exists profiles_update_own_or_admin_same_company on public.profiles;

drop policy if exists employees_crud_same_company on public.employees;
drop policy if exists services_crud_same_company on public.services;
drop policy if exists appointments_crud_same_company on public.appointments;
drop policy if exists payments_crud_same_company on public.payments;

-- Policies: companies
create policy companies_select_own
on public.companies
for select
to authenticated
using (id = public.current_company_id());

create policy companies_insert_authenticated
on public.companies
for insert
to authenticated
with check (true);

create policy companies_update_admin
on public.companies
for update
to authenticated
using (
  id = public.current_company_id()
  and exists (
    select 1
    from public.profiles p
    where p.id = auth.uid()
      and p.company_id = public.current_company_id()
      and p.role = 'admin'
  )
)
with check (id = public.current_company_id());

-- Policies: profiles
create policy profiles_select_own_company
on public.profiles
for select
to authenticated
using (company_id = public.current_company_id());

create policy profiles_insert_self_bootstrap
on public.profiles
for insert
to authenticated
with check (
  id = auth.uid()
  and email = lower(email)
);

create policy profiles_insert_admin_same_company
on public.profiles
for insert
to authenticated
with check (
  company_id = public.current_company_id()
  and exists (
    select 1
    from public.profiles p
    where p.id = auth.uid()
      and p.company_id = public.current_company_id()
      and p.role = 'admin'
  )
);

create policy profiles_update_own_or_admin_same_company
on public.profiles
for update
to authenticated
using (
  company_id = public.current_company_id()
  and (
    id = auth.uid()
    or exists (
      select 1
      from public.profiles p
      where p.id = auth.uid()
        and p.company_id = public.current_company_id()
        and p.role = 'admin'
    )
  )
)
with check (company_id = public.current_company_id());

-- Policies: employees
create policy employees_crud_same_company
on public.employees
for all
to authenticated
using (company_id = public.current_company_id())
with check (company_id = public.current_company_id());

-- Policies: services
create policy services_crud_same_company
on public.services
for all
to authenticated
using (company_id = public.current_company_id())
with check (company_id = public.current_company_id());

-- Policies: appointments
create policy appointments_crud_same_company
on public.appointments
for all
to authenticated
using (company_id = public.current_company_id())
with check (company_id = public.current_company_id());

-- Policies: payments
create policy payments_crud_same_company
on public.payments
for all
to authenticated
using (company_id = public.current_company_id())
with check (company_id = public.current_company_id());

```

### Arquivo: docs/database/002_etapa6_conflito_agendamentos.sql
```
-- Etapa 6 - Reforco de conflitos de horario em agendamentos
-- Execute no Supabase SQL Editor apos a Etapa 3.

create extension if not exists btree_gist;

alter table public.appointments
add column if not exists data_hora_fim timestamptz;

-- Backfill para dados existentes usando a duracao do servico.
update public.appointments as a
set data_hora_fim = a.data_hora + make_interval(mins => s.duracao)
from public.services as s
where a.service_id = s.id
  and a.company_id = s.company_id
  and a.data_hora_fim is null;

-- Fallback defensivo para evitar nulos em dados legados inconsistentes.
update public.appointments
set data_hora_fim = data_hora + interval '30 minutes'
where data_hora_fim is null;

alter table public.appointments
alter column data_hora_fim set not null;

alter table public.appointments
drop constraint if exists appointments_data_hora_fim_after_start;

alter table public.appointments
add constraint appointments_data_hora_fim_after_start
check (data_hora_fim > data_hora);

create index if not exists idx_appointments_employee_status_start
on public.appointments (company_id, employee_id, status, data_hora);

create index if not exists idx_appointments_employee_status_end
on public.appointments (company_id, employee_id, status, data_hora_fim);

-- Regra de conflito no banco (backend principal):
-- novo_inicio < existente_fim AND novo_fim > existente_inicio
-- Aplicada apenas para status 'agendado'.
alter table public.appointments
drop constraint if exists appointments_no_overlap_per_employee;

alter table public.appointments
add constraint appointments_no_overlap_per_employee
exclude using gist (
  company_id with =,
  employee_id with =,
  tstzrange(data_hora, data_hora_fim, '[)') with &&
)
where (status = 'agendado');

```

### Arquivo: docs/database/003_etapa11_convites_auditoria.sql
```
-- Etapa 11 - Convites da equipe e trilha de auditoria
-- Execute no Supabase SQL Editor apos a Etapa 3.

do $$
begin
  if not exists (
    select 1
    from pg_type t
    join pg_namespace n on n.oid = t.typnamespace
    where t.typname = 'invite_status'
      and n.nspname = 'public'
  ) then
    create type public.invite_status as enum ('pending', 'accepted', 'revoked', 'expired');
  end if;
end
$$;

create table if not exists public.team_invites (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  email text not null,
  role public.user_role not null default 'employee',
  status public.invite_status not null default 'pending',
  token text not null,
  invited_by uuid references auth.users(id) on delete set null,
  accepted_by uuid references auth.users(id) on delete set null,
  expires_at timestamptz not null,
  accepted_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint team_invites_email_lower check (email = lower(email)),
  constraint team_invites_token_unique unique (token)
);

create index if not exists idx_team_invites_company_id on public.team_invites(company_id);
create index if not exists idx_team_invites_status on public.team_invites(status);
create index if not exists idx_team_invites_expires_at on public.team_invites(expires_at);

create table if not exists public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  actor_id uuid references auth.users(id) on delete set null,
  action text not null,
  entity text not null,
  entity_id text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists idx_audit_logs_company_created_at on public.audit_logs(company_id, created_at desc);
create index if not exists idx_audit_logs_action on public.audit_logs(action);

drop trigger if exists trg_team_invites_updated_at on public.team_invites;
create trigger trg_team_invites_updated_at
before update on public.team_invites
for each row
execute function public.set_updated_at();

alter table public.team_invites enable row level security;
alter table public.audit_logs enable row level security;

drop policy if exists team_invites_select_same_company on public.team_invites;
drop policy if exists team_invites_insert_admin_same_company on public.team_invites;
drop policy if exists team_invites_update_admin_same_company on public.team_invites;
drop policy if exists team_invites_delete_admin_same_company on public.team_invites;
drop policy if exists team_invites_select_invited_email on public.team_invites;
drop policy if exists team_invites_update_invited_accept on public.team_invites;

drop policy if exists audit_logs_select_same_company on public.audit_logs;
drop policy if exists audit_logs_insert_same_company on public.audit_logs;

create policy team_invites_select_same_company
on public.team_invites
for select
to authenticated
using (company_id = public.current_company_id());

create policy team_invites_select_invited_email
on public.team_invites
for select
to authenticated
using (
  email = lower(coalesce(auth.jwt() ->> 'email', ''))
);

create policy team_invites_insert_admin_same_company
on public.team_invites
for insert
to authenticated
with check (
  company_id = public.current_company_id()
  and exists (
    select 1
    from public.profiles p
    where p.id = auth.uid()
      and p.company_id = public.current_company_id()
      and p.role = 'admin'
  )
);

create policy team_invites_update_admin_same_company
on public.team_invites
for update
to authenticated
using (
  company_id = public.current_company_id()
  and exists (
    select 1
    from public.profiles p
    where p.id = auth.uid()
      and p.company_id = public.current_company_id()
      and p.role = 'admin'
  )
)
with check (company_id = public.current_company_id());

create policy team_invites_update_invited_accept
on public.team_invites
for update
to authenticated
using (
  status = 'pending'
  and email = lower(coalesce(auth.jwt() ->> 'email', ''))
)
with check (
  email = lower(coalesce(auth.jwt() ->> 'email', ''))
  and status in ('accepted', 'expired')
  and accepted_by = auth.uid()
);

create policy team_invites_delete_admin_same_company
on public.team_invites
for delete
to authenticated
using (
  company_id = public.current_company_id()
  and exists (
    select 1
    from public.profiles p
    where p.id = auth.uid()
      and p.company_id = public.current_company_id()
      and p.role = 'admin'
  )
);

create policy audit_logs_select_same_company
on public.audit_logs
for select
to authenticated
using (company_id = public.current_company_id());

create policy audit_logs_insert_same_company
on public.audit_logs
for insert
to authenticated
with check (company_id = public.current_company_id());

```

### Arquivo: docs/database/004_etapa12_notificacoes.sql
```
-- Etapa 12 - Automacoes de notificacao para eventos sensiveis
-- Execute no Supabase SQL Editor apos a Etapa 11.

create table if not exists public.security_notifications (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  recipient_id uuid not null references auth.users(id) on delete cascade,
  actor_id uuid references auth.users(id) on delete set null,
  event_key text not null,
  title text not null,
  message text not null,
  severity text not null default 'warning',
  metadata jsonb not null default '{}'::jsonb,
  read_at timestamptz,
  created_at timestamptz not null default now(),
  constraint security_notifications_severity_check check (severity in ('info', 'warning', 'critical'))
);

create index if not exists idx_security_notifications_company_created
  on public.security_notifications(company_id, created_at desc);
create index if not exists idx_security_notifications_recipient_read
  on public.security_notifications(recipient_id, read_at);
create index if not exists idx_security_notifications_event_key
  on public.security_notifications(event_key);

alter table public.security_notifications enable row level security;

drop policy if exists security_notifications_select_recipient on public.security_notifications;
drop policy if exists security_notifications_insert_admin_same_company on public.security_notifications;
drop policy if exists security_notifications_update_recipient on public.security_notifications;

create policy security_notifications_select_recipient
on public.security_notifications
for select
to authenticated
using (
  company_id = public.current_company_id()
  and recipient_id = auth.uid()
);

create policy security_notifications_insert_admin_same_company
on public.security_notifications
for insert
to authenticated
with check (
  company_id = public.current_company_id()
  and exists (
    select 1
    from public.profiles p
    where p.id = auth.uid()
      and p.company_id = public.current_company_id()
      and p.role = 'admin'
  )
);

create policy security_notifications_update_recipient
on public.security_notifications
for update
to authenticated
using (
  company_id = public.current_company_id()
  and recipient_id = auth.uid()
)
with check (
  company_id = public.current_company_id()
  and recipient_id = auth.uid()
);

```

### Arquivo: docs/database/005_etapa13_clientes.sql
```
-- Etapa 13 - Cadastro de clientes (primeiro bloco)
-- Execute no Supabase SQL Editor apos a Etapa 3.

create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  nome text not null,
  telefone text,
  email text,
  observacoes text,
  ativo boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint customers_nome_min_length check (char_length(trim(nome)) >= 2)
);

create index if not exists idx_customers_company_created_at
  on public.customers(company_id, created_at desc);
create index if not exists idx_customers_company_nome
  on public.customers(company_id, nome);

drop trigger if exists trg_customers_updated_at on public.customers;
create trigger trg_customers_updated_at
before update on public.customers
for each row
execute function public.set_updated_at();

alter table public.customers enable row level security;

drop policy if exists customers_select_same_company on public.customers;
drop policy if exists customers_insert_admin_same_company on public.customers;
drop policy if exists customers_update_admin_same_company on public.customers;
drop policy if exists customers_delete_admin_same_company on public.customers;

create policy customers_select_same_company
on public.customers
for select
to authenticated
using (company_id = public.current_company_id());

create policy customers_insert_admin_same_company
on public.customers
for insert
to authenticated
with check (
  company_id = public.current_company_id()
  and exists (
    select 1
    from public.profiles p
    where p.id = auth.uid()
      and p.company_id = public.current_company_id()
      and p.role = 'admin'
  )
);

create policy customers_update_admin_same_company
on public.customers
for update
to authenticated
using (
  company_id = public.current_company_id()
  and exists (
    select 1
    from public.profiles p
    where p.id = auth.uid()
      and p.company_id = public.current_company_id()
      and p.role = 'admin'
  )
)
with check (company_id = public.current_company_id());

create policy customers_delete_admin_same_company
on public.customers
for delete
to authenticated
using (
  company_id = public.current_company_id()
  and exists (
    select 1
    from public.profiles p
    where p.id = auth.uid()
      and p.company_id = public.current_company_id()
      and p.role = 'admin'
  )
);

```

### Arquivo: docs/database/006_etapa13_agendamentos_clientes.sql
```
-- Etapa 13 - Integracao de clientes em agendamentos
-- Execute no Supabase SQL Editor apos 001, 002 e 005.

alter table public.customers
  add column if not exists updated_at timestamptz not null default now();

do $$
begin
  if not exists (
    select 1
    from pg_constraint
    where conname = 'customers_id_company_unique'
      and conrelid = 'public.customers'::regclass
  ) then
    alter table public.customers
      add constraint customers_id_company_unique unique (id, company_id);
  end if;
end
$$;

alter table public.appointments
  add column if not exists customer_id uuid;

do $$
begin
  if not exists (
    select 1
    from pg_constraint
    where conname = 'appointments_customer_company_fk'
      and conrelid = 'public.appointments'::regclass
  ) then
    alter table public.appointments
      add constraint appointments_customer_company_fk
      foreign key (customer_id, company_id)
      references public.customers (id, company_id)
      on delete set null;
  end if;
end
$$;

create index if not exists idx_appointments_customer_id
  on public.appointments (customer_id);

```

### Arquivo: docs/database/009_etapa16_master_plataforma.sql
```
-- Etapa 16: Acesso master da plataforma (visao global)

create table if not exists public.platform_admins (
  user_id uuid primary key,
  created_at timestamptz not null default timezone('utc', now())
);

comment on table public.platform_admins is 'Usuarios master com acesso global de plataforma.';

alter table public.platform_admins enable row level security;

drop policy if exists platform_admins_select_self on public.platform_admins;
create policy platform_admins_select_self
on public.platform_admins
for select
to authenticated
using (user_id = auth.uid());

create or replace function public.is_platform_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.platform_admins pa
    where pa.user_id = auth.uid()
  );
$$;

revoke all on function public.is_platform_admin() from public;
grant execute on function public.is_platform_admin() to authenticated;

drop policy if exists companies_select_platform_admin on public.companies;
create policy companies_select_platform_admin
on public.companies
for select
to authenticated
using (public.is_platform_admin());

-- Uso inicial:
-- insert into public.platform_admins (user_id) values ('SEU_USER_ID_AQUI');

```

### Arquivo: docs/database/etapa3_como_executar.md
```
# Etapa 3 - Como executar SQL e RLS no Supabase

## Objetivo
Aplicar o schema inicial multi-tenant e as politicas de RLS no banco PostgreSQL do Supabase.

## Arquivo SQL da etapa
- `docs/database/001_etapa3_schema_rls.sql`

## Passo a passo (Supabase)
1. Acesse o projeto no painel do Supabase.
2. No menu lateral, clique em SQL Editor.
3. Clique em New query.
4. Abra o arquivo `docs/database/001_etapa3_schema_rls.sql` no projeto e copie todo o conteudo.
5. Cole no SQL Editor.
6. Clique em Run.

## Validacoes rapidas
1. Em Table Editor, confirme as tabelas:
   - companies
   - profiles
   - employees
   - services
   - appointments
   - payments
2. Em Authentication > Policies, confirme que RLS foi habilitado para todas as tabelas acima.

## Observacoes importantes
- Este script nao cria dashboard nem telas de agenda/financeiro.
- A funcao `current_company_id()` depende da existencia de registro em `profiles` para o usuario autenticado.
- No Supabase, a service role ignora RLS por design. Use apenas em processos administrativos controlados.

```

### Arquivo: docs/database/etapa6_testes_basicos.md
```
# Etapa 6 - Testes basicos de conflito de horario

## Pre-requisitos
- Script `docs/database/002_etapa6_conflito_agendamentos.sql` executado no Supabase.
- Pelo menos 1 funcionario ativo e 1 servico ativo cadastrados.

## Casos de teste

1. Criacao sem conflito
- Criar agendamento para funcionario A as 14:00 com servico de 60 min.
- Esperado: sucesso.

2. Conflito no mesmo funcionario (sobreposicao)
- Criar outro para funcionario A as 14:30.
- Esperado: bloqueio com mensagem amigavel de horario indisponivel.

3. Sem conflito para outro funcionario
- Criar para funcionario B as 14:30.
- Esperado: sucesso.

4. Reagendamento com conflito
- Editar um agendamento existente do funcionario A para horario que sobrepoe outro agendado.
- Esperado: bloqueio com mensagem de conflito.

5. Cancelado nao bloqueia
- Marcar um agendamento como cancelado e tentar criar outro no mesmo intervalo.
- Esperado: permitido.

6. Integridade no banco
- Tentar inserir manualmente no SQL Editor dois agendamentos sobrepostos para mesmo funcionario com status agendado.
- Esperado: erro de constraint `appointments_no_overlap_per_employee`.

## Timezone
- O front envia datetime local e o backend converte para ISO (UTC).
- A comparacao de conflito ocorre com timestamptz no banco, mantendo consistencia.

```

### Arquivo: docs/database/README.md
```
# Database

Esta pasta guarda materiais de banco de dados, incluindo scripts SQL e politicas RLS nas proximas etapas.

## Arquivos atuais
- `001_etapa3_schema_rls.sql`: modelagem inicial do banco com RLS multi-tenant.
- `etapa3_como_executar.md`: guia de execucao do script no Supabase SQL Editor.
- `002_etapa6_conflito_agendamentos.sql`: reforco de agendamentos com `data_hora_fim` e bloqueio de sobreposicao por funcionario.
- `etapa6_testes_basicos.md`: roteiro de validacao dos cenarios de conflito.
- `003_etapa11_convites_auditoria.sql`: tabelas e policies para convites e trilha de auditoria.
- `004_etapa12_notificacoes.sql`: tabela e policies para notificacoes de eventos sensiveis.
- `005_etapa13_clientes.sql`: tabela e policies para cadastro de clientes.
- `006_etapa13_agendamentos_clientes.sql`: vinculo opcional de agendamento com cliente cadastrado.
- `007_etapa14_logo_empresa_storage.sql`: bucket e policies para logo da empresa.
- `008_etapa15_agendamento_publico.sql`: configuracoes e policies para agendamento publico.
- `009_etapa16_master_plataforma.sql`: acesso master global para visao de empresas.

```

### Arquivo: docs/manual-de-uso.md
```
# Manual de Uso - SaaS Agenda de Servicos

## 1. Visao geral
Este sistema permite gerenciar negocios de servicos em modelo SaaS com isolamento por empresa (multi-tenant).

Principais recursos:
- Autenticacao (login, cadastro, recuperacao de senha)
- Onboarding da empresa no primeiro acesso
- Dashboard com indicadores
- CRUD de funcionarios, servicos, clientes, agendamentos e financeiro
- Gestao de equipe e papeis
- Convites por e-mail
- Auditoria e notificacoes sensiveis
- Relatorios com exportacao CSV/PDF

## 2. Perfis de acesso
Existem tres papeis:
- master: acesso global da plataforma para visao de todas as empresas
- admin: acesso completo aos modulos
- employee: acesso limitado (agendamentos e relatorios)

## 3. Requisitos para rodar
- Node.js 22+ (recomendado)
- Projeto Supabase criado
- Banco com scripts SQL aplicados na ordem correta

## 4. Configuracao inicial
### 4.1 Variaveis de ambiente
Crie o arquivo .env.local com base no .env.example.

Campos obrigatorios:
- NEXT_PUBLIC_SUPABASE_URL
- NEXT_PUBLIC_SUPABASE_ANON_KEY

Campo obrigatorio em producao:
- NEXT_PUBLIC_APP_URL (https://saas-barbearias.vercel.app)

Campo opcional (futuras integracoes administrativas):
- SUPABASE_SERVICE_ROLE_KEY

Observacao para area master:
- `SUPABASE_SERVICE_ROLE_KEY` passa a ser obrigatoria para incluir, alterar, excluir empresas e gerar relatorios globais.

### 4.2 Instalar dependencias
Execute:
- npm install

### 4.3 Rodar aplicacao
Execute:
- npm run dev

Acesse:
- http://localhost:3000

## 5. Banco de dados (ordem recomendada)
No Supabase SQL Editor, execute os scripts:
1. docs/database/001_etapa3_schema_rls.sql
2. docs/database/002_etapa6_conflito_agendamentos.sql
3. docs/database/003_etapa11_convites_auditoria.sql
4. docs/database/004_etapa12_notificacoes.sql
5. docs/database/005_etapa13_clientes.sql
6. docs/database/006_etapa13_agendamentos_clientes.sql
7. docs/database/007_etapa14_logo_empresa_storage.sql
8. docs/database/008_etapa15_agendamento_publico.sql
9. docs/database/009_etapa16_master_plataforma.sql

Se algum modulo acusar erro de tabela/campo ausente, revalide se todos os scripts acima foram executados.

## 5.1 Deploy na Vercel e links de e-mail
Para evitar que e-mails de cadastro/recuperacao apontem para localhost:
1. Na Vercel, configure a variavel `NEXT_PUBLIC_APP_URL` com a URL publica do projeto.
2. No Supabase, abra Authentication > URL Configuration.
3. Em Site URL, informe a mesma URL publica da Vercel.
4. Em Redirect URLs, adicione:
- https://saas-barbearias.vercel.app/auth/confirm?next=/login
- https://saas-barbearias.vercel.app/auth/atualizar-senha
5. Salve e teste novo cadastro em ambiente de producao.

## 6. Primeiro acesso (fluxo admin)
1. Acesse /login
2. Clique em Cadastrar para criar usuario
3. Confirme e-mail (se habilitado no Supabase)
4. Apos login, o sistema envia para /onboarding
5. No onboarding, informe:
- nome do responsavel
- nome da empresa
- telefone (opcional)
- endereco (opcional)
6. Finalize o cadastro
7. Sistema redireciona para /painel

## 7. Navegacao principal
Tela principal:
- /painel

Area master:
- /master/empresas
- /master/relatorios

Modulos:
- /painel/funcionarios
- /painel/servicos
- /painel/clientes
- /painel/agendamentos
- /painel/financeiro
- /painel/equipe
- /painel/auditoria
- /painel/notificacoes
- /painel/relatorios

## 8. Operacao recomendada (ordem diaria)
1. Funcionarios
- Cadastre os profissionais
- Defina percentual de comissao

2. Servicos
- Cadastre servicos com duracao e valor

3. Clientes
- Cadastre clientes para historico e relacionamento

4. Agendamentos
- Crie agendamentos vinculando cliente, funcionario e servico
- Sistema bloqueia conflito de horario por funcionario

5. Financeiro
- Registre pagamento apenas para agendamento concluido
- Sistema calcula valor de comissao automaticamente

6. Relatorios
- Exporte CSV/PDF por periodo para operacao e gestao

## 9. Detalhe por modulo
### 9.1 Dashboard
- Mostra agenda do dia
- Mostra faturamento diario
- Mostra status dos agendamentos
- Mostra servicos mais vendidos no mes

### 9.2 Funcionarios
- Criar, editar, ativar/inativar e remover
- Campo de comissao com validacao

### 9.3 Servicos
- Criar, editar, ativar/inativar e remover
- Campos de duracao e valor com validacao

### 9.4 Clientes
- Criar, editar, ativar/inativar e remover
- Historico individual por cliente em /painel/clientes/[id]

### 9.5 Agendamentos
- Criar, editar e (para admin) excluir
- Vinculo com funcionario e servico da mesma empresa
- Validacao de conflito de horario

### 9.6 Financeiro
- Criar, editar e excluir pagamentos
- Um pagamento por agendamento
- Filtros por periodo
- Resumo por funcionario

### 9.7 Equipe
- Alteracao de papel (admin/employee)
- Convites por e-mail
- Revogacao de convites

### 9.8 Auditoria
- Lista eventos sensiveis
- Filtros por periodo, acao, entidade e texto
- Exportacao CSV/PDF

### 9.9 Notificacoes sensiveis
- Exibe alertas de eventos criticos
- Marcar item como lido
- Marcar todas como lidas

### 9.10 Relatorios
- Exportacao de agendamentos (CSV/PDF)
- Exportacao de financeiro (CSV/PDF)
- Filtro por intervalo de datas

## 10. Permissoes (resumo)
Master:
- Acesso global para listar empresas cadastradas da plataforma
- Pode incluir, alterar e excluir empresas na area master
- Pode acessar relatorios financeiros consolidados de todas as empresas
- Pode filtrar os relatorios financeiros por empresa especifica
- Pode pesquisar empresa digitando parte do nome no filtro dos relatorios master

Admin:
- Acesso total a todos os modulos e operacoes

Equipe (employee):
- Pode acessar agendamentos e relatorios
- Nao pode acessar modulos administrativos restritos

## 11. Erros comuns e solucao
1. Erro de sessao expirada
- Faca login novamente em /login

2. Erro de empresa nao encontrada
- Finalize onboarding em /onboarding

3. Erro em clientes, convites, auditoria ou notificacoes
- Verifique scripts SQL das etapas 11, 12 e 13

4. Erro de conflito de horario em agendamentos
- Horario ja ocupado para o funcionario
- Escolha outro horario

5. Erro de pagamento duplicado
- Cada agendamento concluido aceita apenas um pagamento

## 12. Boas praticas operacionais
- Cadastre servicos e funcionarios antes de iniciar agenda
- Use clientes cadastrados para manter historico consolidado
- Defina papeis corretos da equipe para seguranca
- Revise auditoria periodicamente
- Exporte relatorios no fechamento diario/semanal

## 13. Checklist rapido de abertura
- Login funcionando
- Modulos carregando sem erro de schema
- Agenda com funcionarios e servicos ativos
- Financeiro registrando pagamentos
- Relatorios exportando CSV/PDF

## 14. Referencias internas
- docs/roadmap.md
- docs/rules.md
- docs/database.md
- docs/database/README.md
- docs/changelog.md

```

### Arquivo: docs/prompts/README.md
```
# Prompts

Esta pasta armazena prompts e instrucoes de trabalho para desenvolvimento guiado por etapas.

```

### Arquivo: docs/roadmap.md
```
# Roadmap

## Etapa 1 - Base do projeto
Status: Concluida em 2026-07-04

Checklist:
- [x] Criar projeto Next.js
- [x] Configurar TailwindCSS
- [x] Configurar shadcn/ui
- [x] Configurar Supabase (dependencias e clientes)
- [x] Criar estrutura inicial de pastas
- [x] Criar documentacao inicial
- [x] Criar tela inicial de login
- [x] Criar conexao com banco
- [x] Criar variaveis .env.example
- [x] Criar rota de teste da conexao Supabase

## Etapa 2 - Autenticacao
Status: Concluida em 2026-07-04

Checklist:
- [x] Login real com Supabase Auth
- [x] Cadastro de conta
- [x] Recuperacao de senha por e-mail
- [x] Pagina de atualizacao de senha
- [x] Protecao basica de rotas

## Etapa 3 - Modelagem SQL e RLS
Status: Concluida em 2026-07-04

Checklist:
- [x] Criar script SQL inicial para tabelas obrigatorias
- [x] Definir enums e constraints
- [x] Definir indices principais
- [x] Implementar RLS multi-tenant
- [x] Documentar execucao no Supabase SQL Editor

## Etapa 4 - Bootstrap inicial da empresa
Status: Concluida em 2026-07-04

Checklist:
- [x] Criar rota de onboarding para primeiro acesso
- [x] Criar formulario para cadastrar empresa inicial
- [x] Criar perfil admin inicial vinculado a empresa
- [x] Redirecionar usuario sem empresa para onboarding
- [x] Atualizar documentacao da etapa

## Etapa 5 - CRUD de funcionarios e servicos
Status: Concluida em 2026-07-04

Checklist:
- [x] Criar CRUD de funcionarios
- [x] Criar CRUD de servicos
- [x] Validar isolamento por empresa (company_id)
- [x] Adicionar estados de loading e mensagens de erro/sucesso
- [x] Atualizar documentacao da etapa

## Etapa 6 - CRUD inicial de agendamentos
Status: Concluida em 2026-07-04

Checklist:
- [x] Criar CRUD de agendamentos
- [x] Vincular agendamento a funcionario e servico
- [x] Validar isolamento por empresa (company_id)
- [x] Adicionar estados de loading e mensagens de feedback
- [x] Calcular e persistir data_hora_fim automaticamente
- [x] Bloquear conflitos de horario por funcionario (frontend e backend)
- [x] Atualizar documentacao da etapa

## Etapa 7 - CRUD inicial do financeiro
Status: Concluida em 2026-07-04

Checklist:
- [x] Criar CRUD de pagamentos em `/painel/financeiro`
- [x] Vincular pagamento somente a agendamento concluido
- [x] Impedir pagamento duplicado por agendamento
- [x] Calcular e persistir valor de comissao automaticamente
- [x] Atualizar painel e documentacao da etapa

## Etapa 8 - Dashboard com indicadores
Status: Concluida em 2026-07-04

Checklist:
- [x] Dashboard inicial no painel com Agenda do dia e contadores por status
- [x] Indicador de faturamento do dia
- [x] Indicador de servicos mais vendidos
- [x] Atualizar documentacao de encerramento da etapa

## Etapa 9 - Relatorios e exportacao
Status: Concluida em 2026-07-04

Checklist:
- [x] Criar modulo de relatorios em `/painel/relatorios`
- [x] Exportar CSV de agendamentos por periodo
- [x] Exportar CSV de financeiro por periodo
- [x] Exportacao em PDF (agendamentos e financeiro)
- [x] Atualizar documentacao de encerramento da etapa

## Etapa 10 - Permissoes e papeis avancados
Status: Concluida em 2026-07-04

Checklist:
- [x] Criar base de RBAC com leitura de papel (`admin` e `employee`) no backend
- [x] Restringir modulos criticos (funcionarios, servicos, financeiro) para admin
- [x] Aplicar validacao de permissao nas pages e nas server actions
- [x] Permissoes granulares por operacao (leitura vs escrita)
- [x] Gestao de membros/equipe com troca de papel
- [x] Atualizar documentacao de encerramento da etapa

## Etapa 11 - Convites e auditoria
Status: Concluida em 2026-07-04

Checklist:
- [x] Criar estrutura de convites por e-mail no modulo de equipe
- [x] Permitir criar/listar/revogar convites por admin
- [x] Preparar script SQL para `team_invites` e `audit_logs`
- [x] Fluxo completo de aceite de convite por token
- [x] Exibicao dedicada da trilha de auditoria no painel
- [x] Atualizar documentacao de encerramento da etapa

## Etapa 12 - Melhorias operacionais
Status: Concluida em 2026-07-04

Checklist:
- [x] Filtros avancados na auditoria (periodo, acao, entidade e busca textual)
- [x] Exportacao da auditoria (CSV/PDF)
- [x] Automacoes de notificacao para eventos sensiveis
- [x] Atualizar documentacao de encerramento da etapa

## Etapa 13 - Clientes e relacionamento
Status: Concluida em 2026-07-04

Checklist:
- [x] Criar estrutura SQL de clientes (`customers`) com RLS
- [x] Criar modulo `/painel/clientes` com CRUD inicial
- [x] Integrar clientes ao fluxo de agendamentos
- [x] Historico de atendimentos por cliente
- [x] Atualizar documentacao de encerramento da etapa

## Proximas etapas (aguardando autorizacao)
- Definir Etapa 14.

```

### Arquivo: docs/rules.md
```
# Regras do Projeto

## Stack obrigatoria
- Next.js (App Router)
- TypeScript
- TailwindCSS
- shadcn/ui
- Supabase
- PostgreSQL
- Deploy alvo: Vercel

## Regras tecnicas
- Sempre usar TypeScript.
- Nao usar any.
- Priorizar Server Components quando possivel.
- Criar componentes reutilizaveis.
- Validar formularios.
- Tratar erros e estados de carregamento.
- Manter clean code e escalabilidade.
- Interface mobile first e responsiva.

## Regras de execucao
- Implementar uma funcionalidade por vez.
- Nao adicionar funcionalidades extras sem autorizacao.
- Atualizar documentacao a cada etapa.
- Nao quebrar funcionalidades existentes.

```

### Arquivo: eslint.config.mjs
```
import { defineConfig, globalIgnores } from "eslint/config";
import nextVitals from "eslint-config-next/core-web-vitals";
import nextTs from "eslint-config-next/typescript";

const eslintConfig = defineConfig([
  ...nextVitals,
  ...nextTs,
  // Override default ignores of eslint-config-next.
  globalIgnores([
    // Default ignores of eslint-config-next:
    ".next/**",
    "out/**",
    "build/**",
    "next-env.d.ts",
  ]),
]);

export default eslintConfig;

```

### Arquivo: middleware.ts
```
import { type NextRequest } from "next/server";

import { updateSession } from "@/lib/supabase/middleware";

export async function middleware(request: NextRequest) {
  return updateSession(request);
}

export const config = {
  matcher: ["/login", "/auth/:path*", "/painel/:path*", "/master/:path*", "/onboarding", "/convites/:path*"],
};

```

### Arquivo: next.config.ts
```
import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* config options here */
};

export default nextConfig;

```

### Arquivo: package.json
```
{
  "name": "saas-barbearias",
  "version": "0.1.0",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "lint": "eslint",
    "ai:context": "powershell -ExecutionPolicy Bypass -File ./scripts/generate-ai-context.ps1 -Mode lite",
    "ai:context:full": "powershell -ExecutionPolicy Bypass -File ./scripts/generate-ai-context.ps1 -Mode full"
  },
  "dependencies": {
    "@supabase/ssr": "^0.12.0",
    "@supabase/supabase-js": "^2.110.0",
    "class-variance-authority": "^0.7.1",
    "clsx": "^2.1.1",
    "lucide-react": "^1.23.0",
    "next": "16.3.0",
    "pdf-lib": "^1.17.1",
    "radix-ui": "^1.6.1",
    "react": "19.2.4",
    "react-dom": "19.2.4",
    "shadcn": "^4.13.0",
    "tailwind-merge": "^3.6.0",
    "tw-animate-css": "^1.4.0"
  },
  "devDependencies": {
    "@tailwindcss/postcss": "^4",
    "@types/node": "^20",
    "@types/react": "^19",
    "@types/react-dom": "^19",
    "eslint": "^9",
    "eslint-config-next": "16.3.0",
    "tailwindcss": "^4",
    "typescript": "^5"
  }
}

```

### Arquivo: postcss.config.mjs
```
const config = {
  plugins: {
    "@tailwindcss/postcss": {},
  },
};

export default config;

```

### Arquivo: README.md
```
This is a [Next.js](https://nextjs.org) project bootstrapped with [`create-next-app`](https://nextjs.org/docs/app/api-reference/cli/create-next-app).

## Manual de Uso

- Consulte o manual completo em `docs/manual-de-uso.md`.

## Getting Started

First, run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

You can start editing the page by modifying `app/page.tsx`. The page auto-updates as you edit the file.

This project uses [`next/font`](https://nextjs.org/docs/app/building-your-application/optimizing/fonts) to automatically optimize and load [Geist](https://vercel.com/font), a new font family for Vercel.

## Learn More

To learn more about Next.js, take a look at the following resources:

- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.
- [Learn Next.js](https://nextjs.org/learn) - an interactive Next.js tutorial.

You can check out [the Next.js GitHub repository](https://github.com/vercel/next.js) - your feedback and contributions are welcome!

## Deploy on Vercel

The easiest way to deploy your Next.js app is to use the [Vercel Platform](https://vercel.com/new?utm_medium=default-template&filter=next.js&utm_source=create-next-app&utm_campaign=create-next-app-readme) from the creators of Next.js.

Check out our [Next.js deployment documentation](https://nextjs.org/docs/app/building-your-application/deploying) for more details.

```

### Arquivo: src/app/api/reports/appointments/pdf/route.ts
```
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { generateReportPdf } from "@/lib/reports/pdf";

type AppointmentStatus = "agendado" | "concluido" | "cancelado";

type AppointmentRow = {
  id: string;
  cliente_nome: string;
  cliente_telefone: string | null;
  data_hora: string;
  data_hora_fim: string | null;
  status: AppointmentStatus;
  observacoes: string | null;
  employee_id: string;
  service_id: string;
  created_at: string;
};

type EmployeeRow = {
  id: string;
  nome: string;
};

type ServiceRow = {
  id: string;
  nome: string;
};

function buildDateRange(url: URL) {
  const now = new Date();
  const startDefault = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
  const endDefault = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);

  const startInput = url.searchParams.get("start");
  const endInput = url.searchParams.get("end");

  const start = startInput && /^\d{4}-\d{2}-\d{2}$/.test(startInput) ? new Date(`${startInput}T00:00:00`) : startDefault;
  const end = endInput && /^\d{4}-\d{2}-\d{2}$/.test(endInput) ? new Date(`${endInput}T23:59:59.999`) : endDefault;

  return {
    startIso: start.toISOString(),
    endIso: end.toISOString(),
    labelStart: start.toISOString().slice(0, 10),
    labelEnd: end.toISOString().slice(0, 10),
  };
}

export async function GET(request: Request) {
  const url = new URL(request.url);
  const range = buildDateRange(url);

  const supabase = await createSupabaseServerClient();
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser();

  if (userError || !user) {
    return Response.json({ error: "Nao autenticado." }, { status: 401 });
  }

  const { data: companyId, error: companyError } = await supabase.rpc("current_company_id");

  if (companyError || !companyId) {
    return Response.json({ error: "Empresa nao encontrada para este usuario." }, { status: 400 });
  }

  const { data: appointmentsData, error: appointmentsError } = await supabase
    .from("appointments")
    .select("id, cliente_nome, cliente_telefone, data_hora, data_hora_fim, status, observacoes, employee_id, service_id, created_at")
    .eq("company_id", companyId)
    .gte("data_hora", range.startIso)
    .lte("data_hora", range.endIso)
    .order("data_hora", { ascending: true });

  if (appointmentsError) {
    return Response.json({ error: `Erro ao gerar relatorio: ${appointmentsError.message}` }, { status: 500 });
  }

  const appointments = (appointmentsData ?? []) as AppointmentRow[];
  const employeeIds = [...new Set(appointments.map((item) => item.employee_id).filter(Boolean))];
  const serviceIds = [...new Set(appointments.map((item) => item.service_id).filter(Boolean))];

  const [employeesResponse, servicesResponse] = await Promise.all([
    employeeIds.length > 0
      ? supabase.from("employees").select("id, nome").eq("company_id", companyId).in("id", employeeIds)
      : Promise.resolve({ data: [] as EmployeeRow[], error: null }),
    serviceIds.length > 0
      ? supabase.from("services").select("id, nome").eq("company_id", companyId).in("id", serviceIds)
      : Promise.resolve({ data: [] as ServiceRow[], error: null }),
  ]);

  if (employeesResponse.error || servicesResponse.error) {
    return Response.json({ error: "Erro ao carregar referencias para o relatorio." }, { status: 500 });
  }

  const employees = (employeesResponse.data ?? []) as EmployeeRow[];
  const services = (servicesResponse.data ?? []) as ServiceRow[];

  const employeeNameById = new Map(employees.map((employee) => [employee.id, employee.nome]));
  const serviceNameById = new Map(services.map((service) => [service.id, service.nome]));

  const columns = [
    "id",
    "cliente_nome",
    "cliente_telefone",
    "data_hora",
    "data_hora_fim",
    "status",
    "funcionario",
    "servico",
    "observacoes",
    "created_at",
  ];

  const rows = appointments.map((appointment) => [
    appointment.id,
    appointment.cliente_nome,
    appointment.cliente_telefone,
    appointment.data_hora,
    appointment.data_hora_fim,
    appointment.status,
    employeeNameById.get(appointment.employee_id) ?? "",
    serviceNameById.get(appointment.service_id) ?? "",
    appointment.observacoes,
    appointment.created_at,
  ]);

  const pdfBytes = await generateReportPdf({
    title: "Relatorio de agendamentos",
    periodLabel: `${range.labelStart} a ${range.labelEnd}`,
    columns,
    rows,
  });
  const pdfArray = new Uint8Array(pdfBytes);
  const pdfBody = pdfArray.buffer.slice(pdfArray.byteOffset, pdfArray.byteOffset + pdfArray.byteLength);

  const fileName = `relatorio_agendamentos_${range.labelStart}_${range.labelEnd}.pdf`;

  return new Response(pdfBody, {
    status: 200,
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="${fileName}"`,
      "Cache-Control": "no-store",
    },
  });
}

```

### Arquivo: src/app/api/reports/appointments/route.ts
```
import { createSupabaseServerClient } from "@/lib/supabase/server";

type AppointmentStatus = "agendado" | "concluido" | "cancelado";

type AppointmentRow = {
  id: string;
  cliente_nome: string;
  cliente_telefone: string | null;
  data_hora: string;
  data_hora_fim: string | null;
  status: AppointmentStatus;
  observacoes: string | null;
  employee_id: string;
  service_id: string;
  created_at: string;
};

type EmployeeRow = {
  id: string;
  nome: string;
};

type ServiceRow = {
  id: string;
  nome: string;
};

function buildDateRange(url: URL) {
  const now = new Date();
  const startDefault = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
  const endDefault = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);

  const startInput = url.searchParams.get("start");
  const endInput = url.searchParams.get("end");

  const start = startInput && /^\d{4}-\d{2}-\d{2}$/.test(startInput) ? new Date(`${startInput}T00:00:00`) : startDefault;
  const end = endInput && /^\d{4}-\d{2}-\d{2}$/.test(endInput) ? new Date(`${endInput}T23:59:59.999`) : endDefault;

  return {
    startIso: start.toISOString(),
    endIso: end.toISOString(),
    labelStart: start.toISOString().slice(0, 10),
    labelEnd: end.toISOString().slice(0, 10),
  };
}

function csvCell(value: string | number | null | undefined): string {
  if (value === null || value === undefined) {
    return "\"\"";
  }

  const text = String(value).replaceAll("\"", "\"\"");
  return `\"${text}\"`;
}

function toCsv(headers: string[], rows: Array<Array<string | number | null | undefined>>): string {
  const headerLine = headers.map((header) => csvCell(header)).join(",");
  const bodyLines = rows.map((row) => row.map((cell) => csvCell(cell)).join(","));
  return `\uFEFF${[headerLine, ...bodyLines].join("\n")}`;
}

export async function GET(request: Request) {
  const url = new URL(request.url);
  const range = buildDateRange(url);

  const supabase = await createSupabaseServerClient();
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser();

  if (userError || !user) {
    return Response.json({ error: "Nao autenticado." }, { status: 401 });
  }

  const { data: companyId, error: companyError } = await supabase.rpc("current_company_id");

  if (companyError || !companyId) {
    return Response.json({ error: "Empresa nao encontrada para este usuario." }, { status: 400 });
  }

  const { data: appointmentsData, error: appointmentsError } = await supabase
    .from("appointments")
    .select("id, cliente_nome, cliente_telefone, data_hora, data_hora_fim, status, observacoes, employee_id, service_id, created_at")
    .eq("company_id", companyId)
    .gte("data_hora", range.startIso)
    .lte("data_hora", range.endIso)
    .order("data_hora", { ascending: true });

  if (appointmentsError) {
    return Response.json({ error: `Erro ao gerar relatorio: ${appointmentsError.message}` }, { status: 500 });
  }

  const appointments = (appointmentsData ?? []) as AppointmentRow[];
  const employeeIds = [...new Set(appointments.map((item) => item.employee_id).filter(Boolean))];
  const serviceIds = [...new Set(appointments.map((item) => item.service_id).filter(Boolean))];

  const [employeesResponse, servicesResponse] = await Promise.all([
    employeeIds.length > 0
      ? supabase.from("employees").select("id, nome").eq("company_id", companyId).in("id", employeeIds)
      : Promise.resolve({ data: [] as EmployeeRow[], error: null }),
    serviceIds.length > 0
      ? supabase.from("services").select("id, nome").eq("company_id", companyId).in("id", serviceIds)
      : Promise.resolve({ data: [] as ServiceRow[], error: null }),
  ]);

  if (employeesResponse.error || servicesResponse.error) {
    return Response.json({ error: "Erro ao carregar referencias para o relatorio." }, { status: 500 });
  }

  const employees = (employeesResponse.data ?? []) as EmployeeRow[];
  const services = (servicesResponse.data ?? []) as ServiceRow[];

  const employeeNameById = new Map(employees.map((employee) => [employee.id, employee.nome]));
  const serviceNameById = new Map(services.map((service) => [service.id, service.nome]));

  const csv = toCsv(
    [
      "id",
      "cliente_nome",
      "cliente_telefone",
      "data_hora",
      "data_hora_fim",
      "status",
      "funcionario",
      "servico",
      "observacoes",
      "created_at",
    ],
    appointments.map((appointment) => [
      appointment.id,
      appointment.cliente_nome,
      appointment.cliente_telefone,
      appointment.data_hora,
      appointment.data_hora_fim,
      appointment.status,
      employeeNameById.get(appointment.employee_id) ?? "",
      serviceNameById.get(appointment.service_id) ?? "",
      appointment.observacoes,
      appointment.created_at,
    ]),
  );

  const fileName = `relatorio_agendamentos_${range.labelStart}_${range.labelEnd}.csv`;

  return new Response(csv, {
    status: 200,
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${fileName}"`,
      "Cache-Control": "no-store",
    },
  });
}

```

### Arquivo: src/app/api/reports/auditoria/pdf/route.ts
```
import { canPerformAction, getAccessContext } from "@/lib/auth/access";
import { generateReportPdf } from "@/lib/reports/pdf";

type AuditRow = {
  id: string;
  actor_id: string | null;
  action: string;
  entity: string;
  entity_id: string | null;
  metadata: Record<string, unknown>;
  created_at: string;
};

type ProfileRow = {
  id: string;
  nome: string;
  email: string;
};

function sanitizeText(value: string | null): string {
  return (value ?? "").trim();
}

function normalizeDate(value: string, fallback: string): string {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    return fallback;
  }

  return value;
}

function toDateInputValue(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function formatMetadata(metadata: Record<string, unknown>): string {
  try {
    return JSON.stringify(metadata);
  } catch {
    return "{}";
  }
}

export async function GET(request: Request) {
  const { supabase, companyId, role, errorMessage } = await getAccessContext();

  if (!companyId || !role) {
    return Response.json({ error: errorMessage ?? "Nao autenticado." }, { status: 401 });
  }

  if (!canPerformAction(role, "auditoria", "export")) {
    return Response.json({ error: "Sem permissao para exportar auditoria." }, { status: 403 });
  }

  const url = new URL(request.url);
  const now = new Date();
  const defaultFrom = toDateInputValue(new Date(now.getFullYear(), now.getMonth(), now.getDate() - 30));
  const defaultTo = toDateInputValue(now);

  const fromInput = normalizeDate(sanitizeText(url.searchParams.get("from")), defaultFrom);
  const toInput = normalizeDate(sanitizeText(url.searchParams.get("to")), defaultTo);
  const actionInput = sanitizeText(url.searchParams.get("action"));
  const entityInput = sanitizeText(url.searchParams.get("entity"));
  const queryInput = sanitizeText(url.searchParams.get("q")).toLowerCase();

  const fromIso = new Date(`${fromInput}T00:00:00`).toISOString();
  const toIso = new Date(`${toInput}T23:59:59.999`).toISOString();

  let logsQuery = supabase
    .from("audit_logs")
    .select("id, actor_id, action, entity, entity_id, metadata, created_at")
    .eq("company_id", companyId)
    .gte("created_at", fromIso)
    .lte("created_at", toIso)
    .order("created_at", { ascending: false })
    .limit(5000);

  if (actionInput) {
    logsQuery = logsQuery.eq("action", actionInput);
  }

  if (entityInput) {
    logsQuery = logsQuery.eq("entity", entityInput);
  }

  const logsResponse = await logsQuery;

  if (logsResponse.error) {
    return Response.json({ error: `Nao foi possivel exportar auditoria: ${logsResponse.error.message}` }, { status: 500 });
  }

  const logs = (logsResponse.data ?? []) as AuditRow[];
  const actorIds = [...new Set(logs.map((item) => item.actor_id).filter(Boolean))] as string[];

  const profilesResponse =
    actorIds.length > 0
      ? await supabase.from("profiles").select("id, nome, email").eq("company_id", companyId).in("id", actorIds)
      : { data: [] as ProfileRow[], error: null };

  if (profilesResponse.error) {
    return Response.json({ error: "Nao foi possivel carregar atores da auditoria." }, { status: 500 });
  }

  const profiles = (profilesResponse.data ?? []) as ProfileRow[];
  const profileById = new Map(profiles.map((profile) => [profile.id, profile]));

  const filteredLogs = queryInput
    ? logs.filter((log) => {
        const actor = log.actor_id ? profileById.get(log.actor_id) : null;
        const searchStack = [
          log.action,
          log.entity,
          log.entity_id ?? "",
          formatMetadata(log.metadata),
          actor?.nome ?? "",
          actor?.email ?? "",
        ]
          .join(" ")
          .toLowerCase();

        return searchStack.includes(queryInput);
      })
    : logs;

  const rows = filteredLogs.map((log) => {
    const actor = log.actor_id ? profileById.get(log.actor_id) : null;

    return [
      log.id,
      log.created_at,
      log.action,
      log.entity,
      log.entity_id,
      actor?.nome ?? "",
      actor?.email ?? "",
      formatMetadata(log.metadata),
    ];
  });

  const pdfBytes = await generateReportPdf({
    title: "Relatorio de auditoria",
    periodLabel: `${fromInput} a ${toInput}`,
    columns: ["id", "created_at", "action", "entity", "entity_id", "actor_nome", "actor_email", "metadata"],
    rows,
  });
  const pdfArray = new Uint8Array(pdfBytes);
  const pdfBody = pdfArray.buffer.slice(pdfArray.byteOffset, pdfArray.byteOffset + pdfArray.byteLength);

  const fileName = `auditoria_${fromInput}_${toInput}.pdf`;

  return new Response(pdfBody, {
    status: 200,
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="${fileName}"`,
      "Cache-Control": "no-store",
    },
  });
}

```

### Arquivo: src/app/api/reports/auditoria/route.ts
```
import { canPerformAction, getAccessContext } from "@/lib/auth/access";

type AuditRow = {
  id: string;
  actor_id: string | null;
  action: string;
  entity: string;
  entity_id: string | null;
  metadata: Record<string, unknown>;
  created_at: string;
};

type ProfileRow = {
  id: string;
  nome: string;
  email: string;
};

function sanitizeText(value: string | null): string {
  return (value ?? "").trim();
}

function normalizeDate(value: string, fallback: string): string {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    return fallback;
  }

  return value;
}

function toDateInputValue(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function formatMetadata(metadata: Record<string, unknown>): string {
  try {
    return JSON.stringify(metadata);
  } catch {
    return "{}";
  }
}

function csvCell(value: string | number | null | undefined): string {
  if (value === null || value === undefined) {
    return "\"\"";
  }

  const text = String(value).replaceAll("\"", "\"\"");
  return `\"${text}\"`;
}

function toCsv(headers: string[], rows: Array<Array<string | number | null | undefined>>): string {
  const headerLine = headers.map((header) => csvCell(header)).join(",");
  const bodyLines = rows.map((row) => row.map((cell) => csvCell(cell)).join(","));
  return `\uFEFF${[headerLine, ...bodyLines].join("\n")}`;
}

export async function GET(request: Request) {
  const { supabase, companyId, role, errorMessage } = await getAccessContext();

  if (!companyId || !role) {
    return Response.json({ error: errorMessage ?? "Nao autenticado." }, { status: 401 });
  }

  if (!canPerformAction(role, "auditoria", "export")) {
    return Response.json({ error: "Sem permissao para exportar auditoria." }, { status: 403 });
  }

  const url = new URL(request.url);
  const now = new Date();
  const defaultFrom = toDateInputValue(new Date(now.getFullYear(), now.getMonth(), now.getDate() - 30));
  const defaultTo = toDateInputValue(now);

  const fromInput = normalizeDate(sanitizeText(url.searchParams.get("from")), defaultFrom);
  const toInput = normalizeDate(sanitizeText(url.searchParams.get("to")), defaultTo);
  const actionInput = sanitizeText(url.searchParams.get("action"));
  const entityInput = sanitizeText(url.searchParams.get("entity"));
  const queryInput = sanitizeText(url.searchParams.get("q")).toLowerCase();

  const fromIso = new Date(`${fromInput}T00:00:00`).toISOString();
  const toIso = new Date(`${toInput}T23:59:59.999`).toISOString();

  let logsQuery = supabase
    .from("audit_logs")
    .select("id, actor_id, action, entity, entity_id, metadata, created_at")
    .eq("company_id", companyId)
    .gte("created_at", fromIso)
    .lte("created_at", toIso)
    .order("created_at", { ascending: false })
    .limit(5000);

  if (actionInput) {
    logsQuery = logsQuery.eq("action", actionInput);
  }

  if (entityInput) {
    logsQuery = logsQuery.eq("entity", entityInput);
  }

  const logsResponse = await logsQuery;

  if (logsResponse.error) {
    return Response.json({ error: `Nao foi possivel exportar auditoria: ${logsResponse.error.message}` }, { status: 500 });
  }

  const logs = (logsResponse.data ?? []) as AuditRow[];
  const actorIds = [...new Set(logs.map((item) => item.actor_id).filter(Boolean))] as string[];

  const profilesResponse =
    actorIds.length > 0
      ? await supabase.from("profiles").select("id, nome, email").eq("company_id", companyId).in("id", actorIds)
      : { data: [] as ProfileRow[], error: null };

  if (profilesResponse.error) {
    return Response.json({ error: "Nao foi possivel carregar atores da auditoria." }, { status: 500 });
  }

  const profiles = (profilesResponse.data ?? []) as ProfileRow[];
  const profileById = new Map(profiles.map((profile) => [profile.id, profile]));

  const filteredLogs = queryInput
    ? logs.filter((log) => {
        const actor = log.actor_id ? profileById.get(log.actor_id) : null;
        const searchStack = [
          log.action,
          log.entity,
          log.entity_id ?? "",
          formatMetadata(log.metadata),
          actor?.nome ?? "",
          actor?.email ?? "",
        ]
          .join(" ")
          .toLowerCase();

        return searchStack.includes(queryInput);
      })
    : logs;

  const csv = toCsv(
    ["id", "created_at", "action", "entity", "entity_id", "actor_nome", "actor_email", "metadata"],
    filteredLogs.map((log) => {
      const actor = log.actor_id ? profileById.get(log.actor_id) : null;

      return [
        log.id,
        log.created_at,
        log.action,
        log.entity,
        log.entity_id,
        actor?.nome ?? "",
        actor?.email ?? "",
        formatMetadata(log.metadata),
      ];
    }),
  );

  const fileName = `auditoria_${fromInput}_${toInput}.csv`;

  return new Response(csv, {
    status: 200,
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${fileName}"`,
      "Cache-Control": "no-store",
    },
  });
}

```

### Arquivo: src/app/api/reports/payments/pdf/route.ts
```
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { generateReportPdf } from "@/lib/reports/pdf";

type PaymentRow = {
  id: string;
  appointment_id: string;
  valor: number;
  forma_pagamento: string;
  percentual_comissao: number;
  valor_comissao: number;
  created_at: string;
};

type AppointmentRow = {
  id: string;
  cliente_nome: string;
  data_hora: string;
};

function buildDateRange(url: URL) {
  const now = new Date();
  const startDefault = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
  const endDefault = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);

  const startInput = url.searchParams.get("start");
  const endInput = url.searchParams.get("end");

  const start = startInput && /^\d{4}-\d{2}-\d{2}$/.test(startInput) ? new Date(`${startInput}T00:00:00`) : startDefault;
  const end = endInput && /^\d{4}-\d{2}-\d{2}$/.test(endInput) ? new Date(`${endInput}T23:59:59.999`) : endDefault;

  return {
    startIso: start.toISOString(),
    endIso: end.toISOString(),
    labelStart: start.toISOString().slice(0, 10),
    labelEnd: end.toISOString().slice(0, 10),
  };
}

export async function GET(request: Request) {
  const url = new URL(request.url);
  const range = buildDateRange(url);

  const supabase = await createSupabaseServerClient();
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser();

  if (userError || !user) {
    return Response.json({ error: "Nao autenticado." }, { status: 401 });
  }

  const { data: companyId, error: companyError } = await supabase.rpc("current_company_id");

  if (companyError || !companyId) {
    return Response.json({ error: "Empresa nao encontrada para este usuario." }, { status: 400 });
  }

  const { data: paymentsData, error: paymentsError } = await supabase
    .from("payments")
    .select("id, appointment_id, valor, forma_pagamento, percentual_comissao, valor_comissao, created_at")
    .eq("company_id", companyId)
    .gte("created_at", range.startIso)
    .lte("created_at", range.endIso)
    .order("created_at", { ascending: true });

  if (paymentsError) {
    return Response.json({ error: `Erro ao gerar relatorio: ${paymentsError.message}` }, { status: 500 });
  }

  const payments = (paymentsData ?? []) as PaymentRow[];
  const appointmentIds = [...new Set(payments.map((item) => item.appointment_id).filter(Boolean))];

  const appointmentsResponse =
    appointmentIds.length > 0
      ? await supabase
          .from("appointments")
          .select("id, cliente_nome, data_hora")
          .eq("company_id", companyId)
          .in("id", appointmentIds)
      : { data: [] as AppointmentRow[], error: null };

  if (appointmentsResponse.error) {
    return Response.json({ error: "Erro ao carregar dados de agendamento para o relatorio." }, { status: 500 });
  }

  const appointments = (appointmentsResponse.data ?? []) as AppointmentRow[];
  const appointmentById = new Map(appointments.map((appointment) => [appointment.id, appointment]));

  const columns = [
    "id",
    "appointment_id",
    "cliente_nome",
    "data_hora_agendamento",
    "valor",
    "forma_pagamento",
    "percentual_comissao",
    "valor_comissao",
    "created_at",
  ];

  const rows = payments.map((payment) => {
    const appointment = appointmentById.get(payment.appointment_id);

    return [
      payment.id,
      payment.appointment_id,
      appointment?.cliente_nome ?? "",
      appointment?.data_hora ?? "",
      payment.valor,
      payment.forma_pagamento,
      payment.percentual_comissao,
      payment.valor_comissao,
      payment.created_at,
    ];
  });

  const pdfBytes = await generateReportPdf({
    title: "Relatorio financeiro",
    periodLabel: `${range.labelStart} a ${range.labelEnd}`,
    columns,
    rows,
  });
  const pdfArray = new Uint8Array(pdfBytes);
  const pdfBody = pdfArray.buffer.slice(pdfArray.byteOffset, pdfArray.byteOffset + pdfArray.byteLength);

  const fileName = `relatorio_financeiro_${range.labelStart}_${range.labelEnd}.pdf`;

  return new Response(pdfBody, {
    status: 200,
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="${fileName}"`,
      "Cache-Control": "no-store",
    },
  });
}

```

### Arquivo: src/app/api/reports/payments/route.ts
```
import { createSupabaseServerClient } from "@/lib/supabase/server";

type PaymentRow = {
  id: string;
  appointment_id: string;
  valor: number;
  forma_pagamento: string;
  percentual_comissao: number;
  valor_comissao: number;
  created_at: string;
};

type AppointmentRow = {
  id: string;
  cliente_nome: string;
  data_hora: string;
};

function buildDateRange(url: URL) {
  const now = new Date();
  const startDefault = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
  const endDefault = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);

  const startInput = url.searchParams.get("start");
  const endInput = url.searchParams.get("end");

  const start = startInput && /^\d{4}-\d{2}-\d{2}$/.test(startInput) ? new Date(`${startInput}T00:00:00`) : startDefault;
  const end = endInput && /^\d{4}-\d{2}-\d{2}$/.test(endInput) ? new Date(`${endInput}T23:59:59.999`) : endDefault;

  return {
    startIso: start.toISOString(),
    endIso: end.toISOString(),
    labelStart: start.toISOString().slice(0, 10),
    labelEnd: end.toISOString().slice(0, 10),
  };
}

function csvCell(value: string | number | null | undefined): string {
  if (value === null || value === undefined) {
    return "\"\"";
  }

  const text = String(value).replaceAll("\"", "\"\"");
  return `\"${text}\"`;
}

function toCsv(headers: string[], rows: Array<Array<string | number | null | undefined>>): string {
  const headerLine = headers.map((header) => csvCell(header)).join(",");
  const bodyLines = rows.map((row) => row.map((cell) => csvCell(cell)).join(","));
  return `\uFEFF${[headerLine, ...bodyLines].join("\n")}`;
}

export async function GET(request: Request) {
  const url = new URL(request.url);
  const range = buildDateRange(url);

  const supabase = await createSupabaseServerClient();
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser();

  if (userError || !user) {
    return Response.json({ error: "Nao autenticado." }, { status: 401 });
  }

  const { data: companyId, error: companyError } = await supabase.rpc("current_company_id");

  if (companyError || !companyId) {
    return Response.json({ error: "Empresa nao encontrada para este usuario." }, { status: 400 });
  }

  const { data: paymentsData, error: paymentsError } = await supabase
    .from("payments")
    .select("id, appointment_id, valor, forma_pagamento, percentual_comissao, valor_comissao, created_at")
    .eq("company_id", companyId)
    .gte("created_at", range.startIso)
    .lte("created_at", range.endIso)
    .order("created_at", { ascending: true });

  if (paymentsError) {
    return Response.json({ error: `Erro ao gerar relatorio: ${paymentsError.message}` }, { status: 500 });
  }

  const payments = (paymentsData ?? []) as PaymentRow[];
  const appointmentIds = [...new Set(payments.map((item) => item.appointment_id).filter(Boolean))];

  const appointmentsResponse =
    appointmentIds.length > 0
      ? await supabase
          .from("appointments")
          .select("id, cliente_nome, data_hora")
          .eq("company_id", companyId)
          .in("id", appointmentIds)
      : { data: [] as AppointmentRow[], error: null };

  if (appointmentsResponse.error) {
    return Response.json({ error: "Erro ao carregar dados de agendamento para o relatorio." }, { status: 500 });
  }

  const appointments = (appointmentsResponse.data ?? []) as AppointmentRow[];
  const appointmentById = new Map(appointments.map((appointment) => [appointment.id, appointment]));

  const csv = toCsv(
    [
      "id",
      "appointment_id",
      "cliente_nome",
      "data_hora_agendamento",
      "valor",
      "forma_pagamento",
      "percentual_comissao",
      "valor_comissao",
      "created_at",
    ],
    payments.map((payment) => {
      const appointment = appointmentById.get(payment.appointment_id);

      return [
        payment.id,
        payment.appointment_id,
        appointment?.cliente_nome ?? "",
        appointment?.data_hora ?? "",
        payment.valor,
        payment.forma_pagamento,
        payment.percentual_comissao,
        payment.valor_comissao,
        payment.created_at,
      ];
    }),
  );

  const fileName = `relatorio_financeiro_${range.labelStart}_${range.labelEnd}.csv`;

  return new Response(csv, {
    status: 200,
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${fileName}"`,
      "Cache-Control": "no-store",
    },
  });
}

```

### Arquivo: src/app/api/test-supabase/route.ts
```
import { NextResponse } from "next/server";

import { createSupabaseServerClient } from "@/lib/supabase/server";
import { getSupabaseEnv } from "@/lib/supabase/env";

export async function GET() {
  try {
    const { supabaseAnonKey, supabaseUrl } = getSupabaseEnv();
    const normalizedSupabaseUrl = supabaseUrl.replace(/\/$/, "");

    const supabase = await createSupabaseServerClient();
    const authHealth = await supabase.auth.getSession();

    if (authHealth.error) {
      return NextResponse.json(
        {
          ok: false,
          mensagem: "Conexao com Supabase Auth falhou.",
          erro: authHealth.error.message,
        },
        { status: 500 },
      );
    }

    // O endpoint raiz do PostgREST pode responder 404 em alguns cenarios.
    // Isso nao significa necessariamente falta de conectividade.
    const restResponse = await fetch(`${normalizedSupabaseUrl}/rest/v1/`, {
      method: "GET",
      headers: {
        apikey: supabaseAnonKey,
        Authorization: `Bearer ${supabaseAnonKey}`,
        Accept: "application/openapi+json",
      },
      cache: "no-store",
    });

    const postgrestReachable =
      restResponse.status === 200 ||
      restResponse.status === 401 ||
      restResponse.status === 403 ||
      restResponse.status === 404;

    if (!postgrestReachable) {
      return NextResponse.json(
        {
          ok: false,
          mensagem: "Conexao com API de banco (PostgREST) falhou.",
          status_http: restResponse.status,
        },
        { status: 500 },
      );
    }

    return NextResponse.json({
      ok: true,
      mensagem: "Conexao com Supabase validada com sucesso.",
      detalhes: {
        auth: "ok",
        postgrest: {
          status_http: restResponse.status,
          observacao:
            restResponse.status === 404
              ? "Endpoint raiz do PostgREST respondeu 404, mas o servico esta acessivel."
              : "Servico PostgREST acessivel.",
        },
      },
    });
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        mensagem: "Erro inesperado ao testar conexao com Supabase.",
        erro: error instanceof Error ? error.message : "Erro desconhecido.",
      },
      { status: 500 },
    );
  }
}

```

### Arquivo: src/app/auth/atualizar-senha/page.tsx
```
"use client";

import { type FormEvent, useState } from "react";
import { useRouter } from "next/navigation";

import { Button } from "@/components/ui/button";
import { createSupabaseBrowserClient } from "@/lib/supabase/client";

type PasswordFormErrors = {
  password?: string;
  confirmPassword?: string;
  form?: string;
};

function validatePassword(password: string, confirmPassword: string): PasswordFormErrors {
  const errors: PasswordFormErrors = {};

  if (!password.trim()) {
    errors.password = "Informe a nova senha.";
  } else if (password.length < 6) {
    errors.password = "A senha deve ter pelo menos 6 caracteres.";
  }

  if (!confirmPassword.trim()) {
    errors.confirmPassword = "Confirme a nova senha.";
  } else if (confirmPassword !== password) {
    errors.confirmPassword = "As senhas nao conferem.";
  }

  return errors;
}

export default function AtualizarSenhaPage() {
  const router = useRouter();

  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [errors, setErrors] = useState<PasswordFormErrors>({});
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const validationErrors = validatePassword(password, confirmPassword);

    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    setErrors({});
    setSuccessMessage(null);
    setIsSubmitting(true);

    try {
      const supabase = createSupabaseBrowserClient();
      const { error } = await supabase.auth.updateUser({ password });

      if (error) {
        setErrors({ form: `Nao foi possivel atualizar a senha: ${error.message}` });
        return;
      }

      setSuccessMessage("Senha atualizada com sucesso. Redirecionando para o login...");
      setTimeout(() => {
        router.replace("/login");
        router.refresh();
      }, 1200);
    } catch {
      setErrors({ form: "Ocorreu um erro inesperado ao atualizar sua senha." });
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <main className="relative flex min-h-screen items-center justify-center overflow-hidden bg-zinc-950 px-4 py-8">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top,_rgba(251,191,36,0.25),_transparent_45%),radial-gradient(circle_at_bottom,_rgba(255,255,255,0.08),_transparent_40%)]" />

      <section className="relative z-10 w-full max-w-md rounded-2xl border border-amber-400/20 bg-zinc-900/85 p-6 shadow-2xl backdrop-blur sm:p-8">
        <div className="mb-6 space-y-2 text-center">
          <p className="text-xs font-semibold tracking-[0.22em] text-amber-300 uppercase">Recuperacao de senha</p>
          <h1 className="text-2xl font-semibold text-zinc-100">Defina sua nova senha</h1>
          <p className="text-sm text-zinc-300">Crie uma senha segura para voltar a acessar sua conta.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4" noValidate>
          <div className="space-y-2">
            <label htmlFor="password" className="block text-sm font-medium text-zinc-200">
              Nova senha
            </label>
            <div className="relative">
              <input
                id="password"
                name="password"
                type={showPassword ? "text" : "password"}
                autoComplete="new-password"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                className="h-11 w-full rounded-lg border border-zinc-700/80 bg-zinc-950/80 px-3 pr-24 text-sm text-zinc-100 outline-none transition focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20"
                placeholder="********"
                aria-invalid={Boolean(errors.password)}
              />
              <button
                type="button"
                onClick={() => setShowPassword((previous) => !previous)}
                className="absolute top-1/2 right-3 -translate-y-1/2 text-xs font-medium text-amber-300 hover:text-amber-200"
                aria-label={showPassword ? "Ocultar senha" : "Mostrar senha"}
              >
                {showPassword ? "Ocultar" : "Mostrar"}
              </button>
            </div>
            {errors.password ? <p className="text-sm text-amber-300">{errors.password}</p> : null}
          </div>

          <div className="space-y-2">
            <label htmlFor="confirm-password" className="block text-sm font-medium text-zinc-200">
              Confirmar nova senha
            </label>
            <div className="relative">
              <input
                id="confirm-password"
                name="confirmPassword"
                type={showConfirmPassword ? "text" : "password"}
                autoComplete="new-password"
                value={confirmPassword}
                onChange={(event) => setConfirmPassword(event.target.value)}
                className="h-11 w-full rounded-lg border border-zinc-700/80 bg-zinc-950/80 px-3 pr-24 text-sm text-zinc-100 outline-none transition focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20"
                placeholder="********"
                aria-invalid={Boolean(errors.confirmPassword)}
              />
              <button
                type="button"
                onClick={() => setShowConfirmPassword((previous) => !previous)}
                className="absolute top-1/2 right-3 -translate-y-1/2 text-xs font-medium text-amber-300 hover:text-amber-200"
                aria-label={showConfirmPassword ? "Ocultar confirmacao de senha" : "Mostrar confirmacao de senha"}
              >
                {showConfirmPassword ? "Ocultar" : "Mostrar"}
              </button>
            </div>
            {errors.confirmPassword ? <p className="text-sm text-amber-300">{errors.confirmPassword}</p> : null}
          </div>

          <Button
            type="submit"
            className="h-11 w-full bg-amber-400 text-zinc-950 hover:bg-amber-300"
            disabled={isSubmitting}
          >
            {isSubmitting ? "Atualizando..." : "Atualizar senha"}
          </Button>

          {errors.form ? <p className="text-sm text-amber-300">{errors.form}</p> : null}
          {successMessage ? <p className="text-sm text-emerald-300">{successMessage}</p> : null}
        </form>
      </section>
    </main>
  );
}

```

### Arquivo: src/app/auth/confirm/route.ts
```
import { NextResponse } from "next/server";

import { createSupabaseServerClient } from "@/lib/supabase/server";

function getSafeNextPath(rawNext: string | null) {
  if (!rawNext) {
    return "/login";
  }

  return rawNext.startsWith("/") ? rawNext : "/login";
}

export async function GET(request: Request) {
  const requestUrl = new URL(request.url);
  const code = requestUrl.searchParams.get("code");
  const safeNext = getSafeNextPath(requestUrl.searchParams.get("next"));
  const redirectUrl = new URL(safeNext, requestUrl.origin);

  if (!code) {
    redirectUrl.searchParams.set("error", "confirmacao_falhou");
    return NextResponse.redirect(redirectUrl);
  }

  const supabase = await createSupabaseServerClient();
  const { error } = await supabase.auth.exchangeCodeForSession(code);

  if (error) {
    redirectUrl.searchParams.set("error", "confirmacao_falhou");
    return NextResponse.redirect(redirectUrl);
  }

  redirectUrl.searchParams.set("confirmed", "1");
  return NextResponse.redirect(redirectUrl);
}

```

### Arquivo: src/app/convites/[token]/actions.ts
```
"use server";

import { revalidatePath } from "next/cache";

import { createSupabaseServerClient } from "@/lib/supabase/server";
import { type UserRole } from "@/lib/auth/access";
import { notifySensitiveEvent } from "@/lib/notifications/sensitive-events";

type ActionState = {
  success: boolean;
  message: string;
};

type InviteStatus = "pending" | "accepted" | "revoked" | "expired";

type InviteRow = {
  id: string;
  company_id: string;
  email: string;
  role: UserRole;
  status: InviteStatus;
  token: string;
  expires_at: string;
};

function sanitizeText(value: FormDataEntryValue | null): string {
  if (typeof value !== "string") {
    return "";
  }

  return value.trim();
}

function mapInviteDatabaseError(message: string): string {
  if (message.includes("team_invites")) {
    return "Seu banco ainda nao foi atualizado para aceite de convites. Reexecute o script docs/database/003_etapa11_convites_auditoria.sql no Supabase SQL Editor e tente novamente.";
  }

  return message;
}

function deriveUserName(user: { email?: string | null; user_metadata?: Record<string, unknown> }): string {
  const metadata = user.user_metadata ?? {};
  const candidates = [
    metadata.full_name,
    metadata.name,
    metadata.nome,
  ];

  for (const candidate of candidates) {
    if (typeof candidate === "string" && candidate.trim().length >= 2) {
      return candidate.trim();
    }
  }

  const email = (user.email ?? "").trim();
  const beforeAt = email.includes("@") ? email.split("@")[0] : email;

  if (beforeAt.length >= 2) {
    return beforeAt;
  }

  return "Novo membro";
}

export async function acceptTeamInviteAction(_prevState: ActionState, formData: FormData): Promise<ActionState> {
  const token = sanitizeText(formData.get("token"));

  if (!token) {
    return { success: false, message: "Token de convite invalido." };
  }

  const supabase = await createSupabaseServerClient();
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser();

  if (userError || !user) {
    return { success: false, message: "Sua sessao expirou. Faca login novamente para aceitar o convite." };
  }

  const userEmail = (user.email ?? "").toLowerCase();

  if (!userEmail) {
    return { success: false, message: "Sua conta nao possui e-mail valido para aceitar convite." };
  }

  const { data: invite, error: inviteError } = await supabase
    .from("team_invites")
    .select("id, company_id, email, role, status, token, expires_at")
    .eq("token", token)
    .maybeSingle();

  if (inviteError) {
    return { success: false, message: `Nao foi possivel validar convite: ${mapInviteDatabaseError(inviteError.message)}` };
  }

  if (!invite) {
    return { success: false, message: "Convite nao encontrado ou indisponivel para sua conta." };
  }

  const inviteRow = invite as InviteRow;

  if (inviteRow.email !== userEmail) {
    return { success: false, message: "Este convite foi enviado para outro e-mail." };
  }

  if (inviteRow.status === "accepted") {
    return { success: true, message: "Convite ja foi aceito anteriormente." };
  }

  if (inviteRow.status === "revoked") {
    return { success: false, message: "Este convite foi revogado pelo administrador." };
  }

  const expiresAt = new Date(inviteRow.expires_at);

  if (Number.isNaN(expiresAt.getTime()) || expiresAt.getTime() < Date.now()) {
    await supabase.from("team_invites").update({ status: "expired" }).eq("id", inviteRow.id).eq("status", "pending");
    return { success: false, message: "Este convite expirou. Solicite um novo convite ao administrador." };
  }

  const { data: existingProfile } = await supabase.from("profiles").select("id, company_id").eq("id", user.id).maybeSingle();

  if (existingProfile && existingProfile.company_id !== inviteRow.company_id) {
    return {
      success: false,
      message: "Sua conta ja esta vinculada a outra empresa. Use outro usuario para aceitar este convite.",
    };
  }

  if (!existingProfile) {
    const { error: createProfileError } = await supabase.from("profiles").insert({
      id: user.id,
      company_id: inviteRow.company_id,
      nome: deriveUserName(user),
      email: userEmail,
      role: inviteRow.role,
    });

    if (createProfileError) {
      return {
        success: false,
        message: `Nao foi possivel criar seu perfil na empresa: ${createProfileError.message}`,
      };
    }
  } else {
    const { error: updateRoleError } = await supabase
      .from("profiles")
      .update({ role: inviteRow.role })
      .eq("id", user.id)
      .eq("company_id", inviteRow.company_id);

    if (updateRoleError) {
      return { success: false, message: `Nao foi possivel atualizar seu papel: ${updateRoleError.message}` };
    }
  }

  const { error: acceptError } = await supabase
    .from("team_invites")
    .update({
      status: "accepted",
      accepted_by: user.id,
      accepted_at: new Date().toISOString(),
    })
    .eq("id", inviteRow.id)
    .eq("status", "pending");

  if (acceptError) {
    return {
      success: false,
      message: `Nao foi possivel concluir aceite do convite: ${mapInviteDatabaseError(acceptError.message)}`,
    };
  }

  await supabase.from("audit_logs").insert({
    company_id: inviteRow.company_id,
    actor_id: user.id,
    action: "team_invite_accepted",
    entity: "team_invites",
    entity_id: inviteRow.id,
    metadata: {
      email: userEmail,
      role: inviteRow.role,
    },
  });

  await notifySensitiveEvent({
    supabase,
    companyId: inviteRow.company_id,
    actorId: user.id,
    eventKey: "team_invite_accepted",
    title: "Convite de equipe aceito",
    message: `${userEmail} aceitou convite e entrou na equipe.`,
    severity: "info",
    metadata: {
      inviteId: inviteRow.id,
      email: userEmail,
      role: inviteRow.role,
    },
  });

  revalidatePath("/painel");
  revalidatePath("/painel/equipe");
  return { success: true, message: "Convite aceito com sucesso. Seu acesso foi liberado no painel." };
}

```

### Arquivo: src/app/convites/[token]/page.tsx
```
import Link from "next/link";
import { redirect } from "next/navigation";

import { AcceptTeamInviteForm } from "@/components/invites/accept-team-invite-form";
import { createSupabaseServerClient } from "@/lib/supabase/server";

type InviteStatus = "pending" | "accepted" | "revoked" | "expired";

type InvitePreview = {
  email: string;
  role: "admin" | "employee";
  status: InviteStatus;
  expires_at: string;
  companies: { nome: string } | null;
};

function formatDate(value: string): string {
  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return value;
  }

  return new Intl.DateTimeFormat("pt-BR", {
    dateStyle: "short",
    timeStyle: "short",
  }).format(date);
}

export default async function InviteTokenPage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const supabase = await createSupabaseServerClient();
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser();

  if (userError || !user) {
    redirect(`/login?next=/convites/${token}`);
  }

  const inviteResponse = await supabase
    .from("team_invites")
    .select("email, role, status, expires_at, companies(nome)")
    .eq("token", token)
    .maybeSingle();

  const invite = (inviteResponse.data ?? null) as InvitePreview | null;
  const hasInviteTableIssue = Boolean(inviteResponse.error?.message.includes("team_invites"));

  return (
    <main className="relative flex min-h-screen items-center justify-center overflow-hidden bg-zinc-950 px-4 py-8">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top,_rgba(251,191,36,0.22),_transparent_45%),radial-gradient(circle_at_bottom,_rgba(255,255,255,0.08),_transparent_40%)]" />

      <section className="relative z-10 w-full max-w-xl rounded-2xl border border-amber-400/20 bg-zinc-900/85 p-6 shadow-2xl backdrop-blur sm:p-8">
        <h1 className="text-2xl font-semibold text-zinc-100">Aceitar convite</h1>
        <p className="mt-2 text-sm text-zinc-300">Confirme sua entrada para acessar o sistema da empresa convidante.</p>

        {hasInviteTableIssue ? (
          <p className="mt-4 rounded-lg border border-amber-500/40 bg-amber-600/10 p-4 text-sm text-amber-200">
            Convites ainda nao estao habilitados neste banco. Reexecute o script docs/database/003_etapa11_convites_auditoria.sql no Supabase SQL Editor.
          </p>
        ) : null}

        {invite ? (
          <div className="mt-4 space-y-2 rounded-lg border border-zinc-700/70 bg-zinc-950/70 p-4 text-sm">
            <p className="text-zinc-200">
              <span className="text-zinc-400">Empresa:</span> {invite.companies?.nome ?? "Empresa"}
            </p>
            <p className="text-zinc-200">
              <span className="text-zinc-400">Convidado:</span> {invite.email}
            </p>
            <p className="text-zinc-200">
              <span className="text-zinc-400">Papel:</span> {invite.role === "admin" ? "Administrador" : "Equipe"}
            </p>
            <p className="text-zinc-200">
              <span className="text-zinc-400">Status:</span> {invite.status}
            </p>
            <p className="text-zinc-200">
              <span className="text-zinc-400">Expira em:</span> {formatDate(invite.expires_at)}
            </p>
          </div>
        ) : (
          <p className="mt-4 rounded-lg border border-zinc-700/70 bg-zinc-950/70 p-4 text-sm text-zinc-300">
            Convite nao encontrado para este token.
          </p>
        )}

        <div className="mt-5">
          <AcceptTeamInviteForm token={token} />
        </div>

        <div className="mt-4">
          <Link
            href="/painel"
            className="text-sm text-zinc-300 underline decoration-zinc-600 underline-offset-4 hover:text-amber-300"
          >
            Voltar ao painel
          </Link>
        </div>
      </section>
    </main>
  );
}

```

### Arquivo: src/app/globals.css
```
@import "tailwindcss";
@import "tw-animate-css";
@import "shadcn/tailwind.css";

@custom-variant dark (&:is(.dark *));

@theme inline {
  --color-background: var(--background);
  --color-foreground: var(--foreground);
  --font-sans: var(--font-sans);
  --font-mono: var(--font-geist-mono);
  --font-heading: var(--font-sans);
  --color-sidebar-ring: var(--sidebar-ring);
  --color-sidebar-border: var(--sidebar-border);
  --color-sidebar-accent-foreground: var(--sidebar-accent-foreground);
  --color-sidebar-accent: var(--sidebar-accent);
  --color-sidebar-primary-foreground: var(--sidebar-primary-foreground);
  --color-sidebar-primary: var(--sidebar-primary);
  --color-sidebar-foreground: var(--sidebar-foreground);
  --color-sidebar: var(--sidebar);
  --color-chart-5: var(--chart-5);
  --color-chart-4: var(--chart-4);
  --color-chart-3: var(--chart-3);
  --color-chart-2: var(--chart-2);
  --color-chart-1: var(--chart-1);
  --color-ring: var(--ring);
  --color-input: var(--input);
  --color-border: var(--border);
  --color-destructive: var(--destructive);
  --color-accent-foreground: var(--accent-foreground);
  --color-accent: var(--accent);
  --color-muted-foreground: var(--muted-foreground);
  --color-muted: var(--muted);
  --color-secondary-foreground: var(--secondary-foreground);
  --color-secondary: var(--secondary);
  --color-primary-foreground: var(--primary-foreground);
  --color-primary: var(--primary);
  --color-popover-foreground: var(--popover-foreground);
  --color-popover: var(--popover);
  --color-card-foreground: var(--card-foreground);
  --color-card: var(--card);
  --radius-sm: calc(var(--radius) * 0.6);
  --radius-md: calc(var(--radius) * 0.8);
  --radius-lg: var(--radius);
  --radius-xl: calc(var(--radius) * 1.4);
  --radius-2xl: calc(var(--radius) * 1.8);
  --radius-3xl: calc(var(--radius) * 2.2);
  --radius-4xl: calc(var(--radius) * 2.6);
}

:root {
  --background: oklch(0.12 0.03 282);
  --foreground: oklch(0.97 0.01 286);
  --card: oklch(0.18 0.03 282);
  --card-foreground: oklch(0.97 0.01 286);
  --popover: oklch(0.2 0.03 282);
  --popover-foreground: oklch(0.97 0.01 286);
  --primary: oklch(0.76 0.22 345);
  --primary-foreground: oklch(0.99 0.01 286);
  --secondary: oklch(0.27 0.04 282);
  --secondary-foreground: oklch(0.97 0.01 286);
  --muted: oklch(0.24 0.03 282);
  --muted-foreground: oklch(0.78 0.03 286);
  --accent: oklch(0.74 0.18 210);
  --accent-foreground: oklch(0.99 0.01 286);
  --destructive: oklch(0.577 0.245 27.325);
  --border: oklch(0.38 0.06 286);
  --input: oklch(0.3 0.05 286);
  --ring: oklch(0.74 0.18 210);
  --chart-1: oklch(0.87 0 0);
  --chart-2: oklch(0.556 0 0);
  --chart-3: oklch(0.439 0 0);
  --chart-4: oklch(0.371 0 0);
  --chart-5: oklch(0.269 0 0);
  --radius: 0.625rem;
  --sidebar: oklch(0.985 0 0);
  --sidebar-foreground: oklch(0.145 0 0);
  --sidebar-primary: oklch(0.205 0 0);
  --sidebar-primary-foreground: oklch(0.985 0 0);
  --sidebar-accent: oklch(0.97 0 0);
  --sidebar-accent-foreground: oklch(0.205 0 0);
  --sidebar-border: oklch(0.922 0 0);
  --sidebar-ring: oklch(0.708 0 0);
}

.dark {
  --background: oklch(0.12 0.03 282);
  --foreground: oklch(0.985 0.01 286);
  --card: oklch(0.18 0.03 282);
  --card-foreground: oklch(0.985 0.01 286);
  --popover: oklch(0.2 0.03 282);
  --popover-foreground: oklch(0.985 0.01 286);
  --primary: oklch(0.76 0.22 345);
  --primary-foreground: oklch(0.99 0.01 286);
  --secondary: oklch(0.27 0.04 282);
  --secondary-foreground: oklch(0.985 0.01 286);
  --muted: oklch(0.24 0.03 282);
  --muted-foreground: oklch(0.78 0.03 286);
  --accent: oklch(0.74 0.18 210);
  --accent-foreground: oklch(0.99 0.01 286);
  --destructive: oklch(0.704 0.191 22.216);
  --border: oklch(0.38 0.06 286);
  --input: oklch(0.3 0.05 286);
  --ring: oklch(0.74 0.18 210);
  --chart-1: oklch(0.87 0 0);
  --chart-2: oklch(0.556 0 0);
  --chart-3: oklch(0.439 0 0);
  --chart-4: oklch(0.371 0 0);
  --chart-5: oklch(0.269 0 0);
  --sidebar: oklch(0.205 0 0);
  --sidebar-foreground: oklch(0.985 0 0);
  --sidebar-primary: oklch(0.488 0.243 264.376);
  --sidebar-primary-foreground: oklch(0.985 0 0);
  --sidebar-accent: oklch(0.269 0 0);
  --sidebar-accent-foreground: oklch(0.985 0 0);
  --sidebar-border: oklch(1 0 0 / 10%);
  --sidebar-ring: oklch(0.556 0 0);
}

@layer base {
  * {
    @apply border-border outline-ring/50;
  }
  body {
    @apply bg-background text-foreground;
  }
  html {
    @apply font-sans;
  }
}

@layer base {
  body {
    position: relative;
    isolation: isolate;
  }

  body::before {
    content: "";
    position: fixed;
    inset: 0;
    z-index: -2;
    background:
      radial-gradient(circle at 12% 8%, oklch(0.74 0.23 345 / 0.28), transparent 36%),
      radial-gradient(circle at 86% 14%, oklch(0.74 0.2 210 / 0.24), transparent 32%),
      radial-gradient(circle at 50% 92%, oklch(0.68 0.18 292 / 0.24), transparent 42%),
      linear-gradient(155deg, oklch(0.13 0.03 282), oklch(0.1 0.03 278));
  }

  body::after {
    content: "";
    position: fixed;
    inset: 0;
    z-index: -1;
    opacity: 0.32;
    background-image: linear-gradient(120deg, transparent 0%, oklch(0.84 0.15 210 / 0.14) 42%, transparent 84%);
    transform: translateX(-18%);
    animation: shimmer-pan 16s ease-in-out infinite;
    pointer-events: none;
  }
}

@keyframes shimmer-pan {
  0%,
  100% {
    transform: translateX(-18%);
  }
  50% {
    transform: translateX(12%);
  }
}
```

### Arquivo: src/app/layout.tsx
```
import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "SaaS Agenda de Servicos",
  description: "Sistema SaaS de agendamento para barbearias, saloes e negocios de beleza",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="pt-BR"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <body className="min-h-full flex flex-col">{children}</body>
    </html>
  );
}

```

### Arquivo: src/app/login/page.tsx
```
import { Suspense } from "react";

import { LoginForm } from "@/components/auth/login-form";

export default function LoginPage() {
  return (
    <main className="relative flex min-h-screen items-center justify-center overflow-hidden bg-zinc-950 px-4 py-8">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top,_rgba(251,191,36,0.25),_transparent_45%),radial-gradient(circle_at_bottom,_rgba(255,255,255,0.08),_transparent_40%)]" />

      <section className="relative z-10 w-full max-w-md rounded-2xl border border-amber-400/20 bg-zinc-900/85 p-6 shadow-2xl backdrop-blur sm:p-8">
        <div className="mb-6 space-y-2 text-center">
          <p className="text-xs font-semibold tracking-[0.22em] text-amber-300 uppercase">SaaS Agenda de Servicos</p>
          <h1 className="text-2xl font-semibold text-zinc-100">Acesse sua conta</h1>
          <p className="text-sm text-zinc-300">Entre para continuar a gestao do seu negocio.</p>
        </div>

        <Suspense fallback={null}>
          <LoginForm />
        </Suspense>
      </section>
    </main>
  );
}

```

### Arquivo: src/app/master/actions.ts
```
"use server";

import { revalidatePath } from "next/cache";

import { getPlatformAccessContext } from "@/lib/auth/access";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";

function sanitizeText(value: FormDataEntryValue | null) {
  if (typeof value !== "string") {
    return "";
  }

  return value.trim();
}

export async function createMasterCompanyAction(formData: FormData) {
  const companyName = sanitizeText(formData.get("nome"));
  const phone = sanitizeText(formData.get("telefone"));
  const address = sanitizeText(formData.get("endereco"));

  if (companyName.length < 2) {
    return;
  }

  const { isPlatformAdmin } = await getPlatformAccessContext();

  if (!isPlatformAdmin) {
    return;
  }

  const adminClient = createSupabaseAdminClient();
  await adminClient.from("companies").insert({
    nome: companyName,
    telefone: phone || null,
    endereco: address || null,
  });

  revalidatePath("/master/empresas");
}

export async function updateMasterCompanyAction(formData: FormData) {
  const companyId = sanitizeText(formData.get("id"));
  const companyName = sanitizeText(formData.get("nome"));
  const phone = sanitizeText(formData.get("telefone"));
  const address = sanitizeText(formData.get("endereco"));

  if (!companyId || companyName.length < 2) {
    return;
  }

  const { isPlatformAdmin } = await getPlatformAccessContext();

  if (!isPlatformAdmin) {
    return;
  }

  const adminClient = createSupabaseAdminClient();
  await adminClient
    .from("companies")
    .update({
      nome: companyName,
      telefone: phone || null,
      endereco: address || null,
    })
    .eq("id", companyId);

  revalidatePath("/master/empresas");
}

export async function deleteMasterCompanyAction(formData: FormData) {
  const companyId = sanitizeText(formData.get("id"));

  if (!companyId) {
    return;
  }

  const { isPlatformAdmin } = await getPlatformAccessContext();

  if (!isPlatformAdmin) {
    return;
  }

  const adminClient = createSupabaseAdminClient();

  await adminClient.from("security_notifications").delete().eq("company_id", companyId);
  await adminClient.from("audit_logs").delete().eq("company_id", companyId);
  await adminClient.from("team_invites").delete().eq("company_id", companyId);
  await adminClient.from("payments").delete().eq("company_id", companyId);
  await adminClient.from("appointments").delete().eq("company_id", companyId);
  await adminClient.from("customers").delete().eq("company_id", companyId);
  await adminClient.from("employees").delete().eq("company_id", companyId);
  await adminClient.from("services").delete().eq("company_id", companyId);
  await adminClient.from("profiles").delete().eq("company_id", companyId);
  await adminClient.from("companies").delete().eq("id", companyId);

  revalidatePath("/master/empresas");
  revalidatePath("/master/relatorios");
}

```

### Arquivo: src/app/master/empresas/page.tsx
```
import { redirect } from "next/navigation";
import Link from "next/link";

import {
  createMasterCompanyAction,
  deleteMasterCompanyAction,
  updateMasterCompanyAction,
} from "@/app/master/actions";
import { signOutAction } from "@/app/painel/actions";
import { getPlatformAccessContext } from "@/lib/auth/access";

type CompanyRow = {
  id: string;
  nome: string;
  telefone: string | null;
  endereco: string | null;
  created_at: string;
};

function formatDate(dateIso: string) {
  const date = new Date(dateIso);

  if (Number.isNaN(date.getTime())) {
    return "Data invalida";
  }

  return new Intl.DateTimeFormat("pt-BR", {
    dateStyle: "short",
    timeStyle: "short",
  }).format(date);
}

export default async function MasterCompaniesPage() {
  const { supabase, redirectTo } = await getPlatformAccessContext();

  if (redirectTo) {
    redirect(redirectTo);
  }

  const [{ data: companies, error: companiesError }, userResponse] = await Promise.all([
    supabase.from("companies").select("id, nome, telefone, endereco, created_at").order("created_at", { ascending: false }),
    supabase.auth.getUser(),
  ]);

  const companyList = ((companies ?? []) as CompanyRow[]).filter((company) => Boolean(company.id));

  return (
    <main className="relative min-h-screen overflow-hidden bg-zinc-950">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top_left,_rgba(34,197,94,0.20),_transparent_45%),radial-gradient(circle_at_bottom_right,_rgba(14,165,233,0.18),_transparent_35%)]" />

      <div className="relative z-10 mx-auto w-full max-w-6xl px-4 py-6 sm:px-6 lg:py-8">
        <header className="mb-6 rounded-2xl border border-zinc-700/70 bg-zinc-900/80 p-4 shadow-2xl backdrop-blur sm:p-5">
          <p className="text-[11px] font-semibold tracking-[0.22em] text-emerald-300 uppercase">Area master</p>
          <div className="mt-3 flex flex-wrap gap-2">
            <Link
              href="/master/empresas"
              className="rounded-lg border border-emerald-400/40 bg-emerald-500/20 px-3 py-1.5 text-xs font-medium text-emerald-100"
            >
              Empresas
            </Link>
            <Link
              href="/master/relatorios"
              className="rounded-lg border border-zinc-600 px-3 py-1.5 text-xs font-medium text-zinc-200 transition hover:border-zinc-500 hover:bg-zinc-800/70"
            >
              Relatorios financeiros
            </Link>
          </div>
          <div className="mt-2 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h1 className="text-xl font-semibold text-zinc-100 sm:text-2xl">Empresas cadastradas</h1>
              <p className="mt-1 text-sm text-zinc-300">Visao global da plataforma para operacao e futura cobranca por uso.</p>
            </div>
            <form action={signOutAction}>
              <button
                type="submit"
                className="rounded-xl border border-zinc-600 px-3 py-2 text-sm font-medium text-zinc-200 transition hover:border-rose-400 hover:text-rose-300"
              >
                Sair da conta
              </button>
            </form>
          </div>
          <p className="mt-3 text-xs text-zinc-400">Usuario: {userResponse.data.user?.email ?? "sem e-mail"}</p>
        </header>

        <section className="rounded-2xl border border-zinc-700/60 bg-zinc-900/70 p-4 shadow-2xl backdrop-blur sm:p-6">
          <form action={createMasterCompanyAction} className="mb-5 grid gap-3 rounded-xl border border-zinc-700/70 bg-zinc-950/50 p-3 sm:grid-cols-4">
            <input
              name="nome"
              required
              minLength={2}
              placeholder="Nome da empresa"
              className="h-10 rounded-lg border border-zinc-700/80 bg-zinc-950/80 px-3 text-sm text-zinc-100 outline-none transition focus:border-emerald-400"
            />
            <input
              name="telefone"
              placeholder="Telefone"
              className="h-10 rounded-lg border border-zinc-700/80 bg-zinc-950/80 px-3 text-sm text-zinc-100 outline-none transition focus:border-emerald-400"
            />
            <input
              name="endereco"
              placeholder="Endereco"
              className="h-10 rounded-lg border border-zinc-700/80 bg-zinc-950/80 px-3 text-sm text-zinc-100 outline-none transition focus:border-emerald-400"
            />
            <button
              type="submit"
              className="h-10 rounded-lg border border-emerald-500/60 bg-emerald-500/15 px-3 text-sm font-medium text-emerald-100 transition hover:bg-emerald-500/25"
            >
              Incluir empresa
            </button>
          </form>

          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-lg font-semibold text-zinc-100">Total de empresas: {companyList.length}</h2>
          </div>

          {companiesError ? (
            <p className="rounded-xl border border-rose-400/30 bg-rose-500/10 px-3 py-2 text-sm text-rose-200">
              Nao foi possivel carregar as empresas: {companiesError.message}
            </p>
          ) : null}

          {!companiesError && companyList.length === 0 ? (
            <p className="rounded-xl border border-zinc-700/70 bg-zinc-950/50 px-3 py-2 text-sm text-zinc-300">Nenhuma empresa cadastrada ate o momento.</p>
          ) : null}

          {!companiesError && companyList.length > 0 ? (
            <div className="space-y-3">
              {companyList.map((company) => (
                <div key={company.id} className="grid gap-3 rounded-xl border border-zinc-700/70 bg-zinc-950/45 p-3 sm:grid-cols-5">
                  <form action={updateMasterCompanyAction} className="contents">
                    <input type="hidden" name="id" value={company.id} />
                    <input
                      name="nome"
                      required
                      minLength={2}
                      defaultValue={company.nome}
                      className="h-10 rounded-lg border border-zinc-700/80 bg-zinc-950/80 px-3 text-sm text-zinc-100 outline-none transition focus:border-emerald-400"
                    />
                    <input
                      name="telefone"
                      defaultValue={company.telefone ?? ""}
                      className="h-10 rounded-lg border border-zinc-700/80 bg-zinc-950/80 px-3 text-sm text-zinc-100 outline-none transition focus:border-emerald-400"
                    />
                    <input
                      name="endereco"
                      defaultValue={company.endereco ?? ""}
                      className="h-10 rounded-lg border border-zinc-700/80 bg-zinc-950/80 px-3 text-sm text-zinc-100 outline-none transition focus:border-emerald-400"
                    />
                    <button
                      type="submit"
                      className="h-10 rounded-lg border border-sky-500/60 bg-sky-500/15 px-3 text-sm font-medium text-sky-100 transition hover:bg-sky-500/25"
                    >
                      Salvar alteracoes
                    </button>
                  </form>
                  <div className="flex flex-col gap-2 sm:items-end">
                    <span className="text-xs text-zinc-400">Criada em: {formatDate(company.created_at)}</span>
                    <span className="text-[11px] text-zinc-500">ID: {company.id}</span>
                    <form action={deleteMasterCompanyAction}>
                      <input type="hidden" name="id" value={company.id} />
                      <button
                        type="submit"
                        className="h-9 rounded-lg border border-rose-500/60 bg-rose-500/15 px-3 text-xs font-medium text-rose-100 transition hover:bg-rose-500/25"
                      >
                        Excluir empresa
                      </button>
                    </form>
                  </div>
                </div>
              ))}
            </div>
          ) : null}
        </section>
      </div>
    </main>
  );
}

```

### Arquivo: src/app/master/page.tsx
```
import { redirect } from "next/navigation";

export default function MasterHomePage() {
  redirect("/master/empresas");
}

```

### Arquivo: src/app/master/relatorios/page.tsx
```
import Link from "next/link";
import { redirect } from "next/navigation";

import { signOutAction } from "@/app/painel/actions";
import { getPlatformAccessContext } from "@/lib/auth/access";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";

type CompanyRow = {
  id: string;
  nome: string;
};

type PaymentRow = {
  company_id: string;
  valor: number | string;
  valor_comissao: number | string;
};

type AppointmentRow = {
  company_id: string;
  status: "agendado" | "concluido" | "cancelado";
};

function asNumber(value: number | string | null | undefined) {
  const numeric = Number(value ?? 0);
  return Number.isFinite(numeric) ? numeric : 0;
}

function formatCurrency(value: number) {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
    minimumFractionDigits: 2,
  }).format(value);
}

function normalizeText(value: string) {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim();
}

type MasterReportsPageProps = {
  searchParams?: Promise<{
    empresa?: string;
  }>;
};

export default async function MasterReportsPage({ searchParams }: MasterReportsPageProps) {
  const { redirectTo } = await getPlatformAccessContext();

  if (redirectTo) {
    redirect(redirectTo);
  }

  const resolvedSearchParams = searchParams ? await searchParams : undefined;

  const adminClient = createSupabaseAdminClient();

  const [{ data: companies }, { data: payments }, { data: appointments }, userResponse] = await Promise.all([
    adminClient.from("companies").select("id, nome").order("nome", { ascending: true }),
    adminClient.from("payments").select("company_id, valor, valor_comissao"),
    adminClient.from("appointments").select("company_id, status"),
    adminClient.auth.getUser(),
  ]);

  const companiesList = (companies ?? []) as CompanyRow[];
  const paymentsList = (payments ?? []) as PaymentRow[];
  const appointmentsList = (appointments ?? []) as AppointmentRow[];
  const companySearchTerm = resolvedSearchParams?.empresa?.trim() ?? "";
  const normalizedCompanySearchTerm = normalizeText(companySearchTerm);

  const perCompany = companiesList.map((company) => {
    const companyPayments = paymentsList.filter((item) => item.company_id === company.id);
    const companyAppointments = appointmentsList.filter((item) => item.company_id === company.id);

    const totalRevenue = companyPayments.reduce((sum, item) => sum + asNumber(item.valor), 0);
    const totalCommission = companyPayments.reduce((sum, item) => sum + asNumber(item.valor_comissao), 0);
    const totalAppointments = companyAppointments.length;
    const completedAppointments = companyAppointments.filter((item) => item.status === "concluido").length;

    return {
      ...company,
      totalRevenue,
      totalCommission,
      totalAppointments,
      completedAppointments,
    };
  });

  const visibleCompanies = normalizedCompanySearchTerm
    ? perCompany.filter((company) => normalizeText(company.nome).includes(normalizedCompanySearchTerm))
    : perCompany;

  const platformRevenue = visibleCompanies.reduce((sum, item) => sum + item.totalRevenue, 0);
  const platformCommission = visibleCompanies.reduce((sum, item) => sum + item.totalCommission, 0);
  const platformAppointments = visibleCompanies.reduce((sum, item) => sum + item.totalAppointments, 0);

  return (
    <main className="relative min-h-screen overflow-hidden bg-zinc-950">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top_left,_rgba(34,197,94,0.20),_transparent_45%),radial-gradient(circle_at_bottom_right,_rgba(14,165,233,0.18),_transparent_35%)]" />

      <div className="relative z-10 mx-auto w-full max-w-6xl px-4 py-6 sm:px-6 lg:py-8">
        <header className="mb-6 rounded-2xl border border-zinc-700/70 bg-zinc-900/80 p-4 shadow-2xl backdrop-blur sm:p-5">
          <p className="text-[11px] font-semibold tracking-[0.22em] text-emerald-300 uppercase">Area master</p>
          <div className="mt-3 flex flex-wrap gap-2">
            <Link
              href="/master/empresas"
              className="rounded-lg border border-zinc-600 px-3 py-1.5 text-xs font-medium text-zinc-200 transition hover:border-zinc-500 hover:bg-zinc-800/70"
            >
              Empresas
            </Link>
            <Link
              href="/master/relatorios"
              className="rounded-lg border border-emerald-400/40 bg-emerald-500/20 px-3 py-1.5 text-xs font-medium text-emerald-100"
            >
              Relatorios financeiros
            </Link>
          </div>
          <div className="mt-2 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h1 className="text-xl font-semibold text-zinc-100 sm:text-2xl">Rendimento financeiro da plataforma</h1>
              <p className="mt-1 text-sm text-zinc-300">Visao consolidada e por empresa para analise de faturamento e operacao.</p>
            </div>
            <form action={signOutAction}>
              <button
                type="submit"
                className="rounded-xl border border-zinc-600 px-3 py-2 text-sm font-medium text-zinc-200 transition hover:border-rose-400 hover:text-rose-300"
              >
                Sair da conta
              </button>
            </form>
          </div>
          <p className="mt-3 text-xs text-zinc-400">Usuario: {userResponse.data.user?.email ?? "sem e-mail"}</p>
        </header>

        <section className="mb-5 grid gap-3 sm:grid-cols-3">
          <div className="rounded-xl border border-emerald-500/40 bg-emerald-500/10 p-4">
            <p className="text-xs text-emerald-200">Faturamento total</p>
            <p className="mt-1 text-2xl font-semibold text-emerald-100">{formatCurrency(platformRevenue)}</p>
          </div>
          <div className="rounded-xl border border-sky-500/40 bg-sky-500/10 p-4">
            <p className="text-xs text-sky-200">Comissao total</p>
            <p className="mt-1 text-2xl font-semibold text-sky-100">{formatCurrency(platformCommission)}</p>
          </div>
          <div className="rounded-xl border border-amber-500/40 bg-amber-500/10 p-4">
            <p className="text-xs text-amber-200">Agendamentos totais</p>
            <p className="mt-1 text-2xl font-semibold text-amber-100">{platformAppointments}</p>
          </div>
        </section>

        <section className="rounded-2xl border border-zinc-700/60 bg-zinc-900/70 p-4 shadow-2xl backdrop-blur sm:p-6">
          <form className="mb-4 flex flex-col gap-3 rounded-xl border border-zinc-700/70 bg-zinc-950/50 p-3 sm:flex-row sm:items-end">
            <div className="min-w-0 flex-1">
              <label htmlFor="empresa" className="mb-1 block text-sm font-medium text-zinc-200">
                Filtrar por empresa
              </label>
              <input
                id="empresa"
                name="empresa"
                type="text"
                list="master-companies"
                defaultValue={companySearchTerm}
                placeholder="Digite o nome da empresa"
                className="h-10 w-full rounded-lg border border-zinc-700/80 bg-zinc-950/80 px-3 text-sm text-zinc-100 outline-none transition focus:border-emerald-400"
              />
              <datalist id="master-companies">
                {companiesList.map((company) => (
                  <option key={company.id} value={company.nome} />
                ))}
              </datalist>
            </div>
            <button
              type="submit"
              className="h-10 rounded-lg border border-emerald-500/60 bg-emerald-500/15 px-4 text-sm font-medium text-emerald-100 transition hover:bg-emerald-500/25"
            >
              Aplicar filtro
            </button>
            <Link
              href="/master/relatorios"
              className="inline-flex h-10 items-center justify-center rounded-lg border border-zinc-600 px-4 text-sm font-medium text-zinc-200 transition hover:border-zinc-500 hover:bg-zinc-800/70"
            >
              Limpar
            </Link>
          </form>

          <h2 className="mb-4 text-lg font-semibold text-zinc-100">Resumo por empresa</h2>

          {companySearchTerm ? <p className="mb-4 text-sm text-zinc-400">Filtro ativo: empresas com nome contendo &quot;{companySearchTerm}&quot;.</p> : null}

          {visibleCompanies.length === 0 ? (
            <p className="rounded-xl border border-zinc-700/70 bg-zinc-950/50 px-3 py-2 text-sm text-zinc-300">Nenhuma empresa encontrada para o filtro informado.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[860px] divide-y divide-zinc-700 text-sm">
                <thead>
                  <tr className="text-left text-zinc-300">
                    <th className="py-2 pr-3 font-medium">Empresa</th>
                    <th className="py-2 pr-3 font-medium">Faturamento</th>
                    <th className="py-2 pr-3 font-medium">Comissao</th>
                    <th className="py-2 pr-3 font-medium">Agendamentos</th>
                    <th className="py-2 pr-3 font-medium">Concluidos</th>
                    <th className="py-2 pr-3 font-medium">ID</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800/80 text-zinc-200">
                  {visibleCompanies.map((item) => (
                    <tr key={item.id}>
                      <td className="py-3 pr-3 font-medium">{item.nome}</td>
                      <td className="py-3 pr-3">{formatCurrency(item.totalRevenue)}</td>
                      <td className="py-3 pr-3">{formatCurrency(item.totalCommission)}</td>
                      <td className="py-3 pr-3">{item.totalAppointments}</td>
                      <td className="py-3 pr-3">{item.completedAppointments}</td>
                      <td className="py-3 pr-3 text-xs text-zinc-400">{item.id}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>
    </main>
  );
}

```

### Arquivo: src/app/onboarding/actions.ts
```
"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { randomUUID } from "node:crypto";

import { createSupabaseServerClient } from "@/lib/supabase/server";

export type OnboardingActionState = {
  success: boolean;
  message: string;
  fieldErrors?: {
    nomeResponsavel?: string;
    nomeEmpresa?: string;
  };
};

function sanitizeText(value: FormDataEntryValue | null): string {
  if (typeof value !== "string") {
    return "";
  }

  return value.trim();
}

export async function completeOnboardingAction(
  _previousState: OnboardingActionState,
  formData: FormData,
): Promise<OnboardingActionState> {
  const nomeResponsavel = sanitizeText(formData.get("nomeResponsavel"));
  const nomeEmpresa = sanitizeText(formData.get("nomeEmpresa"));
  const telefone = sanitizeText(formData.get("telefone"));
  const endereco = sanitizeText(formData.get("endereco"));

  const fieldErrors: OnboardingActionState["fieldErrors"] = {};

  if (nomeResponsavel.length < 3) {
    fieldErrors.nomeResponsavel = "Informe seu nome com pelo menos 3 caracteres.";
  }

  if (nomeEmpresa.length < 2) {
    fieldErrors.nomeEmpresa = "Informe o nome da empresa com pelo menos 2 caracteres.";
  }

  if (fieldErrors.nomeEmpresa || fieldErrors.nomeResponsavel) {
    return {
      success: false,
      message: "Corrija os campos destacados para continuar.",
      fieldErrors,
    };
  }

  const supabase = await createSupabaseServerClient();
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser();

  if (userError || !user) {
    return {
      success: false,
      message: "Sua sessao expirou. Faca login novamente.",
    };
  }

  const { data: existingCompanyId } = await supabase.rpc("current_company_id");

  if (existingCompanyId) {
    redirect("/painel");
  }

  const companyId = randomUUID();

  const { error: companyError } = await supabase.from("companies").insert({
    id: companyId,
    nome: nomeEmpresa,
    telefone: telefone || null,
    endereco: endereco || null,
  });

  if (companyError) {
    return {
      success: false,
      message: `Nao foi possivel criar a empresa: ${companyError?.message ?? "erro desconhecido"}`,
    };
  }

  const { error: profileError } = await supabase.from("profiles").insert({
    id: user.id,
    company_id: companyId,
    nome: nomeResponsavel,
    email: (user.email ?? "").toLowerCase(),
    role: "admin",
  });

  if (profileError) {
    return {
      success: false,
      message: `Empresa criada, mas houve erro ao criar o perfil admin: ${profileError.message}`,
    };
  }

  revalidatePath("/painel");
  redirect("/painel");
}

```

### Arquivo: src/app/onboarding/page.tsx
```
import { redirect } from "next/navigation";

import { OnboardingForm } from "@/components/onboarding/onboarding-form";
import { createSupabaseServerClient } from "@/lib/supabase/server";

export default async function OnboardingPage() {
  const supabase = await createSupabaseServerClient();
  const {
    data: { user },
    error,
  } = await supabase.auth.getUser();

  if (error || !user) {
    redirect("/login");
  }

  const { data: companyId } = await supabase.rpc("current_company_id");
  const { data: isPlatformAdmin, error: platformAdminError } = await supabase.rpc("is_platform_admin");

  if (companyId) {
    redirect("/painel");
  }

  if (!platformAdminError && isPlatformAdmin) {
    redirect("/master/empresas");
  }

  return (
    <main className="relative flex min-h-screen items-center justify-center overflow-hidden bg-zinc-950 px-4 py-8">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top,_rgba(251,191,36,0.25),_transparent_45%),radial-gradient(circle_at_bottom,_rgba(255,255,255,0.08),_transparent_40%)]" />

      <section className="relative z-10 w-full max-w-lg rounded-2xl border border-amber-400/20 bg-zinc-900/85 p-6 shadow-2xl backdrop-blur sm:p-8">
        <div className="mb-6 space-y-2 text-center">
          <p className="text-xs font-semibold tracking-[0.22em] text-amber-300 uppercase">Primeiro acesso</p>
          <h1 className="text-2xl font-semibold text-zinc-100">Finalize o cadastro da sua empresa</h1>
          <p className="text-sm text-zinc-300">Vamos criar sua empresa e seu perfil administrador para liberar o acesso ao painel.</p>
        </div>

        <OnboardingForm />
      </section>
    </main>
  );
}

```

### Arquivo: src/app/page.tsx
```
import { redirect } from "next/navigation";

export default function Home() {
  redirect("/login");
}

```

### Arquivo: src/app/painel/actions.ts
```
"use server";

import { redirect } from "next/navigation";

import { createSupabaseServerClient } from "@/lib/supabase/server";

export async function signOutAction(): Promise<void> {
  const supabase = await createSupabaseServerClient();
  await supabase.auth.signOut();
  redirect("/login");
}

```

### Arquivo: src/app/painel/agendamentos/actions.ts
```
"use server";

import { revalidatePath } from "next/cache";

import { calculateEndDateIso } from "@/lib/appointments/conflict";
import { canPerformAction, getAccessContext } from "@/lib/auth/access";

type ActionState = {
  success: boolean;
  message: string;
};

type AppointmentStatus = "agendado" | "concluido" | "cancelado";

const APPOINTMENT_STATUS: AppointmentStatus[] = ["agendado", "concluido", "cancelado"];

function mapAppointmentDatabaseError(message: string): string {
  if (message.includes("data_hora_fim")) {
    return "Seu banco ainda nao foi atualizado para conflitos de horario. Execute o script docs/database/002_etapa6_conflito_agendamentos.sql no Supabase SQL Editor e tente novamente.";
  }

  if (message.includes("customer_id") || message.includes("appointments_customer_company_fk")) {
    return "Seu banco ainda nao foi atualizado para clientes em agendamentos. Execute o script docs/database/006_etapa13_agendamentos_clientes.sql no Supabase SQL Editor e tente novamente.";
  }

  return message;
}

function sanitizeText(value: FormDataEntryValue | null): string {
  if (typeof value !== "string") {
    return "";
  }

  return value.trim();
}

function parseDateTimeLocal(value: string): string | null {
  const parsedDate = new Date(value);

  if (Number.isNaN(parsedDate.getTime())) {
    return null;
  }

  return parsedDate.toISOString();
}

async function getCompanyScope() {
  return getAccessContext();
}

function validateStatus(value: string): value is AppointmentStatus {
  return APPOINTMENT_STATUS.includes(value as AppointmentStatus);
}

async function ensureReferencesBelongToCompany(
  employeeId: string,
  serviceId: string,
  companyId: string,
  supabase: Awaited<ReturnType<typeof getAccessContext>>["supabase"],
): Promise<string | null> {
  const [{ data: employee }, { data: service }] = await Promise.all([
    supabase.from("employees").select("id").eq("id", employeeId).eq("company_id", companyId).maybeSingle(),
    supabase.from("services").select("id").eq("id", serviceId).eq("company_id", companyId).maybeSingle(),
  ]);

  if (!employee) {
    return "Funcionario invalido para sua empresa.";
  }

  if (!service) {
    return "Servico invalido para sua empresa.";
  }

  return null;
}

async function getServiceDurationMinutes(
  serviceId: string,
  companyId: string,
  supabase: Awaited<ReturnType<typeof getAccessContext>>["supabase"],
): Promise<number | null> {
  const { data: service } = await supabase
    .from("services")
    .select("duracao")
    .eq("id", serviceId)
    .eq("company_id", companyId)
    .maybeSingle();

  if (!service) {
    return null;
  }

  const durationMinutes = Number(service.duracao);

  if (!Number.isFinite(durationMinutes) || durationMinutes <= 0) {
    return null;
  }

  return Math.trunc(durationMinutes);
}

async function hasConflictForEmployee(
  params: {
    companyId: string;
    employeeId: string;
    newStartIso: string;
    newEndIso: string;
    ignoreAppointmentId?: string;
  },
  supabase: Awaited<ReturnType<typeof getAccessContext>>["supabase"],
): Promise<{ hasConflict: boolean; errorMessage: string | null }> {
  const query = supabase
    .from("appointments")
    .select("id")
    .eq("company_id", params.companyId)
    .eq("employee_id", params.employeeId)
    .eq("status", "agendado")
    .lt("data_hora", params.newEndIso)
    .gt("data_hora_fim", params.newStartIso)
    .limit(1);

  if (params.ignoreAppointmentId) {
    query.neq("id", params.ignoreAppointmentId);
  }

  const { data, error } = await query;

  if (error) {
    return {
      hasConflict: false,
      errorMessage: mapAppointmentDatabaseError(error.message),
    };
  }

  return { hasConflict: (data?.length ?? 0) > 0, errorMessage: null };
}

export async function createAppointmentAction(_prevState: ActionState, formData: FormData): Promise<ActionState> {
  const customerIdInput = sanitizeText(formData.get("customer_id"));
  const clienteNomeInput = sanitizeText(formData.get("cliente_nome"));
  const clienteTelefoneInput = sanitizeText(formData.get("cliente_telefone"));
  const employeeId = sanitizeText(formData.get("employee_id"));
  const serviceId = sanitizeText(formData.get("service_id"));
  const dataHoraInput = sanitizeText(formData.get("data_hora"));
  const statusInput = sanitizeText(formData.get("status"));
  const observacoes = sanitizeText(formData.get("observacoes"));

  if (!employeeId) {
    return { success: false, message: "Selecione um funcionario." };
  }

  if (!serviceId) {
    return { success: false, message: "Selecione um servico." };
  }

  const dataHora = parseDateTimeLocal(dataHoraInput);

  if (!dataHora) {
    return { success: false, message: "Informe uma data e horario validos." };
  }

  if (!validateStatus(statusInput)) {
    return { success: false, message: "Status de agendamento invalido." };
  }

  const { supabase, companyId, role, errorMessage } = await getCompanyScope();

  if (!companyId || !role) {
    return { success: false, message: errorMessage ?? "Nao foi possivel identificar sua empresa." };
  }

  if (!canPerformAction(role, "agendamentos", "create")) {
    return { success: false, message: "Seu perfil nao tem permissao para criar agendamentos." };
  }

  let customerId: string | null = customerIdInput || null;
  let clienteNome = clienteNomeInput;
  let clienteTelefone = clienteTelefoneInput;

  if (customerId) {
    const { data: customer } = await supabase
      .from("customers")
      .select("id, nome, telefone")
      .eq("id", customerId)
      .eq("company_id", companyId)
      .maybeSingle();

    if (!customer) {
      return { success: false, message: "Cliente selecionado invalido para sua empresa." };
    }

    clienteNome = String(customer.nome ?? "").trim();
    clienteTelefone = String(customer.telefone ?? "").trim();
  } else {
    customerId = null;
  }

  if (clienteNome.length < 2) {
    return { success: false, message: "Informe o nome do cliente com pelo menos 2 caracteres." };
  }

  const referenceError = await ensureReferencesBelongToCompany(employeeId, serviceId, companyId, supabase);

  if (referenceError) {
    return { success: false, message: referenceError };
  }

  const durationMinutes = await getServiceDurationMinutes(serviceId, companyId, supabase);

  if (!durationMinutes) {
    return { success: false, message: "Nao foi possivel calcular a duracao do servico selecionado." };
  }

  const dataHoraFim = calculateEndDateIso(dataHora, durationMinutes);

  if (statusInput === "agendado") {
    const conflictResult = await hasConflictForEmployee(
      {
        companyId,
        employeeId,
        newStartIso: dataHora,
        newEndIso: dataHoraFim,
      },
      supabase,
    );

    if (conflictResult.errorMessage) {
      return {
        success: false,
        message: conflictResult.errorMessage,
      };
    }

    if (conflictResult.hasConflict) {
      return {
        success: false,
        message: "Este funcionario ja possui um agendamento nesse horario.",
      };
    }
  }

  const { error } = await supabase.from("appointments").insert({
    company_id: companyId,
    customer_id: customerId,
    cliente_nome: clienteNome,
    cliente_telefone: clienteTelefone || null,
    employee_id: employeeId,
    service_id: serviceId,
    data_hora: dataHora,
    data_hora_fim: dataHoraFim,
    status: statusInput,
    observacoes: observacoes || null,
  });

  if (error) {
    return {
      success: false,
      message: `Nao foi possivel criar agendamento: ${mapAppointmentDatabaseError(error.message)}`,
    };
  }

  revalidatePath("/painel/agendamentos");
  return { success: true, message: "Agendamento criado com sucesso." };
}

export async function updateAppointmentAction(_prevState: ActionState, formData: FormData): Promise<ActionState> {
  const id = sanitizeText(formData.get("id"));
  const customerIdInput = sanitizeText(formData.get("customer_id"));
  const clienteNomeInput = sanitizeText(formData.get("cliente_nome"));
  const clienteTelefoneInput = sanitizeText(formData.get("cliente_telefone"));
  const employeeId = sanitizeText(formData.get("employee_id"));
  const serviceId = sanitizeText(formData.get("service_id"));
  const dataHoraInput = sanitizeText(formData.get("data_hora"));
  const statusInput = sanitizeText(formData.get("status"));
  const observacoes = sanitizeText(formData.get("observacoes"));

  if (!id) {
    return { success: false, message: "Agendamento invalido para atualizacao." };
  }

  if (!employeeId) {
    return { success: false, message: "Selecione um funcionario." };
  }

  if (!serviceId) {
    return { success: false, message: "Selecione um servico." };
  }

  const dataHora = parseDateTimeLocal(dataHoraInput);

  if (!dataHora) {
    return { success: false, message: "Informe uma data e horario validos." };
  }

  if (!validateStatus(statusInput)) {
    return { success: false, message: "Status de agendamento invalido." };
  }

  const { supabase, companyId, role, errorMessage } = await getCompanyScope();

  if (!companyId || !role) {
    return { success: false, message: errorMessage ?? "Nao foi possivel identificar sua empresa." };
  }

  if (!canPerformAction(role, "agendamentos", "update")) {
    return { success: false, message: "Seu perfil nao tem permissao para atualizar agendamentos." };
  }

  let customerId: string | null = customerIdInput || null;
  let clienteNome = clienteNomeInput;
  let clienteTelefone = clienteTelefoneInput;

  if (customerId) {
    const { data: customer } = await supabase
      .from("customers")
      .select("id, nome, telefone")
      .eq("id", customerId)
      .eq("company_id", companyId)
      .maybeSingle();

    if (!customer) {
      return { success: false, message: "Cliente selecionado invalido para sua empresa." };
    }

    clienteNome = String(customer.nome ?? "").trim();
    clienteTelefone = String(customer.telefone ?? "").trim();
  } else {
    customerId = null;
  }

  if (clienteNome.length < 2) {
    return { success: false, message: "Informe o nome do cliente com pelo menos 2 caracteres." };
  }

  const referenceError = await ensureReferencesBelongToCompany(employeeId, serviceId, companyId, supabase);

  if (referenceError) {
    return { success: false, message: referenceError };
  }

  const durationMinutes = await getServiceDurationMinutes(serviceId, companyId, supabase);

  if (!durationMinutes) {
    return { success: false, message: "Nao foi possivel calcular a duracao do servico selecionado." };
  }

  const dataHoraFim = calculateEndDateIso(dataHora, durationMinutes);

  if (statusInput === "agendado") {
    const conflictResult = await hasConflictForEmployee(
      {
        companyId,
        employeeId,
        newStartIso: dataHora,
        newEndIso: dataHoraFim,
        ignoreAppointmentId: id,
      },
      supabase,
    );

    if (conflictResult.errorMessage) {
      return {
        success: false,
        message: conflictResult.errorMessage,
      };
    }

    if (conflictResult.hasConflict) {
      return {
        success: false,
        message: "O horario selecionado esta indisponivel para este funcionario.",
      };
    }
  }

  const { error } = await supabase
    .from("appointments")
    .update({
      customer_id: customerId,
      cliente_nome: clienteNome,
      cliente_telefone: clienteTelefone || null,
      employee_id: employeeId,
      service_id: serviceId,
      data_hora: dataHora,
      data_hora_fim: dataHoraFim,
      status: statusInput,
      observacoes: observacoes || null,
    })
    .eq("id", id)
    .eq("company_id", companyId);

  if (error) {
    return {
      success: false,
      message: `Nao foi possivel atualizar agendamento: ${mapAppointmentDatabaseError(error.message)}`,
    };
  }

  revalidatePath("/painel/agendamentos");
  return { success: true, message: "Agendamento atualizado com sucesso." };
}

export async function deleteAppointmentAction(_prevState: ActionState, formData: FormData): Promise<ActionState> {
  const id = sanitizeText(formData.get("id"));

  if (!id) {
    return { success: false, message: "Agendamento invalido para exclusao." };
  }

  const { supabase, companyId, role, errorMessage } = await getCompanyScope();

  if (!companyId || !role) {
    return { success: false, message: errorMessage ?? "Nao foi possivel identificar sua empresa." };
  }

  if (!canPerformAction(role, "agendamentos", "delete")) {
    return { success: false, message: "Seu perfil nao tem permissao para excluir agendamentos." };
  }

  const { error } = await supabase.from("appointments").delete().eq("id", id).eq("company_id", companyId);

  if (error) {
    return { success: false, message: `Nao foi possivel excluir agendamento: ${error.message}` };
  }

  revalidatePath("/painel/agendamentos");
  return { success: true, message: "Agendamento excluido com sucesso." };
}

```

### Arquivo: src/app/painel/agendamentos/page.tsx
```
import { redirect } from "next/navigation";

import { CreateAppointmentForm } from "@/components/painel/agendamentos/create-appointment-form";
import { AppointmentItemForm } from "@/components/painel/agendamentos/appointment-item-form";
import { canAccessModule, canPerformAction, getAccessContext } from "@/lib/auth/access";
import type { AppointmentStatus } from "@/types";

type OptionItem = {
  id: string;
  nome: string;
  duracao?: number;
  telefone?: string | null;
};

type AppointmentRow = {
  id: string;
  customer_id: string | null;
  cliente_nome: string;
  cliente_telefone: string | null;
  employee_id: string;
  service_id: string;
  data_hora: string;
  data_hora_fim: string | null;
  status: AppointmentStatus;
  observacoes: string | null;
};

type AppointmentSlot = {
  id: string;
  employeeId: string;
  startIso: string;
  endIso: string;
  status: AppointmentStatus;
};

export default async function AgendamentosPage() {
  const { supabase, companyId, role, redirectTo } = await getAccessContext();

  if (!companyId || !role) {
    redirect(redirectTo ?? "/login");
  }

  if (!canAccessModule(role, "agendamentos")) {
    redirect("/painel");
  }

  const canCreateAppointment = canPerformAction(role, "agendamentos", "create");
  const canUpdateAppointment = canPerformAction(role, "agendamentos", "update");
  const canDeleteAppointment = canPerformAction(role, "agendamentos", "delete");

  const [employeesResponse, servicesResponse, customersResponse, appointmentsResponse] = await Promise.all([
    supabase
      .from("employees")
      .select("id, nome")
      .eq("company_id", companyId)
      .eq("ativo", true)
      .order("nome", { ascending: true }),
    supabase
      .from("services")
      .select("id, nome, duracao")
      .eq("company_id", companyId)
      .eq("ativo", true)
      .order("nome", { ascending: true }),
    supabase
      .from("customers")
      .select("id, nome, telefone")
      .eq("company_id", companyId)
      .eq("ativo", true)
      .order("nome", { ascending: true }),
    supabase
      .from("appointments")
      .select("id, customer_id, cliente_nome, cliente_telefone, employee_id, service_id, data_hora, data_hora_fim, status, observacoes")
      .eq("company_id", companyId)
      .order("data_hora", { ascending: true }),
  ]);

  const employees: OptionItem[] = (employeesResponse.data ?? []) as OptionItem[];
  const services: OptionItem[] = (servicesResponse.data ?? []) as OptionItem[];
  const customers: OptionItem[] = (customersResponse.data ?? []) as OptionItem[];
  const appointments: AppointmentRow[] = (appointmentsResponse.data ?? []) as AppointmentRow[];
  const appointmentSlots: AppointmentSlot[] = appointments.map((appointment) => ({
    id: appointment.id,
    employeeId: appointment.employee_id,
    startIso: appointment.data_hora,
    endIso: appointment.data_hora_fim ?? appointment.data_hora,
    status: appointment.status,
  }));

  return (
    <div className="space-y-5">
        <header className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-semibold text-zinc-100">Agendamentos</h1>
            <p className="text-sm text-zinc-300">Gerencie os agendamentos vinculados aos funcionarios e servicos da sua empresa.</p>
          </div>
        </header>

        {employees.length === 0 || services.length === 0 ? (
          <p className="rounded-xl border border-amber-500/40 bg-amber-600/10 p-4 text-sm text-amber-200">
            Para criar agendamentos, cadastre pelo menos um funcionario ativo e um servico ativo.
          </p>
        ) : canCreateAppointment ? (
          <CreateAppointmentForm employees={employees} services={services} customers={customers} appointmentSlots={appointmentSlots} />
        ) : (
          <p className="rounded-xl border border-zinc-700/60 bg-zinc-950/60 p-4 text-sm text-zinc-300">
            Seu perfil pode visualizar e atualizar agendamentos, mas nao pode criar novos.
          </p>
        )}

        <div className="space-y-3">
          <h2 className="text-lg font-medium text-zinc-100">Lista de agendamentos</h2>

          {appointments.length === 0 ? (
            <p className="rounded-xl border border-zinc-700/60 bg-zinc-950/60 p-4 text-sm text-zinc-300">
              Nenhum agendamento cadastrado ainda.
            </p>
          ) : (
            <div className="space-y-3">
              {appointments.map((appointment) => (
                <AppointmentItemForm
                  key={appointment.id}
                  appointment={appointment}
                  employees={employees}
                  services={services}
                  customers={customers}
                  appointmentSlots={appointmentSlots}
                  canUpdate={canUpdateAppointment}
                  canDelete={canDeleteAppointment}
                />
              ))}
            </div>
          )}
        </div>
    </div>
  );
}

```

### Arquivo: src/app/painel/auditoria/page.tsx
```
import Link from "next/link";
import { redirect } from "next/navigation";

import { canAccessModule, getAccessContext } from "@/lib/auth/access";

type AuditRow = {
  id: string;
  actor_id: string | null;
  action: string;
  entity: string;
  entity_id: string | null;
  metadata: Record<string, unknown>;
  created_at: string;
};

type ProfileRow = {
  id: string;
  nome: string;
  email: string;
};

type SearchParams = {
  from?: string | string[];
  to?: string | string[];
  action?: string | string[];
  entity?: string | string[];
  q?: string | string[];
};

function getSingleParam(value: string | string[] | undefined): string {
  if (Array.isArray(value)) {
    return value[0] ?? "";
  }

  return value ?? "";
}

function toDateInputValue(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function normalizeDate(value: string, fallback: string): string {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    return fallback;
  }

  return value;
}

function normalizeText(value: string): string {
  return value.trim();
}

function formatDate(value: string): string {
  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return value;
  }

  return new Intl.DateTimeFormat("pt-BR", {
    dateStyle: "short",
    timeStyle: "short",
  }).format(date);
}

function formatMetadata(metadata: Record<string, unknown>): string {
  try {
    return JSON.stringify(metadata, null, 2);
  } catch {
    return "{}";
  }
}

export default async function AuditoriaPage({
  searchParams,
}: {
  searchParams?: Promise<SearchParams>;
}) {
  const resolvedSearchParams = searchParams ? await searchParams : {};
  const { supabase, companyId, role, redirectTo } = await getAccessContext();

  if (!companyId || !role) {
    redirect(redirectTo ?? "/login");
  }

  if (!canAccessModule(role, "auditoria")) {
    redirect("/painel");
  }

  const now = new Date();
  const defaultFrom = toDateInputValue(new Date(now.getFullYear(), now.getMonth(), now.getDate() - 30));
  const defaultTo = toDateInputValue(now);

  const fromInput = normalizeDate(getSingleParam(resolvedSearchParams.from), defaultFrom);
  const toInput = normalizeDate(getSingleParam(resolvedSearchParams.to), defaultTo);
  const actionInput = normalizeText(getSingleParam(resolvedSearchParams.action));
  const entityInput = normalizeText(getSingleParam(resolvedSearchParams.entity));
  const queryInput = normalizeText(getSingleParam(resolvedSearchParams.q));

  const fromIso = new Date(`${fromInput}T00:00:00`).toISOString();
  const toIso = new Date(`${toInput}T23:59:59.999`).toISOString();

  let logsQuery = supabase
    .from("audit_logs")
    .select("id, actor_id, action, entity, entity_id, metadata, created_at")
    .eq("company_id", companyId)
    .gte("created_at", fromIso)
    .lte("created_at", toIso)
    .order("created_at", { ascending: false })
    .limit(500);

  if (actionInput) {
    logsQuery = logsQuery.eq("action", actionInput);
  }

  if (entityInput) {
    logsQuery = logsQuery.eq("entity", entityInput);
  }

  const logsResponse = await logsQuery;

  const hasAuditTableIssue = Boolean(logsResponse.error?.message.includes("audit_logs"));
  const logs = (logsResponse.data ?? []) as AuditRow[];
  const actorIds = [...new Set(logs.map((item) => item.actor_id).filter(Boolean))] as string[];

  const profilesResponse =
    actorIds.length > 0
      ? await supabase.from("profiles").select("id, nome, email").eq("company_id", companyId).in("id", actorIds)
      : { data: [] as ProfileRow[], error: null };

  const profiles = (profilesResponse.data ?? []) as ProfileRow[];
  const profileById = new Map(profiles.map((profile) => [profile.id, profile]));

  const textQuery = queryInput.toLowerCase();
  const filteredLogs = textQuery
    ? logs.filter((log) => {
        const actor = log.actor_id ? profileById.get(log.actor_id) : null;
        const searchStack = [
          log.action,
          log.entity,
          log.entity_id ?? "",
          formatMetadata(log.metadata),
          actor?.nome ?? "",
          actor?.email ?? "",
        ]
          .join(" ")
          .toLowerCase();

        return searchStack.includes(textQuery);
      })
    : logs;

  const uniqueActions = [...new Set(logs.map((item) => item.action))].sort((left, right) => left.localeCompare(right));
  const uniqueEntities = [...new Set(logs.map((item) => item.entity))].sort((left, right) => left.localeCompare(right));
  const exportQuery = new URLSearchParams({
    from: fromInput,
    to: toInput,
    action: actionInput,
    entity: entityInput,
    q: queryInput,
  });

  const exportAuditCsvHref = `/api/reports/auditoria?${exportQuery.toString()}`;
  const exportAuditPdfHref = `/api/reports/auditoria/pdf?${exportQuery.toString()}`;

  return (
    <div className="space-y-5">
        <header className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-semibold text-zinc-100">Auditoria</h1>
            <p className="text-sm text-zinc-300">Acompanhe alteracoes sensiveis da sua empresa.</p>
          </div>
        </header>

        <form className="grid gap-3 rounded-xl border border-zinc-700/60 bg-zinc-950/60 p-4 md:grid-cols-5">
          <div className="space-y-1">
            <label htmlFor="auditoria-from" className="text-xs text-zinc-400">
              De
            </label>
            <input
              id="auditoria-from"
              name="from"
              type="date"
              defaultValue={fromInput}
              className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-sky-400"
            />
          </div>

          <div className="space-y-1">
            <label htmlFor="auditoria-to" className="text-xs text-zinc-400">
              Ate
            </label>
            <input
              id="auditoria-to"
              name="to"
              type="date"
              defaultValue={toInput}
              className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-sky-400"
            />
          </div>

          <div className="space-y-1">
            <label htmlFor="auditoria-action" className="text-xs text-zinc-400">
              Acao
            </label>
            <select
              id="auditoria-action"
              name="action"
              defaultValue={actionInput}
              className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-sky-400"
            >
              <option value="">Todas</option>
              {uniqueActions.map((action) => (
                <option key={action} value={action}>
                  {action}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1">
            <label htmlFor="auditoria-entity" className="text-xs text-zinc-400">
              Entidade
            </label>
            <select
              id="auditoria-entity"
              name="entity"
              defaultValue={entityInput}
              className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-sky-400"
            >
              <option value="">Todas</option>
              {uniqueEntities.map((entity) => (
                <option key={entity} value={entity}>
                  {entity}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1">
            <label htmlFor="auditoria-q" className="text-xs text-zinc-400">
              Busca
            </label>
            <input
              id="auditoria-q"
              name="q"
              type="text"
              defaultValue={queryInput}
              placeholder="ator, acao, entidade..."
              className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-sky-400"
            />
          </div>

          <div className="md:col-span-5 flex items-center gap-2">
            <button
              type="submit"
              className="h-10 rounded-lg border border-sky-500/40 bg-sky-600/10 px-4 text-sm font-medium text-sky-200 transition hover:border-sky-400"
            >
              Aplicar filtros
            </button>

            <Link
              href="/painel/auditoria"
              className="h-10 rounded-lg border border-zinc-600 px-4 text-sm font-medium text-zinc-200 transition hover:border-zinc-400 hover:text-zinc-100 inline-flex items-center"
            >
              Limpar
            </Link>

            <p className="text-xs text-zinc-500">{filteredLogs.length} registro(s) encontrado(s)</p>
          </div>

          <div className="md:col-span-5 flex flex-wrap items-center gap-2">
            <Link
              href={exportAuditCsvHref}
              className="h-10 rounded-lg border border-zinc-600 px-4 text-sm font-medium text-zinc-200 transition hover:border-sky-400 hover:text-sky-300 inline-flex items-center"
            >
              Exportar auditoria (CSV)
            </Link>

            <Link
              href={exportAuditPdfHref}
              className="h-10 rounded-lg border border-zinc-600 px-4 text-sm font-medium text-zinc-200 transition hover:border-sky-400 hover:text-sky-300 inline-flex items-center"
            >
              Exportar auditoria (PDF)
            </Link>
          </div>
        </form>

        {hasAuditTableIssue ? (
          <p className="rounded-xl border border-amber-500/40 bg-amber-600/10 p-4 text-sm text-amber-200">
            Para habilitar auditoria, execute o script docs/database/003_etapa11_convites_auditoria.sql no Supabase SQL Editor.
          </p>
        ) : filteredLogs.length === 0 ? (
          <p className="rounded-xl border border-zinc-700/60 bg-zinc-950/60 p-4 text-sm text-zinc-300">
            Nenhum evento de auditoria encontrado para os filtros informados.
          </p>
        ) : (
          <div className="space-y-3">
            {filteredLogs.map((log) => {
              const actor = log.actor_id ? profileById.get(log.actor_id) : null;

              return (
                <article key={log.id} className="rounded-xl border border-zinc-700/60 bg-zinc-950/60 p-4">
                  <div className="grid gap-2 sm:grid-cols-2">
                    <p className="text-xs text-zinc-400">Quando: {formatDate(log.created_at)}</p>
                    <p className="text-xs text-zinc-400 sm:text-right">Acao: {log.action}</p>
                  </div>

                  <div className="mt-2 grid gap-2 sm:grid-cols-2">
                    <p className="text-sm text-zinc-200">Entidade: {log.entity}</p>
                    <p className="text-sm text-zinc-200 sm:text-right">Registro: {log.entity_id ?? "-"}</p>
                  </div>

                  <p className="mt-2 text-xs text-zinc-400">
                    Ator: {actor ? `${actor.nome} (${actor.email})` : log.actor_id ?? "Sistema"}
                  </p>

                  <pre className="mt-3 overflow-x-auto rounded-lg border border-zinc-700/70 bg-zinc-900/70 p-3 text-xs text-zinc-300">
                    {formatMetadata(log.metadata)}
                  </pre>
                </article>
              );
            })}
          </div>
        )}
    </div>
  );
}

```

### Arquivo: src/app/painel/clientes/[id]/page.tsx
```
import Link from "next/link";
import { redirect } from "next/navigation";

import { canAccessModule, getAccessContext } from "@/lib/auth/access";
import type { AppointmentStatus, CustomerRow } from "@/types";

type AppointmentRow = {
  id: string;
  data_hora: string;
  status: AppointmentStatus;
  service_id: string;
  employee_id: string;
  observacoes: string | null;
};

type ServiceRow = {
  id: string;
  nome: string;
};

type EmployeeRow = {
  id: string;
  nome: string;
};

type PaymentRow = {
  id: string;
  appointment_id: string;
  valor: number;
  forma_pagamento: string;
  percentual_comissao: number;
  valor_comissao: number;
  created_at: string;
};

function formatDateTime(value: string): string {
  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return value;
  }

  return new Intl.DateTimeFormat("pt-BR", {
    dateStyle: "short",
    timeStyle: "short",
  }).format(date);
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(value);
}

function getStatusBadge(status: AppointmentStatus): string {
  if (status === "concluido") {
    return "border-emerald-500/40 bg-emerald-600/10 text-emerald-200";
  }

  if (status === "cancelado") {
    return "border-rose-500/40 bg-rose-600/10 text-rose-200";
  }

  return "border-amber-500/40 bg-amber-600/10 text-amber-200";
}

function getStatusLabel(status: AppointmentStatus): string {
  if (status === "concluido") {
    return "Concluido";
  }

  if (status === "cancelado") {
    return "Cancelado";
  }

  return "Agendado";
}

export default async function CustomerHistoryPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { supabase, companyId, role, redirectTo } = await getAccessContext();

  if (!companyId || !role) {
    redirect(redirectTo ?? "/login");
  }

  if (!canAccessModule(role, "clientes")) {
    redirect("/painel");
  }

  const customerResponse = await supabase
    .from("customers")
    .select("id, nome, telefone, email, observacoes, ativo")
    .eq("company_id", companyId)
    .eq("id", id)
    .maybeSingle();

  const hasCustomerTableIssue = Boolean(customerResponse.error?.message.includes("customers"));
  const customer = (customerResponse.data ?? null) as CustomerRow | null;

  if (!hasCustomerTableIssue && !customer) {
    redirect("/painel/clientes");
  }

  const appointmentsResponse = customer
    ? await supabase
        .from("appointments")
        .select("id, data_hora, status, service_id, employee_id, observacoes")
        .eq("company_id", companyId)
        .eq("customer_id", customer.id)
        .order("data_hora", { ascending: false })
        .limit(200)
    : { data: [] as AppointmentRow[], error: null };

  const appointments = (appointmentsResponse.data ?? []) as AppointmentRow[];

  const [servicesResponse, employeesResponse] = await Promise.all([
    supabase.from("services").select("id, nome").eq("company_id", companyId),
    supabase.from("employees").select("id, nome").eq("company_id", companyId),
  ]);

  const services = (servicesResponse.data ?? []) as ServiceRow[];
  const employees = (employeesResponse.data ?? []) as EmployeeRow[];

  const serviceNameById = new Map(services.map((service) => [service.id, service.nome]));
  const employeeNameById = new Map(employees.map((employee) => [employee.id, employee.nome]));

  const appointmentIds = appointments.map((appointment) => appointment.id);
  const paymentsResponse =
    appointmentIds.length > 0
      ? await supabase
          .from("payments")
          .select("id, appointment_id, valor, forma_pagamento, percentual_comissao, valor_comissao, created_at")
          .eq("company_id", companyId)
          .in("appointment_id", appointmentIds)
      : { data: [] as PaymentRow[], error: null };

  const payments = (paymentsResponse.data ?? []) as PaymentRow[];
  const paymentByAppointmentId = new Map(payments.map((payment) => [payment.appointment_id, payment]));

  const totalAppointments = appointments.length;
  const totalConcluded = appointments.filter((appointment) => appointment.status === "concluido").length;
  const totalCanceled = appointments.filter((appointment) => appointment.status === "cancelado").length;
  const totalPaid = payments.reduce((sum, payment) => sum + Number(payment.valor ?? 0), 0);

  return (
    <div className="space-y-5">
        <header className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-semibold text-zinc-100">Historico do cliente</h1>
            <p className="text-sm text-zinc-300">Acompanhe atendimentos e pagamentos vinculados ao cliente selecionado.</p>
          </div>

          <Link
            href="/painel/clientes"
            className="rounded-lg border border-zinc-600 px-4 py-2 text-sm text-zinc-200 transition hover:border-amber-400 hover:text-amber-300"
          >
            Voltar para clientes
          </Link>
        </header>

        {hasCustomerTableIssue ? (
          <div className="rounded-lg border border-rose-500/35 bg-rose-600/10 px-4 py-3 text-sm text-rose-100">
            Seu banco ainda nao foi atualizado para clientes. Execute os scripts docs/database/005_etapa13_clientes.sql e docs/database/006_etapa13_agendamentos_clientes.sql no Supabase SQL Editor.
          </div>
        ) : null}

        {customer ? (
          <div className="grid gap-3 rounded-xl border border-zinc-700/70 bg-zinc-950/60 p-4 sm:grid-cols-2 lg:grid-cols-4">
            <div>
              <p className="text-xs text-zinc-400">Cliente</p>
              <p className="text-sm font-medium text-zinc-100">{customer.nome}</p>
            </div>
            <div>
              <p className="text-xs text-zinc-400">Telefone</p>
              <p className="text-sm font-medium text-zinc-100">{customer.telefone || "Nao informado"}</p>
            </div>
            <div>
              <p className="text-xs text-zinc-400">E-mail</p>
              <p className="text-sm font-medium text-zinc-100">{customer.email || "Nao informado"}</p>
            </div>
            <div>
              <p className="text-xs text-zinc-400">Status</p>
              <p className="text-sm font-medium text-zinc-100">{customer.ativo ? "Ativo" : "Inativo"}</p>
            </div>
          </div>
        ) : null}

        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
          <article className="rounded-lg border border-zinc-700/70 bg-zinc-950/60 p-4">
            <p className="text-xs text-zinc-400">Atendimentos (total)</p>
            <p className="mt-1 text-2xl font-semibold text-zinc-100">{totalAppointments}</p>
          </article>
          <article className="rounded-lg border border-emerald-500/35 bg-emerald-600/10 p-4">
            <p className="text-xs text-emerald-200/80">Concluidos</p>
            <p className="mt-1 text-2xl font-semibold text-emerald-100">{totalConcluded}</p>
          </article>
          <article className="rounded-lg border border-rose-500/35 bg-rose-600/10 p-4">
            <p className="text-xs text-rose-200/80">Cancelados</p>
            <p className="mt-1 text-2xl font-semibold text-rose-100">{totalCanceled}</p>
          </article>
          <article className="rounded-lg border border-sky-500/35 bg-sky-600/10 p-4">
            <p className="text-xs text-sky-200/80">Faturamento pago</p>
            <p className="mt-1 text-2xl font-semibold text-sky-100">{formatCurrency(totalPaid)}</p>
          </article>
        </div>

        <div className="space-y-3">
          <h2 className="text-lg font-medium text-zinc-100">Linha do tempo de atendimentos</h2>

          {appointments.length === 0 ? (
            <p className="rounded-xl border border-zinc-700/60 bg-zinc-950/60 p-4 text-sm text-zinc-300">
              Nenhum atendimento vinculado a este cliente ainda.
            </p>
          ) : (
            <div className="space-y-3">
              {appointments.map((appointment) => {
                const payment = paymentByAppointmentId.get(appointment.id);
                const serviceName = serviceNameById.get(appointment.service_id) ?? "Servico removido";
                const employeeName = employeeNameById.get(appointment.employee_id) ?? "Funcionario removido";

                return (
                  <article key={appointment.id} className="rounded-xl border border-zinc-700/70 bg-zinc-950/60 p-4">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <p className="text-sm font-medium text-zinc-100">{formatDateTime(appointment.data_hora)}</p>
                      <span className={`rounded-full border px-2.5 py-1 text-[11px] font-semibold uppercase tracking-[0.08em] ${getStatusBadge(appointment.status)}`}>
                        {getStatusLabel(appointment.status)}
                      </span>
                    </div>

                    <div className="mt-3 grid gap-2 text-sm text-zinc-300 sm:grid-cols-2">
                      <p>
                        <span className="text-zinc-500">Servico:</span> {serviceName}
                      </p>
                      <p>
                        <span className="text-zinc-500">Funcionario:</span> {employeeName}
                      </p>
                      <p>
                        <span className="text-zinc-500">Pagamento:</span> {payment ? formatCurrency(Number(payment.valor ?? 0)) : "Nao registrado"}
                      </p>
                      <p>
                        <span className="text-zinc-500">Forma:</span> {payment?.forma_pagamento ?? "-"}
                      </p>
                    </div>

                    {appointment.observacoes ? (
                      <p className="mt-3 rounded-lg border border-zinc-700/70 bg-zinc-900/60 px-3 py-2 text-xs text-zinc-400">
                        {appointment.observacoes}
                      </p>
                    ) : null}
                  </article>
                );
              })}
            </div>
          )}
        </div>
    </div>
  );
}

```

### Arquivo: src/app/painel/clientes/actions.ts
```
"use server";

import { revalidatePath } from "next/cache";

import { getAccessContext, isAdmin } from "@/lib/auth/access";

type ActionState = {
  success: boolean;
  message: string;
};

function sanitizeText(value: FormDataEntryValue | null): string {
  if (typeof value !== "string") {
    return "";
  }

  return value.trim();
}

function normalizeNullableText(value: FormDataEntryValue | null): string | null {
  const text = sanitizeText(value);
  return text.length > 0 ? text : null;
}

function isValidEmail(value: string | null): boolean {
  if (!value) {
    return true;
  }

  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

function mapDatabaseError(message: string): string {
  if (message.includes("customers")) {
    return "Seu banco ainda nao foi atualizado para clientes. Execute docs/database/005_etapa13_clientes.sql no Supabase SQL Editor e tente novamente.";
  }

  return message;
}

async function getCompanyScope() {
  return getAccessContext();
}

export async function createCustomerAction(_prevState: ActionState, formData: FormData): Promise<ActionState> {
  const nome = sanitizeText(formData.get("nome"));
  const telefone = normalizeNullableText(formData.get("telefone"));
  const emailRaw = normalizeNullableText(formData.get("email"));
  const email = emailRaw ? emailRaw.toLowerCase() : null;
  const observacoes = normalizeNullableText(formData.get("observacoes"));
  const ativo = formData.get("ativo") === "on";

  if (nome.length < 2) {
    return { success: false, message: "Informe o nome do cliente com pelo menos 2 caracteres." };
  }

  if (!isValidEmail(email)) {
    return { success: false, message: "Informe um e-mail valido para o cliente." };
  }

  const { supabase, companyId, role, errorMessage } = await getCompanyScope();

  if (!companyId) {
    return { success: false, message: errorMessage ?? "Nao foi possivel identificar sua empresa." };
  }

  if (!isAdmin(role)) {
    return { success: false, message: "Apenas administradores podem gerenciar clientes." };
  }

  const { error } = await supabase.from("customers").insert({
    company_id: companyId,
    nome,
    telefone,
    email,
    observacoes,
    ativo,
  });

  if (error) {
    return { success: false, message: `Nao foi possivel criar cliente: ${mapDatabaseError(error.message)}` };
  }

  revalidatePath("/painel/clientes");
  return { success: true, message: "Cliente criado com sucesso." };
}

export async function updateCustomerAction(_prevState: ActionState, formData: FormData): Promise<ActionState> {
  const id = sanitizeText(formData.get("id"));
  const nome = sanitizeText(formData.get("nome"));
  const telefone = normalizeNullableText(formData.get("telefone"));
  const emailRaw = normalizeNullableText(formData.get("email"));
  const email = emailRaw ? emailRaw.toLowerCase() : null;
  const observacoes = normalizeNullableText(formData.get("observacoes"));
  const ativo = formData.get("ativo") === "on";

  if (!id) {
    return { success: false, message: "Cliente invalido para atualizacao." };
  }

  if (nome.length < 2) {
    return { success: false, message: "Informe o nome do cliente com pelo menos 2 caracteres." };
  }

  if (!isValidEmail(email)) {
    return { success: false, message: "Informe um e-mail valido para o cliente." };
  }

  const { supabase, companyId, role, errorMessage } = await getCompanyScope();

  if (!companyId) {
    return { success: false, message: errorMessage ?? "Nao foi possivel identificar sua empresa." };
  }

  if (!isAdmin(role)) {
    return { success: false, message: "Apenas administradores podem gerenciar clientes." };
  }

  const { error } = await supabase
    .from("customers")
    .update({
      nome,
      telefone,
      email,
      observacoes,
      ativo,
    })
    .eq("id", id)
    .eq("company_id", companyId);

  if (error) {
    return { success: false, message: `Nao foi possivel atualizar cliente: ${mapDatabaseError(error.message)}` };
  }

  revalidatePath("/painel/clientes");
  return { success: true, message: "Cliente atualizado com sucesso." };
}

export async function deleteCustomerAction(_prevState: ActionState, formData: FormData): Promise<ActionState> {
  const id = sanitizeText(formData.get("id"));

  if (!id) {
    return { success: false, message: "Cliente invalido para exclusao." };
  }

  const { supabase, companyId, role, errorMessage } = await getCompanyScope();

  if (!companyId) {
    return { success: false, message: errorMessage ?? "Nao foi possivel identificar sua empresa." };
  }

  if (!isAdmin(role)) {
    return { success: false, message: "Apenas administradores podem gerenciar clientes." };
  }

  const { error } = await supabase.from("customers").delete().eq("id", id).eq("company_id", companyId);

  if (error) {
    return { success: false, message: `Nao foi possivel excluir cliente: ${mapDatabaseError(error.message)}` };
  }

  revalidatePath("/painel/clientes");
  return { success: true, message: "Cliente excluido com sucesso." };
}

```

### Arquivo: src/app/painel/clientes/page.tsx
```
import { redirect } from "next/navigation";

import { CreateCustomerForm } from "@/components/painel/clientes/create-customer-form";
import { CustomerItemForm } from "@/components/painel/clientes/customer-item-form";
import { canAccessModule, getAccessContext } from "@/lib/auth/access";
import type { CustomerRow } from "@/types";

export default async function ClientesPage() {
  const { supabase, companyId, role, redirectTo } = await getAccessContext();

  if (!companyId || !role) {
    redirect(redirectTo ?? "/login");
  }

  if (!canAccessModule(role, "clientes")) {
    redirect("/painel");
  }

  const customersResponse = await supabase
    .from("customers")
    .select("id, nome, telefone, email, observacoes, ativo")
    .eq("company_id", companyId)
    .order("created_at", { ascending: false });

  const hasCustomerTableIssue = Boolean(customersResponse.error?.message.includes("customers"));
  const customerRows: CustomerRow[] = (customersResponse.data ?? []) as CustomerRow[];

  return (
    <div className="space-y-5">
        <header className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-semibold text-zinc-100">Clientes</h1>
            <p className="text-sm text-zinc-300">Cadastre e mantenha sua base de clientes com dados de contato.</p>
          </div>
        </header>

        {hasCustomerTableIssue ? (
          <div className="rounded-lg border border-rose-500/35 bg-rose-600/10 px-4 py-3 text-sm text-rose-100">
            Seu banco ainda nao foi atualizado para clientes. Execute o script docs/database/005_etapa13_clientes.sql no Supabase SQL Editor.
          </div>
        ) : (
          <>
            <CreateCustomerForm />

            <div className="space-y-3">
              <h2 className="text-lg font-medium text-zinc-100">Lista de clientes</h2>

              {customerRows.length === 0 ? (
                <p className="rounded-xl border border-zinc-700/60 bg-zinc-950/60 p-4 text-sm text-zinc-300">
                  Nenhum cliente cadastrado ainda.
                </p>
              ) : (
                <div className="space-y-3">
                  {customerRows.map((customer) => (
                    <CustomerItemForm key={customer.id} customer={customer} />
                  ))}
                </div>
              )}
            </div>
          </>
        )}
    </div>
  );
}

```

### Arquivo: src/app/painel/equipe/actions.ts
```
"use server";

import { revalidatePath } from "next/cache";
import { randomUUID } from "node:crypto";

import { getAccessContext, isAdmin, type UserRole } from "@/lib/auth/access";
import { notifySensitiveEvent } from "@/lib/notifications/sensitive-events";

type ActionState = {
  success: boolean;
  message: string;
};

const ALLOWED_ROLES: UserRole[] = ["admin", "employee"];

function sanitizeEmail(value: FormDataEntryValue | null): string {
  return sanitizeText(value).toLowerCase();
}

function isValidEmail(value: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

function mapInviteDatabaseError(message: string): string {
  if (message.includes("team_invites")) {
    return "Seu banco ainda nao foi atualizado para convites da equipe. Execute o script docs/database/003_etapa11_convites_auditoria.sql no Supabase SQL Editor e tente novamente.";
  }

  return message;
}

async function writeAuditLog(params: {
  supabase: Awaited<ReturnType<typeof getAccessContext>>["supabase"];
  companyId: string;
  actorId: string;
  action: string;
  entity: string;
  entityId: string;
  metadata?: Record<string, unknown>;
}) {
  const { error } = await params.supabase.from("audit_logs").insert({
    company_id: params.companyId,
    actor_id: params.actorId,
    action: params.action,
    entity: params.entity,
    entity_id: params.entityId,
    metadata: params.metadata ?? {},
  });

  if (error && !error.message.includes("audit_logs")) {
    // Evita quebrar fluxo principal caso o log falhe por motivo secundario.
  }
}

function sanitizeText(value: FormDataEntryValue | null): string {
  if (typeof value !== "string") {
    return "";
  }

  return value.trim();
}

function isRole(value: string): value is UserRole {
  return ALLOWED_ROLES.includes(value as UserRole);
}

export async function updateMemberRoleAction(_prevState: ActionState, formData: FormData): Promise<ActionState> {
  const memberId = sanitizeText(formData.get("member_id"));
  const roleInput = sanitizeText(formData.get("role"));

  if (!memberId) {
    return { success: false, message: "Membro invalido para atualizacao." };
  }

  if (!isRole(roleInput)) {
    return { success: false, message: "Papel de acesso invalido." };
  }

  const { supabase, userId, companyId, role, errorMessage } = await getAccessContext();

  if (!companyId || !userId || !role) {
    return { success: false, message: errorMessage ?? "Nao foi possivel identificar sua empresa." };
  }

  if (!isAdmin(role)) {
    return { success: false, message: "Apenas administradores podem alterar papeis da equipe." };
  }

  const { data: memberProfile } = await supabase
    .from("profiles")
    .select("id, role")
    .eq("id", memberId)
    .eq("company_id", companyId)
    .maybeSingle();

  if (!memberProfile) {
    return { success: false, message: "Membro nao encontrado na sua empresa." };
  }

  if (memberProfile.role === roleInput) {
    return { success: true, message: "Papel ja estava atualizado." };
  }

  if (memberId === userId && roleInput !== "admin") {
    return { success: false, message: "Voce nao pode remover seu proprio acesso de administrador." };
  }

  if (memberProfile.role === "admin" && roleInput === "employee") {
    const { count: adminsCount, error: countError } = await supabase
      .from("profiles")
      .select("id", { count: "exact", head: true })
      .eq("company_id", companyId)
      .eq("role", "admin");

    if (countError) {
      return { success: false, message: "Nao foi possivel validar a quantidade de administradores." };
    }

    if ((adminsCount ?? 0) <= 1) {
      return { success: false, message: "Sua empresa precisa manter pelo menos um administrador." };
    }
  }

  const { error } = await supabase
    .from("profiles")
    .update({ role: roleInput })
    .eq("id", memberId)
    .eq("company_id", companyId);

  if (error) {
    return { success: false, message: `Nao foi possivel atualizar o papel: ${error.message}` };
  }

  await writeAuditLog({
    supabase,
    companyId,
    actorId: userId,
    action: "member_role_updated",
    entity: "profiles",
    entityId: memberId,
    metadata: { role: roleInput },
  });

  await notifySensitiveEvent({
    supabase,
    companyId,
    actorId: userId,
    eventKey: "member_role_updated",
    title: "Papel de membro alterado",
    message: `Um papel de acesso foi alterado para ${roleInput}.`,
    severity: "critical",
    metadata: { memberId, role: roleInput },
  });

  revalidatePath("/painel/equipe");
  revalidatePath("/painel");
  return { success: true, message: "Papel atualizado com sucesso." };
}

export async function createTeamInviteAction(_prevState: ActionState, formData: FormData): Promise<ActionState> {
  const email = sanitizeEmail(formData.get("email"));
  const roleInput = sanitizeText(formData.get("role"));

  if (!isValidEmail(email)) {
    return { success: false, message: "Informe um e-mail valido para convite." };
  }

  if (!isRole(roleInput)) {
    return { success: false, message: "Papel de acesso invalido para convite." };
  }

  const { supabase, userId, companyId, role, errorMessage } = await getAccessContext();

  if (!companyId || !userId || !role) {
    return { success: false, message: errorMessage ?? "Nao foi possivel identificar sua empresa." };
  }

  if (!isAdmin(role)) {
    return { success: false, message: "Apenas administradores podem convidar novos membros." };
  }

  const { data: existingMember } = await supabase
    .from("profiles")
    .select("id")
    .eq("company_id", companyId)
    .eq("email", email)
    .maybeSingle();

  if (existingMember) {
    return { success: false, message: "Esse e-mail ja pertence a um membro da sua empresa." };
  }

  const token = randomUUID().replaceAll("-", "");
  const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();

  const { data: pendingInvite } = await supabase
    .from("team_invites")
    .select("id")
    .eq("company_id", companyId)
    .eq("email", email)
    .eq("status", "pending")
    .maybeSingle();

  if (pendingInvite) {
    const { error: updateInviteError } = await supabase
      .from("team_invites")
      .update({
        role: roleInput,
        token,
        expires_at: expiresAt,
        invited_by: userId,
      })
      .eq("id", pendingInvite.id)
      .eq("company_id", companyId);

    if (updateInviteError) {
      return {
        success: false,
        message: `Nao foi possivel atualizar convite existente: ${mapInviteDatabaseError(updateInviteError.message)}`,
      };
    }

    await writeAuditLog({
      supabase,
      companyId,
      actorId: userId,
      action: "team_invite_updated",
      entity: "team_invites",
      entityId: pendingInvite.id,
      metadata: { email, role: roleInput },
    });

    await notifySensitiveEvent({
      supabase,
      companyId,
      actorId: userId,
      eventKey: "team_invite_updated",
      title: "Convite de equipe atualizado",
      message: `Um convite pendente para ${email} foi atualizado.`,
      severity: "warning",
      metadata: { email, role: roleInput, inviteId: pendingInvite.id },
    });

    revalidatePath("/painel/equipe");
    return { success: true, message: "Convite pendente atualizado com sucesso." };
  }

  const { error } = await supabase.from("team_invites").insert({
    company_id: companyId,
    email,
    role: roleInput,
    token,
    invited_by: userId,
    status: "pending",
    expires_at: expiresAt,
  });

  if (error) {
    return {
      success: false,
      message: `Nao foi possivel criar convite: ${mapInviteDatabaseError(error.message)}`,
    };
  }

  await writeAuditLog({
    supabase,
    companyId,
    actorId: userId,
    action: "team_invite_created",
    entity: "team_invites",
    entityId: token,
    metadata: { email, role: roleInput },
  });

  await notifySensitiveEvent({
    supabase,
    companyId,
    actorId: userId,
    eventKey: "team_invite_created",
    title: "Novo convite de equipe criado",
    message: `Um novo convite foi gerado para ${email}.`,
    severity: "warning",
    metadata: { email, role: roleInput, token },
  });

  revalidatePath("/painel/equipe");
  return { success: true, message: "Convite criado com sucesso. Compartilhe o link com o novo membro." };
}

export async function revokeTeamInviteAction(_prevState: ActionState, formData: FormData): Promise<ActionState> {
  const inviteId = sanitizeText(formData.get("invite_id"));

  if (!inviteId) {
    return { success: false, message: "Convite invalido para revogacao." };
  }

  const { supabase, userId, companyId, role, errorMessage } = await getAccessContext();

  if (!companyId || !userId || !role) {
    return { success: false, message: errorMessage ?? "Nao foi possivel identificar sua empresa." };
  }

  if (!isAdmin(role)) {
    return { success: false, message: "Apenas administradores podem revogar convites." };
  }

  const { error } = await supabase
    .from("team_invites")
    .update({ status: "revoked" })
    .eq("id", inviteId)
    .eq("company_id", companyId)
    .eq("status", "pending");

  if (error) {
    return {
      success: false,
      message: `Nao foi possivel revogar convite: ${mapInviteDatabaseError(error.message)}`,
    };
  }

  await writeAuditLog({
    supabase,
    companyId,
    actorId: userId,
    action: "team_invite_revoked",
    entity: "team_invites",
    entityId: inviteId,
  });

  await notifySensitiveEvent({
    supabase,
    companyId,
    actorId: userId,
    eventKey: "team_invite_revoked",
    title: "Convite de equipe revogado",
    message: "Um convite pendente da equipe foi revogado por um administrador.",
    severity: "warning",
    metadata: { inviteId },
  });

  revalidatePath("/painel/equipe");
  return { success: true, message: "Convite revogado com sucesso." };
}

```

### Arquivo: src/app/painel/equipe/page.tsx
```
import { redirect } from "next/navigation";

import { CreateTeamInviteForm } from "@/components/painel/equipe/create-team-invite-form";
import { TeamInviteItem } from "@/components/painel/equipe/team-invite-item";
import { TeamMemberRoleForm } from "@/components/painel/equipe/team-member-role-form";
import { canAccessModule, getAccessContext, type UserRole } from "@/lib/auth/access";

type TeamMemberRow = {
  id: string;
  nome: string;
  email: string;
  role: UserRole;
};

type InviteStatus = "pending" | "accepted" | "revoked" | "expired";

type TeamInviteRow = {
  id: string;
  email: string;
  role: UserRole;
  status: InviteStatus;
  token: string;
  expires_at: string;
};

export default async function EquipePage() {
  const { supabase, userId, companyId, role, redirectTo } = await getAccessContext();

  if (!companyId || !role || !userId) {
    redirect(redirectTo ?? "/login");
  }

  if (!canAccessModule(role, "equipe")) {
    redirect("/painel");
  }

  const { data: profiles } = await supabase
    .from("profiles")
    .select("id, nome, email, role")
    .eq("company_id", companyId)
    .order("created_at", { ascending: true });

  const invitesResponse = await supabase
    .from("team_invites")
    .select("id, email, role, status, token, expires_at")
    .eq("company_id", companyId)
    .order("created_at", { ascending: false });

  const members = (profiles ?? []) as TeamMemberRow[];
  const invites = (invitesResponse.data ?? []) as TeamInviteRow[];
  const hasInviteTableIssue = Boolean(invitesResponse.error?.message.includes("team_invites"));

  return (
    <div className="space-y-5">
        <header className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-semibold text-zinc-100">Equipe, convites e papeis</h1>
            <p className="text-sm text-zinc-300">Gerencie papeis e convites de acesso da equipe da sua empresa.</p>
          </div>
        </header>

        <div className="space-y-3">
          <h2 className="text-lg font-medium text-zinc-100">Membros da equipe</h2>

          {members.length === 0 ? (
            <p className="rounded-xl border border-zinc-700/60 bg-zinc-950/60 p-4 text-sm text-zinc-300">
              Nenhum membro encontrado para esta empresa.
            </p>
          ) : (
            <div className="space-y-3">
              {members.map((member) => (
                <TeamMemberRoleForm key={member.id} member={member} isCurrentUser={member.id === userId} />
              ))}
            </div>
          )}
        </div>

        <div className="space-y-3">
          <h2 className="text-lg font-medium text-zinc-100">Convites por e-mail</h2>

          {hasInviteTableIssue ? (
            <p className="rounded-xl border border-amber-500/40 bg-amber-600/10 p-4 text-sm text-amber-200">
              Para habilitar convites, execute o script docs/database/003_etapa11_convites_auditoria.sql no Supabase SQL Editor.
            </p>
          ) : (
            <>
              <CreateTeamInviteForm />

              {invites.length === 0 ? (
                <p className="rounded-xl border border-zinc-700/60 bg-zinc-950/60 p-4 text-sm text-zinc-300">
                  Nenhum convite enviado ainda.
                </p>
              ) : (
                <div className="space-y-3">
                  {invites.map((invite) => (
                    <TeamInviteItem
                      key={invite.id}
                      invite={{
                        id: invite.id,
                        email: invite.email,
                        role: invite.role,
                        status: invite.status,
                        token: invite.token,
                        expiresAt: invite.expires_at,
                      }}
                    />
                  ))}
                </div>
              )}
            </>
          )}
        </div>
    </div>
  );
}

```

### Arquivo: src/app/painel/financeiro/actions.ts
```
"use server";

import { revalidatePath } from "next/cache";

import { createSupabaseServerClient } from "@/lib/supabase/server";
import { getAccessContext, isAdmin } from "@/lib/auth/access";

type ActionState = {
  success: boolean;
  message: string;
};

type AppointmentRow = {
  id: string;
  status: "agendado" | "concluido" | "cancelado";
  service_id: string;
  employee_id: string;
};

type ServiceRow = {
  id: string;
  valor: number;
};

type EmployeeRow = {
  id: string;
  percentual_comissao: number;
};

function sanitizeText(value: FormDataEntryValue | null): string {
  if (typeof value !== "string") {
    return "";
  }

  return value.trim();
}

function sanitizeMoney(value: FormDataEntryValue | null): number {
  const textValue = sanitizeText(value).replace(",", ".");
  const parsedValue = Number(textValue);

  if (!Number.isFinite(parsedValue)) {
    return Number.NaN;
  }

  return parsedValue;
}

function roundToTwo(value: number): number {
  return Math.round(value * 100) / 100;
}

async function getCompanyScope() {
  return getAccessContext();
}

async function getAppointmentFinancialContext(
  params: {
    appointmentId: string;
    companyId: string;
  },
  supabase: Awaited<ReturnType<typeof createSupabaseServerClient>>,
): Promise<{
  appointment: AppointmentRow | null;
  service: ServiceRow | null;
  employee: EmployeeRow | null;
}> {
  const { data: appointment } = await supabase
    .from("appointments")
    .select("id, status, service_id, employee_id")
    .eq("id", params.appointmentId)
    .eq("company_id", params.companyId)
    .maybeSingle();

  if (!appointment) {
    return { appointment: null, service: null, employee: null };
  }

  const [serviceResponse, employeeResponse] = await Promise.all([
    supabase
      .from("services")
      .select("id, valor")
      .eq("id", appointment.service_id)
      .eq("company_id", params.companyId)
      .maybeSingle(),
    supabase
      .from("employees")
      .select("id, percentual_comissao")
      .eq("id", appointment.employee_id)
      .eq("company_id", params.companyId)
      .maybeSingle(),
  ]);

  return {
    appointment: appointment as AppointmentRow,
    service: (serviceResponse.data ?? null) as ServiceRow | null,
    employee: (employeeResponse.data ?? null) as EmployeeRow | null,
  };
}

function validateFinancialInput(params: {
  formaPagamento: string;
  valor: number;
  percentualComissao: number;
}): string | null {
  if (!params.formaPagamento) {
    return "Informe a forma de pagamento.";
  }

  if (!Number.isFinite(params.valor) || params.valor < 0) {
    return "Informe um valor valido para o pagamento.";
  }

  if (!Number.isFinite(params.percentualComissao) || params.percentualComissao < 0 || params.percentualComissao > 100) {
    return "Informe percentual de comissao entre 0 e 100.";
  }

  return null;
}

export async function createPaymentAction(_prevState: ActionState, formData: FormData): Promise<ActionState> {
  const appointmentId = sanitizeText(formData.get("appointment_id"));
  const formaPagamento = sanitizeText(formData.get("forma_pagamento"));
  const valorInput = sanitizeMoney(formData.get("valor"));
  const percentualInput = sanitizeMoney(formData.get("percentual_comissao"));

  if (!appointmentId) {
    return { success: false, message: "Selecione um agendamento concluido." };
  }

  const { supabase, companyId, role, errorMessage } = await getCompanyScope();

  if (!companyId) {
    return { success: false, message: errorMessage ?? "Nao foi possivel identificar sua empresa." };
  }

  if (!isAdmin(role)) {
    return { success: false, message: "Apenas administradores podem gerenciar financeiro." };
  }

  const context = await getAppointmentFinancialContext({ appointmentId, companyId }, supabase);

  if (!context.appointment) {
    return { success: false, message: "Agendamento invalido para sua empresa." };
  }

  if (context.appointment.status !== "concluido") {
    return { success: false, message: "Somente agendamentos concluidos podem gerar pagamento." };
  }

  if (!context.service || !context.employee) {
    return { success: false, message: "Nao foi possivel obter dados de servico/funcionario deste agendamento." };
  }

  const valor = Number.isFinite(valorInput) ? valorInput : Number(context.service.valor);
  const percentualComissao = Number.isFinite(percentualInput)
    ? percentualInput
    : Number(context.employee.percentual_comissao);

  const inputError = validateFinancialInput({ formaPagamento, valor, percentualComissao });

  if (inputError) {
    return { success: false, message: inputError };
  }

  const valorComissao = roundToTwo((valor * percentualComissao) / 100);

  const { data: existingPayment } = await supabase
    .from("payments")
    .select("id")
    .eq("appointment_id", appointmentId)
    .eq("company_id", companyId)
    .maybeSingle();

  if (existingPayment) {
    return { success: false, message: "Este agendamento ja possui pagamento registrado." };
  }

  const { error } = await supabase.from("payments").insert({
    company_id: companyId,
    appointment_id: appointmentId,
    valor,
    forma_pagamento: formaPagamento,
    percentual_comissao: percentualComissao,
    valor_comissao: valorComissao,
  });

  if (error) {
    return { success: false, message: `Nao foi possivel registrar pagamento: ${error.message}` };
  }

  revalidatePath("/painel/financeiro");
  return { success: true, message: "Pagamento registrado com sucesso." };
}

export async function updatePaymentAction(_prevState: ActionState, formData: FormData): Promise<ActionState> {
  const id = sanitizeText(formData.get("id"));
  const formaPagamento = sanitizeText(formData.get("forma_pagamento"));
  const valor = sanitizeMoney(formData.get("valor"));
  const percentualComissao = sanitizeMoney(formData.get("percentual_comissao"));

  if (!id) {
    return { success: false, message: "Pagamento invalido para atualizacao." };
  }

  const inputError = validateFinancialInput({ formaPagamento, valor, percentualComissao });

  if (inputError) {
    return { success: false, message: inputError };
  }

  const { supabase, companyId, role, errorMessage } = await getCompanyScope();

  if (!companyId) {
    return { success: false, message: errorMessage ?? "Nao foi possivel identificar sua empresa." };
  }

  if (!isAdmin(role)) {
    return { success: false, message: "Apenas administradores podem gerenciar financeiro." };
  }

  const { data: payment } = await supabase
    .from("payments")
    .select("id, appointment_id")
    .eq("id", id)
    .eq("company_id", companyId)
    .maybeSingle();

  if (!payment) {
    return { success: false, message: "Pagamento nao encontrado para sua empresa." };
  }

  const { data: appointment } = await supabase
    .from("appointments")
    .select("status")
    .eq("id", payment.appointment_id)
    .eq("company_id", companyId)
    .maybeSingle();

  if (!appointment || appointment.status !== "concluido") {
    return { success: false, message: "Pagamento so pode ser mantido em agendamento concluido." };
  }

  const valorComissao = roundToTwo((valor * percentualComissao) / 100);

  const { error } = await supabase
    .from("payments")
    .update({
      forma_pagamento: formaPagamento,
      valor,
      percentual_comissao: percentualComissao,
      valor_comissao: valorComissao,
    })
    .eq("id", id)
    .eq("company_id", companyId);

  if (error) {
    return { success: false, message: `Nao foi possivel atualizar pagamento: ${error.message}` };
  }

  revalidatePath("/painel/financeiro");
  return { success: true, message: "Pagamento atualizado com sucesso." };
}

export async function deletePaymentAction(_prevState: ActionState, formData: FormData): Promise<ActionState> {
  const id = sanitizeText(formData.get("id"));

  if (!id) {
    return { success: false, message: "Pagamento invalido para exclusao." };
  }

  const { supabase, companyId, role, errorMessage } = await getCompanyScope();

  if (!companyId) {
    return { success: false, message: errorMessage ?? "Nao foi possivel identificar sua empresa." };
  }

  if (!isAdmin(role)) {
    return { success: false, message: "Apenas administradores podem gerenciar financeiro." };
  }

  const { error } = await supabase.from("payments").delete().eq("id", id).eq("company_id", companyId);

  if (error) {
    return { success: false, message: `Nao foi possivel excluir pagamento: ${error.message}` };
  }

  revalidatePath("/painel/financeiro");
  return { success: true, message: "Pagamento excluido com sucesso." };
}

```

### Arquivo: src/app/painel/financeiro/page.tsx
```
import { redirect } from "next/navigation";

import { CreatePaymentForm } from "@/components/painel/financeiro/create-payment-form";
import { PaymentItemForm } from "@/components/painel/financeiro/payment-item-form";
import { canAccessModule, getAccessContext } from "@/lib/auth/access";

type AppointmentRow = {
  id: string;
  cliente_nome: string;
  data_hora: string;
  status: "agendado" | "concluido" | "cancelado";
  service_id: string;
  employee_id: string;
};

type ServiceRow = {
  id: string;
  valor: number;
};

type EmployeeRow = {
  id: string;
  nome: string;
  percentual_comissao: number;
};

type PaymentRow = {
  id: string;
  appointment_id: string;
  created_at: string;
  valor: number;
  forma_pagamento: string;
  percentual_comissao: number;
  valor_comissao: number;
  appointments:
    | {
        cliente_nome: string;
        data_hora: string;
        employee_id: string;
      }
    | {
        cliente_nome: string;
        data_hora: string;
        employee_id: string;
      }[]
    | null;
};

type AppointmentOption = {
  id: string;
  clienteNome: string;
  dataHora: string;
  valorSugerido: number;
  percentualComissaoSugerido: number;
};

type EmployeeFinancialSummary = {
  id: string;
  nome: string;
  percentualComissao: number;
  quantidadePagamentos: number;
  faturamento: number;
  comissaoTotal: number;
};

type SearchParams = {
  start?: string;
  end?: string;
};

function roundToTwo(value: number): number {
  return Math.round(value * 100) / 100;
}

function getPaymentAppointmentData(
  appointments: PaymentRow["appointments"],
): { clienteNome: string; dataHora: string } {
  const appointment = Array.isArray(appointments) ? appointments[0] : appointments;

  return {
    clienteNome: appointment?.cliente_nome ?? "Cliente nao encontrado",
    dataHora: appointment?.data_hora ?? "",
  };
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(value);
}

function toDateInputValue(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
}

function normalizeDateInput(value: string | undefined, fallback: string): string {
  if (!value) {
    return fallback;
  }

  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    return fallback;
  }

  return value;
}

export default async function FinanceiroPage({
  searchParams,
}: {
  searchParams?: Promise<SearchParams>;
}) {
  const resolvedSearchParams = (await searchParams) ?? {};
  const { supabase, companyId, role, redirectTo } = await getAccessContext();

  if (!companyId || !role) {
    redirect(redirectTo ?? "/login");
  }

  if (!canAccessModule(role, "financeiro")) {
    redirect("/painel");
  }

  const now = new Date();
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
  const defaultStart = toDateInputValue(startOfMonth);
  const defaultEnd = toDateInputValue(now);

  const start = normalizeDateInput(resolvedSearchParams.start, defaultStart);
  const end = normalizeDateInput(resolvedSearchParams.end, defaultEnd);

  const startDate = new Date(`${start}T00:00:00.000`);
  const endDate = new Date(`${end}T23:59:59.999`);

  const [appointmentsResponse, servicesResponse, employeesResponse, paymentsResponse] = await Promise.all([
    supabase
      .from("appointments")
      .select("id, cliente_nome, data_hora, status, service_id, employee_id")
      .eq("company_id", companyId)
      .eq("status", "concluido")
      .order("data_hora", { ascending: false }),
    supabase.from("services").select("id, valor").eq("company_id", companyId),
    supabase.from("employees").select("id, nome, percentual_comissao").eq("company_id", companyId),
    supabase
      .from("payments")
      .select("id, appointment_id, created_at, valor, forma_pagamento, percentual_comissao, valor_comissao, appointments(cliente_nome, data_hora, employee_id)")
      .eq("company_id", companyId)
      .order("created_at", { ascending: false }),
  ]);

  const appointments = (appointmentsResponse.data ?? []) as AppointmentRow[];
  const services = (servicesResponse.data ?? []) as ServiceRow[];
  const employees = (employeesResponse.data ?? []) as EmployeeRow[];
  const payments = (paymentsResponse.data ?? []) as PaymentRow[];

  const serviceValueById = new Map(services.map((service) => [service.id, Number(service.valor)]));
  const employeeCommissionById = new Map(employees.map((employee) => [employee.id, Number(employee.percentual_comissao)]));
  const employeeNameById = new Map(employees.map((employee) => [employee.id, employee.nome]));
  const appointmentEmployeeById = new Map(appointments.map((appointment) => [appointment.id, appointment.employee_id]));

  const paidAppointmentIds = new Set(payments.map((payment) => payment.appointment_id));

  const filteredPayments = payments.filter((payment) => {
    const createdAt = new Date(payment.created_at);

    if (Number.isNaN(createdAt.getTime())) {
      return false;
    }

    return createdAt >= startDate && createdAt <= endDate;
  });

  const employeeFinancialMap = new Map<string, EmployeeFinancialSummary>(
    employees.map((employee) => [
      employee.id,
      {
        id: employee.id,
        nome: employee.nome,
        percentualComissao: roundToTwo(Number(employee.percentual_comissao ?? 0)),
        quantidadePagamentos: 0,
        faturamento: 0,
        comissaoTotal: 0,
      },
    ]),
  );

  for (const payment of filteredPayments) {
    const appointmentEmployeeId = appointmentEmployeeById.get(payment.appointment_id);

    if (!appointmentEmployeeId) {
      continue;
    }

    const summary = employeeFinancialMap.get(appointmentEmployeeId);

    if (!summary) {
      employeeFinancialMap.set(appointmentEmployeeId, {
        id: appointmentEmployeeId,
        nome: employeeNameById.get(appointmentEmployeeId) ?? "Funcionario nao encontrado",
        percentualComissao: 0,
        quantidadePagamentos: 1,
        faturamento: Number(payment.valor),
        comissaoTotal: Number(payment.valor_comissao),
      });
      continue;
    }

    summary.quantidadePagamentos += 1;
    summary.faturamento += Number(payment.valor);
    summary.comissaoTotal += Number(payment.valor_comissao);
  }

  const employeeFinancialSummaries = [...employeeFinancialMap.values()]
    .map((summary) => ({
      ...summary,
      faturamento: roundToTwo(summary.faturamento),
      comissaoTotal: roundToTwo(summary.comissaoTotal),
    }))
    .sort((left, right) => right.comissaoTotal - left.comissaoTotal);

  const totalFaturamento = roundToTwo(payments.reduce((sum, payment) => sum + Number(payment.valor ?? 0), 0));
  const totalComissao = roundToTwo(filteredPayments.reduce((sum, payment) => sum + Number(payment.valor_comissao ?? 0), 0));

  const availableAppointments: AppointmentOption[] = appointments
    .filter((appointment) => !paidAppointmentIds.has(appointment.id))
    .map((appointment) => {
      const valorSugerido = Number(serviceValueById.get(appointment.service_id) ?? 0);
      const percentualComissaoSugerido = Number(employeeCommissionById.get(appointment.employee_id) ?? 0);

      return {
        id: appointment.id,
        clienteNome: appointment.cliente_nome,
        dataHora: appointment.data_hora,
        valorSugerido: roundToTwo(valorSugerido),
        percentualComissaoSugerido: roundToTwo(percentualComissaoSugerido),
      };
    });

  const paymentItems = filteredPayments.map((payment) => {
    const appointmentData = getPaymentAppointmentData(payment.appointments);

    return {
      id: payment.id,
      appointmentId: payment.appointment_id,
      createdAt: payment.created_at,
      clienteNome: appointmentData.clienteNome,
      dataHora: appointmentData.dataHora,
      valor: Number(payment.valor),
      formaPagamento: payment.forma_pagamento,
      percentualComissao: Number(payment.percentual_comissao),
      valorComissao: Number(payment.valor_comissao),
    };
  });

  return (
    <div className="space-y-5">
        <header className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-semibold text-zinc-100">Financeiro</h1>
            <p className="text-sm text-zinc-300">Registre pagamentos, acompanhe o faturamento total e veja a comissao por funcionario.</p>
          </div>
        </header>

        <form className="grid gap-3 rounded-xl border border-zinc-700/60 bg-zinc-950/60 p-4 md:grid-cols-3">
          <div className="space-y-1">
            <label htmlFor="financeiro-start" className="text-sm text-zinc-200">
              Data inicial
            </label>
            <input
              id="financeiro-start"
              name="start"
              type="date"
              defaultValue={start}
              className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
              required
            />
          </div>

          <div className="space-y-1">
            <label htmlFor="financeiro-end" className="text-sm text-zinc-200">
              Data final
            </label>
            <input
              id="financeiro-end"
              name="end"
              type="date"
              defaultValue={end}
              className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
              required
            />
          </div>

          <div className="flex items-end">
            <button
              type="submit"
              className="h-10 rounded-lg border border-zinc-600 bg-zinc-900 px-4 text-sm font-medium text-zinc-100 transition hover:border-amber-400 hover:text-amber-300"
            >
              Atualizar periodo
            </button>
          </div>
        </form>

        {availableAppointments.length === 0 ? (
          <p className="rounded-xl border border-amber-500/40 bg-amber-600/10 p-4 text-sm text-amber-200">
            Nao ha agendamentos concluidos disponiveis para novo pagamento.
          </p>
        ) : (
          <CreatePaymentForm appointments={availableAppointments} />
        )}

        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
          <article className="min-h-28 rounded-2xl border border-zinc-700/70 bg-zinc-950/60 p-5 shadow-lg shadow-black/10">
            <p className="text-xs text-zinc-400">Faturamento total</p>
            <p className="mt-2 text-3xl font-semibold text-zinc-100">{formatCurrency(totalFaturamento)}</p>
          </article>

          <article className="min-h-28 rounded-2xl border border-emerald-500/35 bg-emerald-600/10 p-5 shadow-lg shadow-emerald-950/20">
            <p className="text-xs text-emerald-200/80">Comissao total</p>
            <p className="mt-2 text-3xl font-semibold text-emerald-100">{formatCurrency(totalComissao)}</p>
          </article>

          <article className="min-h-28 rounded-2xl border border-amber-500/35 bg-amber-600/10 p-5 shadow-lg shadow-amber-950/20">
            <p className="text-xs text-amber-200/80">Pagamentos registrados</p>
            <p className="mt-2 text-3xl font-semibold text-amber-100">{paymentItems.length}</p>
          </article>

          <article className="min-h-28 rounded-2xl border border-sky-500/35 bg-sky-600/10 p-5 shadow-lg shadow-sky-950/20">
            <p className="text-xs text-sky-200/80">Funcionarios com vendas</p>
            <p className="mt-2 text-3xl font-semibold text-sky-100">
              {employeeFinancialSummaries.filter((summary) => summary.quantidadePagamentos > 0).length}
            </p>
          </article>
        </div>

        <div className="space-y-3 rounded-2xl border border-zinc-700/60 bg-zinc-950/60 p-5 shadow-lg shadow-black/10">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className="text-lg font-medium text-zinc-100">Faturamento por funcionario</h2>
              <p className="text-sm text-zinc-400">Valores calculados com base nos pagamentos concluidos.</p>
            </div>
          </div>

          {employeeFinancialSummaries.length === 0 ? (
            <p className="rounded-lg border border-zinc-700/60 bg-zinc-900/60 p-4 text-sm text-zinc-300">
              Nenhum funcionario cadastrado ainda.
            </p>
          ) : (
            <div className="space-y-3">
              {employeeFinancialSummaries.map((summary) => (
                <article key={summary.id} className="grid gap-3 rounded-xl border border-zinc-700/70 bg-zinc-900/80 p-5 md:grid-cols-4">
                  <div>
                    <p className="text-xs text-zinc-400">Funcionario</p>
                    <p className="text-sm font-medium text-zinc-100">{summary.nome}</p>
                  </div>

                  <div>
                    <p className="text-xs text-zinc-400">Faturamento</p>
                    <p className="text-sm text-zinc-100">{formatCurrency(summary.faturamento)}</p>
                  </div>

                  <div>
                    <p className="text-xs text-zinc-400">Comissao</p>
                    <p className="text-sm text-zinc-100">{formatCurrency(summary.comissaoTotal)}</p>
                  </div>

                  <div>
                    <p className="text-xs text-zinc-400">Pagamentos</p>
                    <p className="text-sm text-zinc-100">
                      {summary.quantidadePagamentos} | {summary.percentualComissao.toFixed(2)}%
                    </p>
                  </div>
                </article>
              ))}
            </div>
          )}
        </div>

        <div className="space-y-3">
          <h2 className="text-lg font-medium text-zinc-100">Lista de pagamentos</h2>

          {paymentItems.length === 0 ? (
            <p className="rounded-xl border border-zinc-700/60 bg-zinc-950/60 p-4 text-sm text-zinc-300">
              Nenhum pagamento registrado ainda.
            </p>
          ) : (
            <div className="space-y-3">
              {paymentItems.map((payment) => (
                <PaymentItemForm key={payment.id} payment={payment} />
              ))}
            </div>
          )}
        </div>
    </div>
  );
}

```

### Arquivo: src/app/painel/funcionarios/actions.ts
```
"use server";

import { revalidatePath } from "next/cache";

import { getAccessContext, isAdmin } from "@/lib/auth/access";

type ActionState = {
  success: boolean;
  message: string;
};

function sanitizeText(value: FormDataEntryValue | null): string {
  if (typeof value !== "string") {
    return "";
  }

  return value.trim();
}

function sanitizePercentual(value: FormDataEntryValue | null): number {
  const textValue = sanitizeText(value).replace(",", ".");
  const parsedValue = Number(textValue);

  if (!Number.isFinite(parsedValue)) {
    return Number.NaN;
  }

  return parsedValue;
}

async function getCompanyScope() {
  return getAccessContext();
}

export async function createEmployeeAction(_prevState: ActionState, formData: FormData): Promise<ActionState> {
  const nome = sanitizeText(formData.get("nome"));
  const telefone = sanitizeText(formData.get("telefone"));
  const percentualComissao = sanitizePercentual(formData.get("percentual_comissao"));
  const ativo = formData.get("ativo") === "on";

  if (nome.length < 2) {
    return { success: false, message: "Informe o nome do funcionario com pelo menos 2 caracteres." };
  }

  if (!Number.isFinite(percentualComissao) || percentualComissao < 0 || percentualComissao > 100) {
    return { success: false, message: "Informe um percentual de comissao entre 0 e 100." };
  }

  const { supabase, companyId, role, errorMessage } = await getCompanyScope();

  if (!companyId) {
    return { success: false, message: errorMessage ?? "Nao foi possivel identificar sua empresa." };
  }

  if (!isAdmin(role)) {
    return { success: false, message: "Apenas administradores podem gerenciar funcionarios." };
  }

  const { error } = await supabase.from("employees").insert({
    company_id: companyId,
    nome,
    telefone: telefone || null,
    percentual_comissao: percentualComissao,
    ativo,
  });

  if (error) {
    return { success: false, message: `Nao foi possivel criar funcionario: ${error.message}` };
  }

  revalidatePath("/painel/funcionarios");
  return { success: true, message: "Funcionario criado com sucesso." };
}

export async function updateEmployeeAction(_prevState: ActionState, formData: FormData): Promise<ActionState> {
  const id = sanitizeText(formData.get("id"));
  const nome = sanitizeText(formData.get("nome"));
  const telefone = sanitizeText(formData.get("telefone"));
  const percentualComissao = sanitizePercentual(formData.get("percentual_comissao"));
  const ativo = formData.get("ativo") === "on";

  if (!id) {
    return { success: false, message: "Funcionario invalido para atualizacao." };
  }

  if (nome.length < 2) {
    return { success: false, message: "Informe o nome do funcionario com pelo menos 2 caracteres." };
  }

  if (!Number.isFinite(percentualComissao) || percentualComissao < 0 || percentualComissao > 100) {
    return { success: false, message: "Informe um percentual de comissao entre 0 e 100." };
  }

  const { supabase, companyId, role, errorMessage } = await getCompanyScope();

  if (!companyId) {
    return { success: false, message: errorMessage ?? "Nao foi possivel identificar sua empresa." };
  }

  if (!isAdmin(role)) {
    return { success: false, message: "Apenas administradores podem gerenciar funcionarios." };
  }

  const { error } = await supabase
    .from("employees")
    .update({
      nome,
      telefone: telefone || null,
      percentual_comissao: percentualComissao,
      ativo,
    })
    .eq("id", id)
    .eq("company_id", companyId);

  if (error) {
    return { success: false, message: `Nao foi possivel atualizar funcionario: ${error.message}` };
  }

  revalidatePath("/painel/funcionarios");
  return { success: true, message: "Funcionario atualizado com sucesso." };
}

export async function deleteEmployeeAction(_prevState: ActionState, formData: FormData): Promise<ActionState> {
  const id = sanitizeText(formData.get("id"));

  if (!id) {
    return { success: false, message: "Funcionario invalido para exclusao." };
  }

  const { supabase, companyId, role, errorMessage } = await getCompanyScope();

  if (!companyId) {
    return { success: false, message: errorMessage ?? "Nao foi possivel identificar sua empresa." };
  }

  if (!isAdmin(role)) {
    return { success: false, message: "Apenas administradores podem gerenciar funcionarios." };
  }

  const { error } = await supabase.from("employees").delete().eq("id", id).eq("company_id", companyId);

  if (error) {
    return { success: false, message: `Nao foi possivel excluir funcionario: ${error.message}` };
  }

  revalidatePath("/painel/funcionarios");
  return { success: true, message: "Funcionario excluido com sucesso." };
}

```

### Arquivo: src/app/painel/funcionarios/page.tsx
```
import { redirect } from "next/navigation";

import { CreateEmployeeForm } from "@/components/painel/funcionarios/create-employee-form";
import { EmployeeItemForm } from "@/components/painel/funcionarios/employee-item-form";
import { canAccessModule, getAccessContext } from "@/lib/auth/access";

type EmployeeRow = {
  id: string;
  nome: string;
  telefone: string | null;
  percentual_comissao: number;
  ativo: boolean;
};

export default async function FuncionariosPage() {
  const { supabase, companyId, role, redirectTo } = await getAccessContext();

  if (!companyId || !role) {
    redirect(redirectTo ?? "/login");
  }

  if (!canAccessModule(role, "funcionarios")) {
    redirect("/painel");
  }

  const { data: employees } = await supabase
    .from("employees")
    .select("id, nome, telefone, percentual_comissao, ativo")
    .eq("company_id", companyId)
    .order("created_at", { ascending: false });

  const employeeRows: EmployeeRow[] = (employees ?? []) as EmployeeRow[];

  return (
    <div className="space-y-5">
        <header className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-semibold text-zinc-100">Funcionarios</h1>
            <p className="text-sm text-zinc-300">Cadastre e mantenha a equipe da sua empresa.</p>
          </div>
        </header>

        <CreateEmployeeForm />

        <div className="space-y-3">
          <h2 className="text-lg font-medium text-zinc-100">Lista de funcionarios</h2>

          {employeeRows.length === 0 ? (
            <p className="rounded-xl border border-zinc-700/60 bg-zinc-950/60 p-4 text-sm text-zinc-300">
              Nenhum funcionario cadastrado ainda.
            </p>
          ) : (
            <div className="space-y-3">
              {employeeRows.map((employee) => (
                <EmployeeItemForm key={employee.id} employee={employee} />
              ))}
            </div>
          )}
        </div>
    </div>
  );
}

```

### Arquivo: src/app/painel/layout.tsx
```
import { redirect } from "next/navigation";

import { signOutAction } from "@/app/painel/actions";
import { MobileSidebarMenu } from "@/components/painel/mobile-sidebar-menu";
import { SidebarNav } from "@/components/painel/sidebar-nav";
import { canAccessModule, getAccessContext } from "@/lib/auth/access";

type PainelLayoutProps = {
  children: React.ReactNode;
};

export default async function PainelLayout({ children }: PainelLayoutProps) {
  const { supabase, companyId, role, redirectTo } = await getAccessContext();

  if (!companyId || !role) {
    redirect(redirectTo ?? "/login");
  }

  const [companyResponse, userResponse] = await Promise.all([
    supabase.from("companies").select("nome").eq("id", companyId).maybeSingle(),
    supabase.auth.getUser(),
  ]);

  const navItems = [
    { href: "/painel", label: "Dashboard", section: "Operacao", icon: "dashboard" as const },
    { href: "/painel/agendamentos", label: "Agendamentos", section: "Operacao", icon: "agendamentos" as const },
    { href: "/painel/relatorios", label: "Relatorios", section: "Operacao", icon: "relatorios" as const },
    ...(canAccessModule(role, "clientes")
      ? [{ href: "/painel/clientes", label: "Clientes", section: "Gestao", icon: "clientes" as const }]
      : []),
    ...(canAccessModule(role, "funcionarios")
      ? [{ href: "/painel/funcionarios", label: "Funcionarios", section: "Gestao", icon: "funcionarios" as const }]
      : []),
    ...(canAccessModule(role, "servicos")
      ? [{ href: "/painel/servicos", label: "Servicos", section: "Gestao", icon: "servicos" as const }]
      : []),
    ...(canAccessModule(role, "financeiro")
      ? [{ href: "/painel/financeiro", label: "Financeiro", section: "Gestao", icon: "financeiro" as const }]
      : []),
    ...(canAccessModule(role, "equipe")
      ? [{ href: "/painel/equipe", label: "Equipe", section: "Administracao", icon: "equipe" as const }]
      : []),
    ...(canAccessModule(role, "auditoria")
      ? [{ href: "/painel/auditoria", label: "Auditoria", section: "Seguranca", icon: "auditoria" as const }]
      : []),
    ...(canAccessModule(role, "notificacoes")
      ? [{ href: "/painel/notificacoes", label: "Notificacoes", section: "Seguranca", icon: "notificacoes" as const }]
      : []),
  ];

  return (
    <main className="relative min-h-screen overflow-hidden bg-zinc-950">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top_left,_rgba(236,72,153,0.24),_transparent_45%),radial-gradient(circle_at_bottom_right,_rgba(56,189,248,0.14),_transparent_35%)]" />

      <div className="relative z-10 mx-auto w-full max-w-7xl px-4 py-6 sm:px-6 lg:py-8">
        <MobileSidebarMenu
          companyName={companyResponse.data?.nome ?? "Minha empresa"}
          userEmail={userResponse.data.user?.email ?? "Usuario sem e-mail"}
          items={navItems}
        />

        <div className="grid gap-4 lg:grid-cols-[280px_1fr] lg:gap-6">
          <aside className="hidden rounded-2xl border border-zinc-700/70 bg-zinc-900/85 p-4 shadow-2xl backdrop-blur lg:block lg:sticky lg:top-6 lg:h-[calc(100vh-3rem)] lg:overflow-y-auto">
            <div className="mb-4 border-b border-zinc-700/70 pb-4">
              <p className="text-[11px] font-semibold tracking-[0.22em] text-fuchsia-300 uppercase">SaaS Agenda de Servicos</p>
              <h2 className="mt-2 text-lg font-semibold text-zinc-100">{companyResponse.data?.nome ?? "Minha empresa"}</h2>
              <p className="mt-1 text-xs text-zinc-400">{role === "admin" ? "Administrador" : "Equipe"}</p>
            </div>

            <SidebarNav items={navItems} orientation="vertical" />

            <div className="mt-6 border-t border-zinc-700/70 pt-4">
              <p className="mb-2 text-xs text-zinc-400">{userResponse.data.user?.email ?? "Usuario sem e-mail"}</p>
              <form action={signOutAction}>
                <button
                  type="submit"
                  className="w-full rounded-xl border border-zinc-600 px-3 py-2 text-sm font-medium text-zinc-200 transition hover:border-rose-400 hover:text-rose-300"
                >
                  Sair da conta
                </button>
              </form>
            </div>
          </aside>

          <section className="min-h-[70vh] rounded-2xl border border-zinc-700/60 bg-zinc-900/70 p-4 shadow-2xl backdrop-blur sm:p-6">
            {children}
          </section>
        </div>
      </div>
    </main>
  );
}

```

### Arquivo: src/app/painel/notificacoes/actions.ts
```
"use server";

import { revalidatePath } from "next/cache";

import { canPerformAction, getAccessContext } from "@/lib/auth/access";

function sanitizeText(value: FormDataEntryValue | null): string {
  if (typeof value !== "string") {
    return "";
  }

  return value.trim();
}

export async function markNotificationReadAction(formData: FormData): Promise<void> {
  const notificationId = sanitizeText(formData.get("notification_id"));

  if (!notificationId) {
    return;
  }

  const { supabase, userId, companyId, role } = await getAccessContext();

  if (!userId || !companyId || !role) {
    return;
  }

  if (!canPerformAction(role, "notificacoes", "update")) {
    return;
  }

  await supabase
    .from("security_notifications")
    .update({ read_at: new Date().toISOString() })
    .eq("id", notificationId)
    .eq("company_id", companyId)
    .eq("recipient_id", userId)
    .is("read_at", null);

  revalidatePath("/painel/notificacoes");
  revalidatePath("/painel");
}

export async function markAllNotificationsReadAction(): Promise<void> {
  const { supabase, userId, companyId, role } = await getAccessContext();

  if (!userId || !companyId || !role) {
    return;
  }

  if (!canPerformAction(role, "notificacoes", "update")) {
    return;
  }

  await supabase
    .from("security_notifications")
    .update({ read_at: new Date().toISOString() })
    .eq("company_id", companyId)
    .eq("recipient_id", userId)
    .is("read_at", null);

  revalidatePath("/painel/notificacoes");
  revalidatePath("/painel");
}

```

### Arquivo: src/app/painel/notificacoes/page.tsx
```
import Link from "next/link";
import { redirect } from "next/navigation";

import { canAccessModule, getAccessContext } from "@/lib/auth/access";

import { markAllNotificationsReadAction, markNotificationReadAction } from "./actions";

type NotificationSeverity = "info" | "warning" | "critical";

type SecurityNotificationRow = {
  id: string;
  actor_id: string | null;
  event_key: string;
  title: string;
  message: string;
  severity: NotificationSeverity;
  metadata: Record<string, unknown>;
  created_at: string;
  read_at: string | null;
};

type ProfileRow = {
  id: string;
  nome: string;
  email: string;
};

function getSeverityBadgeClassName(severity: NotificationSeverity): string {
  if (severity === "critical") {
    return "border-rose-500/50 bg-rose-600/10 text-rose-200";
  }

  if (severity === "warning") {
    return "border-amber-500/50 bg-amber-600/10 text-amber-200";
  }

  return "border-sky-500/50 bg-sky-600/10 text-sky-200";
}

function getSeverityLabel(severity: NotificationSeverity): string {
  if (severity === "critical") {
    return "Critico";
  }

  if (severity === "warning") {
    return "Atencao";
  }

  return "Informativo";
}

function formatDateTime(value: string): string {
  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return value;
  }

  return new Intl.DateTimeFormat("pt-BR", {
    dateStyle: "short",
    timeStyle: "short",
  }).format(date);
}

function sanitizeText(value: string | null | undefined): string {
  return (value ?? "").trim();
}

export default async function NotificacoesPage({
  searchParams,
}: {
  searchParams?: Promise<Record<string, string | string[] | undefined>>;
}) {
  const { supabase, companyId, userId, role, redirectTo } = await getAccessContext();

  if (!companyId || !userId || !role) {
    redirect(redirectTo ?? "/login");
  }

  if (!canAccessModule(role, "notificacoes")) {
    redirect("/painel");
  }

  const resolvedSearchParams = (await searchParams) ?? {};
  const onlyUnread = sanitizeText(String(resolvedSearchParams.unread ?? "")) === "1";

  let notificationsQuery = supabase
    .from("security_notifications")
    .select("id, actor_id, event_key, title, message, severity, metadata, created_at, read_at")
    .eq("company_id", companyId)
    .eq("recipient_id", userId)
    .order("created_at", { ascending: false })
    .limit(150);

  if (onlyUnread) {
    notificationsQuery = notificationsQuery.is("read_at", null);
  }

  const notificationsResponse = await notificationsQuery;
  const hasTableIssue = Boolean(notificationsResponse.error?.message.includes("security_notifications"));
  const notifications = (notificationsResponse.data ?? []) as SecurityNotificationRow[];

  const actorIds = [...new Set(notifications.map((item) => item.actor_id).filter(Boolean))] as string[];

  const profilesResponse =
    actorIds.length > 0
      ? await supabase.from("profiles").select("id, nome, email").eq("company_id", companyId).in("id", actorIds)
      : { data: [] as ProfileRow[], error: null };

  const profiles = (profilesResponse.data ?? []) as ProfileRow[];
  const profileById = new Map(profiles.map((profile) => [profile.id, profile]));
  const unreadCount = notifications.filter((item) => !item.read_at).length;

  return (
    <div className="space-y-5">
        <header className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-semibold text-zinc-100">Notificacoes sensiveis</h1>
            <p className="text-sm text-zinc-300">Automacoes para eventos criticos da equipe e convites.</p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <Link
              href={onlyUnread ? "/painel/notificacoes" : "/painel/notificacoes?unread=1"}
              className="rounded-lg border border-zinc-700 px-3 py-2 text-sm text-zinc-100 transition hover:border-amber-400 hover:text-amber-300"
            >
              {onlyUnread ? "Mostrar todas" : "Somente nao lidas"}
            </Link>

            <form action={markAllNotificationsReadAction}>
              <button
                type="submit"
                className="rounded-lg border border-zinc-700 px-3 py-2 text-sm text-zinc-100 transition hover:border-amber-400 hover:text-amber-300"
              >
                Marcar todas como lidas
              </button>
            </form>
          </div>
        </header>

        <div className="mt-4 rounded-lg border border-zinc-700/70 bg-zinc-950/60 px-4 py-3 text-sm text-zinc-200">
          Total listado: {notifications.length} | Nao lidas: {unreadCount}
        </div>

        {hasTableIssue ? (
          <div className="mt-4 rounded-lg border border-rose-500/35 bg-rose-600/10 px-4 py-3 text-sm text-rose-100">
            Seu banco ainda nao foi atualizado para notificacoes. Execute o script docs/database/004_etapa12_notificacoes.sql no Supabase SQL Editor.
          </div>
        ) : null}

        {!hasTableIssue && notifications.length === 0 ? (
          <p className="mt-4 rounded-lg border border-zinc-700/70 bg-zinc-950/60 px-4 py-3 text-sm text-zinc-300">
            Nenhuma notificacao encontrada para os filtros atuais.
          </p>
        ) : null}

        <div className="mt-4 space-y-3">
          {notifications.map((notification) => {
            const actor = notification.actor_id ? profileById.get(notification.actor_id) : null;
            const metadataText = JSON.stringify(notification.metadata ?? {});

            return (
              <article
                key={notification.id}
                className="rounded-xl border border-zinc-700/70 bg-zinc-950/60 p-4"
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <h2 className="text-sm font-semibold text-zinc-100">{notification.title}</h2>
                    <p className="mt-1 text-sm text-zinc-300">{notification.message}</p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <span
                      className={`rounded-full border px-2.5 py-1 text-[11px] font-semibold uppercase tracking-[0.08em] ${getSeverityBadgeClassName(notification.severity)}`}
                    >
                      {getSeverityLabel(notification.severity)}
                    </span>

                    {notification.read_at ? (
                      <span className="rounded-full border border-emerald-500/40 bg-emerald-600/10 px-2.5 py-1 text-[11px] font-semibold uppercase tracking-[0.08em] text-emerald-200">
                        Lida
                      </span>
                    ) : (
                      <form action={markNotificationReadAction}>
                        <input type="hidden" name="notification_id" value={notification.id} />
                        <button
                          type="submit"
                          className="rounded-full border border-zinc-600 px-2.5 py-1 text-[11px] font-semibold uppercase tracking-[0.08em] text-zinc-200 transition hover:border-amber-400 hover:text-amber-300"
                        >
                          Marcar como lida
                        </button>
                      </form>
                    )}
                  </div>
                </div>

                <div className="mt-3 grid gap-2 text-xs text-zinc-400 sm:grid-cols-2">
                  <p>Evento: {notification.event_key}</p>
                  <p>Criada em: {formatDateTime(notification.created_at)}</p>
                  <p>Ator: {actor ? `${actor.nome} (${actor.email})` : "Sistema"}</p>
                  <p>Lida em: {notification.read_at ? formatDateTime(notification.read_at) : "Nao lida"}</p>
                </div>

                <details className="mt-3 rounded-lg border border-zinc-700/70 bg-zinc-900/60 px-3 py-2">
                  <summary className="cursor-pointer text-xs font-medium text-zinc-300">Metadata</summary>
                  <pre className="mt-2 overflow-x-auto whitespace-pre-wrap text-xs text-zinc-400">{metadataText}</pre>
                </details>
              </article>
            );
          })}
        </div>
    </div>
  );
}

```

### Arquivo: src/app/painel/page.tsx
```
import { redirect } from "next/navigation";

import { getAccessContext } from "@/lib/auth/access";
import type { AppointmentStatus } from "@/types";

type AppointmentRow = {
  id: string;
  cliente_nome: string;
  data_hora: string;
  status: AppointmentStatus;
  service_id?: string;
};

type PaymentRow = {
  valor: number;
};

type ServiceRow = {
  id: string;
  nome: string;
};

function formatDateTime(value: string): string {
  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return value;
  }

  return new Intl.DateTimeFormat("pt-BR", {
    dateStyle: "short",
    timeStyle: "short",
  }).format(date);
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(value);
}

function roundToTwo(value: number): number {
  return Math.round(value * 100) / 100;
}

function getStatusBadge(status: AppointmentStatus): string {
  if (status === "concluido") {
    return "border-emerald-500/40 bg-emerald-600/10 text-emerald-200";
  }

  if (status === "cancelado") {
    return "border-rose-500/40 bg-rose-600/10 text-rose-200";
  }

  return "border-amber-500/40 bg-amber-600/10 text-amber-200";
}

function getStatusLabel(status: AppointmentStatus): string {
  if (status === "concluido") {
    return "Concluido";
  }

  if (status === "cancelado") {
    return "Cancelado";
  }

  return "Agendado";
}

export default async function PainelPage() {
  const { supabase, companyId, role, redirectTo } = await getAccessContext();

  if (!companyId || !role) {
    redirect(redirectTo ?? "/login");
  }

  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: company } = await supabase
    .from("companies")
    .select("nome")
    .eq("id", companyId)
    .maybeSingle();

  const now = new Date();
  const startOfDay = new Date(now);
  startOfDay.setHours(0, 0, 0, 0);
  const endOfDay = new Date(now);
  endOfDay.setHours(23, 59, 59, 999);
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
  const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);

  const [todayAppointmentsResponse, paymentsTodayResponse, servicesResponse, concludedMonthResponse] = await Promise.all([
    supabase
      .from("appointments")
      .select("id, cliente_nome, data_hora, status")
      .eq("company_id", companyId)
      .gte("data_hora", startOfDay.toISOString())
      .lte("data_hora", endOfDay.toISOString())
      .order("data_hora", { ascending: true }),
    supabase
      .from("payments")
      .select("valor")
      .eq("company_id", companyId)
      .gte("created_at", startOfDay.toISOString())
      .lte("created_at", endOfDay.toISOString()),
    supabase.from("services").select("id, nome").eq("company_id", companyId),
    supabase
      .from("appointments")
      .select("service_id")
      .eq("company_id", companyId)
      .eq("status", "concluido")
      .gte("data_hora", startOfMonth.toISOString())
      .lte("data_hora", endOfMonth.toISOString()),
  ]);

  const todayAppointments = (todayAppointmentsResponse.data ?? []) as AppointmentRow[];
  const todayPayments = (paymentsTodayResponse.data ?? []) as PaymentRow[];
  const services = (servicesResponse.data ?? []) as ServiceRow[];
  const concludedAppointmentsThisMonth = (concludedMonthResponse.data ?? []) as AppointmentRow[];

  const totalToday = todayAppointments.length;
  const totalScheduled = todayAppointments.filter((item) => item.status === "agendado").length;
  const totalConcluded = todayAppointments.filter((item) => item.status === "concluido").length;
  const totalCanceled = todayAppointments.filter((item) => item.status === "cancelado").length;
  const revenueToday = roundToTwo(todayPayments.reduce((sum, payment) => sum + Number(payment.valor ?? 0), 0));
  const nextAppointments = todayAppointments.filter(
    (item) => item.status === "agendado" && new Date(item.data_hora).getTime() >= now.getTime(),
  );

  const serviceNameById = new Map(services.map((service) => [service.id, service.nome]));
  const serviceCountById = new Map<string, number>();

  for (const appointment of concludedAppointmentsThisMonth) {
    const serviceId = String(appointment.service_id ?? "");

    if (!serviceId) {
      continue;
    }

    serviceCountById.set(serviceId, (serviceCountById.get(serviceId) ?? 0) + 1);
  }

  const topServices = [...serviceCountById.entries()]
    .map(([serviceId, total]) => ({
      serviceId,
      serviceName: serviceNameById.get(serviceId) ?? "Servico removido",
      total,
    }))
    .sort((left, right) => right.total - left.total)
    .slice(0, 5);

  return (
    <div className="space-y-5">
      <header>
        <h1 className="text-2xl font-semibold text-zinc-100">Dashboard</h1>
        <p className="mt-1 text-sm text-zinc-300">Visao rapida da agenda do dia.</p>
      </header>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
        <article className="rounded-lg border border-zinc-700/70 bg-zinc-950/70 p-4">
          <p className="text-xs text-zinc-400">Agendamentos hoje</p>
          <p className="mt-1 text-2xl font-semibold text-zinc-100">{totalToday}</p>
        </article>

        <article className="rounded-lg border border-sky-500/35 bg-sky-600/10 p-4">
          <p className="text-xs text-sky-200/80">Faturamento hoje</p>
          <p className="mt-1 text-2xl font-semibold text-sky-100">{formatCurrency(revenueToday)}</p>
        </article>

        <article className="rounded-lg border border-amber-500/35 bg-amber-600/10 p-4">
          <p className="text-xs text-amber-200/80">Agendados</p>
          <p className="mt-1 text-2xl font-semibold text-amber-100">{totalScheduled}</p>
        </article>

        <article className="rounded-lg border border-emerald-500/35 bg-emerald-600/10 p-4">
          <p className="text-xs text-emerald-200/80">Concluidos</p>
          <p className="mt-1 text-2xl font-semibold text-emerald-100">{totalConcluded}</p>
        </article>

        <article className="rounded-lg border border-rose-500/35 bg-rose-600/10 p-4">
          <p className="text-xs text-rose-200/80">Cancelados</p>
          <p className="mt-1 text-2xl font-semibold text-rose-100">{totalCanceled}</p>
        </article>
      </div>

      <div className="grid gap-3 lg:grid-cols-[1.2fr_1fr]">
        <article className="rounded-lg border border-zinc-700/70 bg-zinc-950/70 p-4">
          <div className="flex items-center justify-between gap-3">
            <h2 className="text-sm font-semibold text-zinc-100">Proximos atendimentos de hoje</h2>
            <p className="text-xs text-zinc-400">{nextAppointments.length} pendente(s)</p>
          </div>

          {nextAppointments.length === 0 ? (
            <p className="mt-3 rounded-lg border border-zinc-700/70 bg-zinc-900/70 px-3 py-2 text-sm text-zinc-300">
              Nenhum agendamento pendente para hoje.
            </p>
          ) : (
            <div className="mt-3 space-y-2">
              {nextAppointments.slice(0, 6).map((appointment) => (
                <div
                  key={appointment.id}
                  className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-zinc-700/70 bg-zinc-900/70 px-3 py-2"
                >
                  <div>
                    <p className="text-sm text-zinc-100">{appointment.cliente_nome}</p>
                    <p className="text-xs text-zinc-400">{formatDateTime(appointment.data_hora)}</p>
                  </div>
                  <span
                    className={`rounded-full border px-2.5 py-1 text-[11px] font-semibold uppercase tracking-[0.08em] ${getStatusBadge(appointment.status)}`}
                  >
                    {getStatusLabel(appointment.status)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </article>

        <article className="rounded-lg border border-zinc-700/70 bg-zinc-950/70 p-4">
          <h2 className="text-sm font-semibold text-zinc-100">Servicos mais vendidos (mes)</h2>

          {topServices.length === 0 ? (
            <p className="mt-3 rounded-lg border border-zinc-700/70 bg-zinc-900/70 px-3 py-2 text-sm text-zinc-300">
              Sem servicos concluidos no mes atual.
            </p>
          ) : (
            <div className="mt-3 space-y-2">
              {topServices.map((service, index) => (
                <div
                  key={service.serviceId}
                  className="flex items-center justify-between gap-2 rounded-lg border border-zinc-700/70 bg-zinc-900/70 px-3 py-2"
                >
                  <p className="text-sm text-zinc-100">
                    {index + 1}. {service.serviceName}
                  </p>
                  <span className="rounded-full border border-amber-500/40 bg-amber-600/10 px-2.5 py-1 text-[11px] font-semibold text-amber-200">
                    {service.total}
                  </span>
                </div>
              ))}
            </div>
          )}

          <p className="mt-4 text-xs text-zinc-400">Empresa</p>
          <p className="mt-1 text-sm text-zinc-100">{company?.nome ?? "Empresa nao encontrada"}</p>

          <p className="mt-4 text-xs text-zinc-400">Usuario logado</p>
          <p className="mt-1 text-sm text-zinc-100">{user?.email ?? "Usuario sem e-mail"}</p>

          <p className="mt-4 text-xs text-zinc-400">Papel de acesso</p>
          <p className="mt-1 text-sm text-zinc-100">{role === "admin" ? "Administrador" : "Equipe"}</p>
        </article>
      </div>
    </div>
  );
}

```

### Arquivo: src/app/painel/relatorios/page.tsx
```
type SearchParams = {
  start?: string;
  end?: string;
};

function toDateInputValue(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function normalizeDateInput(value: string | undefined, fallback: string): string {
  if (!value) {
    return fallback;
  }

  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    return fallback;
  }

  return value;
}

export default async function RelatoriosPage({
  searchParams,
}: {
  searchParams?: Promise<SearchParams>;
}) {
  const resolvedSearchParams = (await searchParams) ?? {};
  const now = new Date();
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

  const defaultStart = toDateInputValue(startOfMonth);
  const defaultEnd = toDateInputValue(now);

  const start = normalizeDateInput(resolvedSearchParams.start, defaultStart);
  const end = normalizeDateInput(resolvedSearchParams.end, defaultEnd);

  const appointmentsCsvHref = `/api/reports/appointments?start=${start}&end=${end}`;
  const paymentsCsvHref = `/api/reports/payments?start=${start}&end=${end}`;
  const appointmentsPdfHref = `/api/reports/appointments/pdf?start=${start}&end=${end}`;
  const paymentsPdfHref = `/api/reports/payments/pdf?start=${start}&end=${end}`;

  return (
    <div className="space-y-5">
        <header className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-semibold text-zinc-100">Relatorios e exportacao</h1>
            <p className="mt-2 text-sm text-zinc-300">Exporte dados de agendamentos e financeiro em CSV e PDF por periodo.</p>
          </div>
        </header>

        <form className="mt-5 grid gap-3 rounded-xl border border-zinc-700/60 bg-zinc-950/60 p-4 md:grid-cols-2">
          <div className="space-y-1">
            <label htmlFor="relatorio-start" className="text-sm text-zinc-200">
              Data inicial
            </label>
            <input
              id="relatorio-start"
              name="start"
              type="date"
              defaultValue={start}
              className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-sky-400"
              required
            />
          </div>

          <div className="space-y-1">
            <label htmlFor="relatorio-end" className="text-sm text-zinc-200">
              Data final
            </label>
            <input
              id="relatorio-end"
              name="end"
              type="date"
              defaultValue={end}
              className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-sky-400"
              required
            />
          </div>

          <div className="md:col-span-2 flex items-center justify-start gap-3">
            <button
              type="submit"
              className="h-10 rounded-lg border border-zinc-600 bg-zinc-900 px-4 text-sm font-medium text-zinc-100 transition hover:border-sky-400 hover:text-sky-300"
            >
              Atualizar periodo
            </button>
          </div>
        </form>

        <div className="mt-5 grid gap-3 md:grid-cols-2">
          <a
            href={appointmentsCsvHref}
            className="rounded-xl border border-zinc-700/70 bg-zinc-950/70 p-4 transition hover:border-sky-400/60"
          >
            <p className="text-sm font-semibold text-zinc-100">Exportar agendamentos (CSV)</p>
            <p className="mt-1 text-xs text-zinc-400">Inclui cliente, status, horario, funcionario e servico.</p>
          </a>

          <a
            href={appointmentsPdfHref}
            className="rounded-xl border border-zinc-700/70 bg-zinc-950/70 p-4 transition hover:border-sky-400/60"
          >
            <p className="text-sm font-semibold text-zinc-100">Exportar agendamentos (PDF)</p>
            <p className="mt-1 text-xs text-zinc-400">Resumo em PDF com periodo, total e linhas do relatorio.</p>
          </a>

          <a
            href={paymentsCsvHref}
            className="rounded-xl border border-zinc-700/70 bg-zinc-950/70 p-4 transition hover:border-sky-400/60"
          >
            <p className="text-sm font-semibold text-zinc-100">Exportar financeiro (CSV)</p>
            <p className="mt-1 text-xs text-zinc-400">Inclui valor, forma de pagamento, comissao e cliente.</p>
          </a>

          <a
            href={paymentsPdfHref}
            className="rounded-xl border border-zinc-700/70 bg-zinc-950/70 p-4 transition hover:border-sky-400/60"
          >
            <p className="text-sm font-semibold text-zinc-100">Exportar financeiro (PDF)</p>
            <p className="mt-1 text-xs text-zinc-400">Resumo em PDF com dados de pagamentos e comissao.</p>
          </a>
        </div>
    </div>
  );
}

```

### Arquivo: src/app/painel/servicos/actions.ts
```
"use server";

import { revalidatePath } from "next/cache";

import { getAccessContext, isAdmin } from "@/lib/auth/access";

type ActionState = {
  success: boolean;
  message: string;
};

function sanitizeText(value: FormDataEntryValue | null): string {
  if (typeof value !== "string") {
    return "";
  }

  return value.trim();
}

function sanitizeInteger(value: FormDataEntryValue | null): number {
  const parsedValue = Number(sanitizeText(value));

  if (!Number.isFinite(parsedValue)) {
    return Number.NaN;
  }

  return Math.trunc(parsedValue);
}

function sanitizeMoney(value: FormDataEntryValue | null): number {
  const textValue = sanitizeText(value).replace(",", ".");
  const parsedValue = Number(textValue);

  if (!Number.isFinite(parsedValue)) {
    return Number.NaN;
  }

  return parsedValue;
}

async function getCompanyScope() {
  return getAccessContext();
}

export async function createServiceAction(_prevState: ActionState, formData: FormData): Promise<ActionState> {
  const nome = sanitizeText(formData.get("nome"));
  const duracao = sanitizeInteger(formData.get("duracao"));
  const valor = sanitizeMoney(formData.get("valor"));
  const ativo = formData.get("ativo") === "on";

  if (nome.length < 2) {
    return { success: false, message: "Informe o nome do servico com pelo menos 2 caracteres." };
  }

  if (!Number.isFinite(duracao) || duracao <= 0) {
    return { success: false, message: "Informe uma duracao valida em minutos." };
  }

  if (!Number.isFinite(valor) || valor < 0) {
    return { success: false, message: "Informe um valor valido para o servico." };
  }

  const { supabase, companyId, role, errorMessage } = await getCompanyScope();

  if (!companyId) {
    return { success: false, message: errorMessage ?? "Nao foi possivel identificar sua empresa." };
  }

  if (!isAdmin(role)) {
    return { success: false, message: "Apenas administradores podem gerenciar servicos." };
  }

  const { error } = await supabase.from("services").insert({
    company_id: companyId,
    nome,
    duracao,
    valor,
    ativo,
  });

  if (error) {
    return { success: false, message: `Nao foi possivel criar servico: ${error.message}` };
  }

  revalidatePath("/painel/servicos");
  return { success: true, message: "Servico criado com sucesso." };
}

export async function updateServiceAction(_prevState: ActionState, formData: FormData): Promise<ActionState> {
  const id = sanitizeText(formData.get("id"));
  const nome = sanitizeText(formData.get("nome"));
  const duracao = sanitizeInteger(formData.get("duracao"));
  const valor = sanitizeMoney(formData.get("valor"));
  const ativo = formData.get("ativo") === "on";

  if (!id) {
    return { success: false, message: "Servico invalido para atualizacao." };
  }

  if (nome.length < 2) {
    return { success: false, message: "Informe o nome do servico com pelo menos 2 caracteres." };
  }

  if (!Number.isFinite(duracao) || duracao <= 0) {
    return { success: false, message: "Informe uma duracao valida em minutos." };
  }

  if (!Number.isFinite(valor) || valor < 0) {
    return { success: false, message: "Informe um valor valido para o servico." };
  }

  const { supabase, companyId, role, errorMessage } = await getCompanyScope();

  if (!companyId) {
    return { success: false, message: errorMessage ?? "Nao foi possivel identificar sua empresa." };
  }

  if (!isAdmin(role)) {
    return { success: false, message: "Apenas administradores podem gerenciar servicos." };
  }

  const { error } = await supabase
    .from("services")
    .update({
      nome,
      duracao,
      valor,
      ativo,
    })
    .eq("id", id)
    .eq("company_id", companyId);

  if (error) {
    return { success: false, message: `Nao foi possivel atualizar servico: ${error.message}` };
  }

  revalidatePath("/painel/servicos");
  return { success: true, message: "Servico atualizado com sucesso." };
}

export async function deleteServiceAction(_prevState: ActionState, formData: FormData): Promise<ActionState> {
  const id = sanitizeText(formData.get("id"));

  if (!id) {
    return { success: false, message: "Servico invalido para exclusao." };
  }

  const { supabase, companyId, role, errorMessage } = await getCompanyScope();

  if (!companyId) {
    return { success: false, message: errorMessage ?? "Nao foi possivel identificar sua empresa." };
  }

  if (!isAdmin(role)) {
    return { success: false, message: "Apenas administradores podem gerenciar servicos." };
  }

  const { error } = await supabase.from("services").delete().eq("id", id).eq("company_id", companyId);

  if (error) {
    return { success: false, message: `Nao foi possivel excluir servico: ${error.message}` };
  }

  revalidatePath("/painel/servicos");
  return { success: true, message: "Servico excluido com sucesso." };
}

```

### Arquivo: src/app/painel/servicos/page.tsx
```
import { redirect } from "next/navigation";

import { CreateServiceForm } from "@/components/painel/servicos/create-service-form";
import { ServiceItemForm } from "@/components/painel/servicos/service-item-form";
import { canAccessModule, getAccessContext } from "@/lib/auth/access";

type ServiceRow = {
  id: string;
  nome: string;
  duracao: number;
  valor: number;
  ativo: boolean;
};

export default async function ServicosPage() {
  const { supabase, companyId, role, redirectTo } = await getAccessContext();

  if (!companyId || !role) {
    redirect(redirectTo ?? "/login");
  }

  if (!canAccessModule(role, "servicos")) {
    redirect("/painel");
  }

  const { data: services } = await supabase
    .from("services")
    .select("id, nome, duracao, valor, ativo")
    .eq("company_id", companyId)
    .order("created_at", { ascending: false });

  const serviceRows: ServiceRow[] = (services ?? []) as ServiceRow[];

  return (
    <div className="space-y-5">
        <header className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-semibold text-zinc-100">Servicos</h1>
            <p className="text-sm text-zinc-300">Cadastre e mantenha os servicos oferecidos pela sua empresa.</p>
          </div>
        </header>

        <CreateServiceForm />

        <div className="space-y-3">
          <h2 className="text-lg font-medium text-zinc-100">Lista de servicos</h2>

          {serviceRows.length === 0 ? (
            <p className="rounded-xl border border-zinc-700/60 bg-zinc-950/60 p-4 text-sm text-zinc-300">
              Nenhum servico cadastrado ainda.
            </p>
          ) : (
            <div className="space-y-3">
              {serviceRows.map((service) => (
                <ServiceItemForm key={service.id} service={service} />
              ))}
            </div>
          )}
        </div>
    </div>
  );
}

```

### Arquivo: src/components/auth/login-form.tsx
```
"use client";

import { type FormEvent, useMemo, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";

import { Button } from "@/components/ui/button";
import { createSupabaseBrowserClient } from "@/lib/supabase/client";

type AuthMode = "login" | "signup" | "recover";

type LoginFormState = {
  email: string;
  password: string;
};

type LoginFormErrors = {
  email?: string;
  password?: string;
  form?: string;
};

const INITIAL_STATE: LoginFormState = {
  email: "",
  password: "",
};

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const DEFAULT_PUBLIC_APP_URL = "https://saas-barbearias.vercel.app";

function getPublicAppUrl() {
  const configuredUrl = process.env.NEXT_PUBLIC_APP_URL?.trim();

  if (configuredUrl) {
    return configuredUrl.replace(/\/$/, "");
  }

  return DEFAULT_PUBLIC_APP_URL;
}

function validateLoginForm(values: LoginFormState): LoginFormErrors {
  const errors: LoginFormErrors = {};

  if (!values.email.trim()) {
    errors.email = "Informe seu e-mail.";
  } else if (!EMAIL_REGEX.test(values.email)) {
    errors.email = "Informe um e-mail valido.";
  }

  if (!values.password.trim()) {
    errors.password = "Informe sua senha.";
  } else if (values.password.length < 6) {
    errors.password = "A senha deve ter pelo menos 6 caracteres.";
  }

  return errors;
}

export function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const isConfirmed = searchParams.get("confirmed") === "1";
  const authFlowError = searchParams.get("error");
  const [mode, setMode] = useState<AuthMode>("login");
  const [form, setForm] = useState<LoginFormState>(INITIAL_STATE);
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState<LoginFormErrors>({});
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const isDisabled = useMemo(
    () =>
      isSubmitting ||
      !form.email ||
      (mode !== "recover" && !form.password),
    [form.email, form.password, isSubmitting, mode],
  );

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const validationErrors =
      mode === "recover"
        ? validateLoginForm({ email: form.email, password: "123456" })
        : validateLoginForm(form);

    if (mode === "recover") {
      delete validationErrors.password;
    }

    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    setErrors({});
    setSuccessMessage(null);
    setIsSubmitting(true);

    try {
      const supabase = createSupabaseBrowserClient();

      if (mode === "login") {
        const nextPath = searchParams.get("next");
        const safeNextPath = nextPath?.startsWith("/") ? nextPath : null;

        const { error } = await supabase.auth.signInWithPassword({
          email: form.email.trim(),
          password: form.password,
        });

        if (error) {
          setErrors({ form: `Nao foi possivel entrar: ${error.message}` });
          return;
        }

        let destinationPath = safeNextPath ?? "/painel";

        if (!safeNextPath) {
          const { data: isPlatformAdmin } = await supabase.rpc("is_platform_admin");

          if (isPlatformAdmin) {
            destinationPath = "/master/empresas";
          }
        }

        router.replace(destinationPath);
        router.refresh();
        return;
      }

      if (mode === "signup") {
        const emailRedirectTo = `${getPublicAppUrl()}/auth/confirm?next=/login`;
        const { data, error } = await supabase.auth.signUp({
          email: form.email.trim(),
          password: form.password,
          options: {
            emailRedirectTo,
          },
        });

        if (error) {
          setErrors({ form: `Nao foi possivel criar a conta: ${error.message}` });
          return;
        }

        if (data.session) {
          router.replace("/painel");
          router.refresh();
          return;
        }

        setSuccessMessage("Conta criada. Verifique seu e-mail para confirmar o cadastro.");
        return;
      }

      const redirectTo = `${getPublicAppUrl()}/auth/atualizar-senha`;
      const { error } = await supabase.auth.resetPasswordForEmail(form.email.trim(), {
        redirectTo,
      });

      if (error) {
        setErrors({ form: `Nao foi possivel enviar o e-mail de recuperacao: ${error.message}` });
        return;
      }

      setSuccessMessage("Enviamos um link de recuperacao para o seu e-mail.");
    } catch (error) {
      setErrors({
        form:
          error instanceof Error
            ? `Nao foi possivel processar sua solicitacao: ${error.message}`
            : "Nao foi possivel processar sua solicitacao. Tente novamente.",
      });
    } finally {
      setIsSubmitting(false);
    }
  }

  function onFieldChange(field: keyof LoginFormState, value: string) {
    setForm((previous) => ({ ...previous, [field]: value }));
    setErrors((previous) => ({ ...previous, [field]: undefined, form: undefined }));
    setSuccessMessage(null);
  }

  function switchMode(nextMode: AuthMode) {
    setMode(nextMode);
    setShowPassword(false);
    setErrors({});
    setSuccessMessage(null);
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4" noValidate>
      <div className="grid grid-cols-3 gap-2 rounded-lg bg-zinc-800/70 p-1">
        <button
          type="button"
          onClick={() => switchMode("login")}
          className={`h-9 rounded-md text-xs font-medium transition ${
            mode === "login" ? "bg-amber-400 text-zinc-950" : "text-zinc-200 hover:bg-zinc-700"
          }`}
        >
          Entrar
        </button>
        <button
          type="button"
          onClick={() => switchMode("signup")}
          className={`h-9 rounded-md text-xs font-medium transition ${
            mode === "signup" ? "bg-amber-400 text-zinc-950" : "text-zinc-200 hover:bg-zinc-700"
          }`}
        >
          Cadastrar
        </button>
        <button
          type="button"
          onClick={() => switchMode("recover")}
          className={`h-9 rounded-md text-xs font-medium transition ${
            mode === "recover" ? "bg-amber-400 text-zinc-950" : "text-zinc-200 hover:bg-zinc-700"
          }`}
        >
          Recuperar
        </button>
      </div>

      <div className="space-y-2">
        <label htmlFor="email" className="block text-sm font-medium text-zinc-200">
          E-mail
        </label>
        <input
          id="email"
          name="email"
          type="email"
          autoComplete="email"
          value={form.email}
          onChange={(event) => onFieldChange("email", event.target.value)}
          className="h-11 w-full rounded-lg border border-zinc-700/80 bg-zinc-950/80 px-3 text-sm text-zinc-100 outline-none transition focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20"
          placeholder="voce@barbearia.com"
          aria-invalid={Boolean(errors.email)}
          aria-describedby={errors.email ? "email-error" : undefined}
        />
        {errors.email ? (
          <p id="email-error" className="text-sm text-amber-300">
            {errors.email}
          </p>
        ) : null}
      </div>

      {mode !== "recover" ? (
        <div className="space-y-2">
          <label htmlFor="password" className="block text-sm font-medium text-zinc-200">
            Senha
          </label>
          <div className="relative">
            <input
              id="password"
              name="password"
              type={showPassword ? "text" : "password"}
              autoComplete={mode === "login" ? "current-password" : "new-password"}
              value={form.password}
              onChange={(event) => onFieldChange("password", event.target.value)}
              className="h-11 w-full rounded-lg border border-zinc-700/80 bg-zinc-950/80 px-3 pr-24 text-sm text-zinc-100 outline-none transition focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20"
              placeholder="********"
              aria-invalid={Boolean(errors.password)}
              aria-describedby={errors.password ? "password-error" : undefined}
            />
            <button
              type="button"
              onClick={() => setShowPassword((previous) => !previous)}
              className="absolute top-1/2 right-3 -translate-y-1/2 text-xs font-medium text-amber-300 hover:text-amber-200"
              aria-label={showPassword ? "Ocultar senha" : "Mostrar senha"}
            >
              {showPassword ? "Ocultar" : "Mostrar"}
            </button>
          </div>
          {errors.password ? (
            <p id="password-error" className="text-sm text-amber-300">
              {errors.password}
            </p>
          ) : null}
        </div>
      ) : null}

      <Button
        type="submit"
        className="h-11 w-full bg-amber-400 text-zinc-950 hover:bg-amber-300"
        disabled={isDisabled}
      >
        {isSubmitting
          ? "Processando..."
          : mode === "login"
            ? "Entrar"
            : mode === "signup"
              ? "Criar conta"
              : "Enviar link de recuperacao"}
      </Button>

      {errors.form ? <p className="text-sm text-amber-300">{errors.form}</p> : null}
      {successMessage ? <p className="text-sm text-emerald-300">{successMessage}</p> : null}
      {!successMessage && isConfirmed ? (
        <p className="text-sm text-emerald-300">Conta confirmada com sucesso. Agora voce pode entrar.</p>
      ) : null}
      {!errors.form && authFlowError === "confirmacao_falhou" ? (
        <p className="text-sm text-amber-300">Nao foi possivel confirmar sua conta. Solicite um novo e-mail de confirmacao.</p>
      ) : null}

      <p className="text-center text-xs text-zinc-400">
        {mode === "login"
          ? "Use seu e-mail e senha para entrar."
          : mode === "signup"
            ? "Crie sua conta para acessar o sistema."
            : "Informe o e-mail para receber o link de recuperacao."}
      </p>
    </form>
  );
}

```

### Arquivo: src/components/invites/accept-team-invite-form.tsx
```
"use client";

import Link from "next/link";
import { useActionState } from "react";
import { useFormStatus } from "react-dom";

import { acceptTeamInviteAction } from "@/app/convites/[token]/actions";
import { Button } from "@/components/ui/button";

type ActionState = {
  success: boolean;
  message: string;
};

const INITIAL_STATE: ActionState = {
  success: false,
  message: "",
};

function SubmitButton() {
  const { pending } = useFormStatus();

  return (
    <Button type="submit" className="h-11 bg-amber-400 text-zinc-950 hover:bg-amber-300" disabled={pending}>
      {pending ? "Confirmando..." : "Aceitar convite"}
    </Button>
  );
}

export function AcceptTeamInviteForm({ token }: { token: string }) {
  const [state, formAction] = useActionState<ActionState, FormData>(acceptTeamInviteAction, INITIAL_STATE);

  return (
    <>
      {state.message ? (
        <div className="mb-4" aria-live="polite">
          <div
            className={`w-full rounded-lg border px-4 py-3 text-sm font-medium ${
              state.success
                ? "border-emerald-500/50 bg-emerald-600/15 text-emerald-200"
                : "border-amber-500/50 bg-amber-600/15 text-amber-200"
            }`}
          >
            {state.message}
          </div>
        </div>
      ) : null}

      <form action={formAction} className="space-y-3">
        <input type="hidden" name="token" value={token} />
        <SubmitButton />
      </form>

      <div className="mt-4">
        <Link
          href="/painel"
          className="text-sm text-zinc-300 underline decoration-zinc-600 underline-offset-4 hover:text-amber-300"
        >
          Ir para o painel
        </Link>
      </div>
    </>
  );
}

```

### Arquivo: src/components/onboarding/onboarding-form.tsx
```
"use client";

import { useActionState } from "react";
import { useFormStatus } from "react-dom";

import { Button } from "@/components/ui/button";
import {
  completeOnboardingAction,
  type OnboardingActionState,
} from "@/app/onboarding/actions";

const ONBOARDING_INITIAL_STATE: OnboardingActionState = {
  success: false,
  message: "",
};

function SubmitButton() {
  const { pending } = useFormStatus();

  return (
    <Button type="submit" className="h-11 w-full bg-amber-400 text-zinc-950 hover:bg-amber-300" disabled={pending}>
      {pending ? "Finalizando..." : "Finalizar cadastro da empresa"}
    </Button>
  );
}

export function OnboardingForm() {
  const [state, formAction] = useActionState<OnboardingActionState, FormData>(
    completeOnboardingAction,
    ONBOARDING_INITIAL_STATE,
  );

  return (
    <form action={formAction} className="space-y-4" noValidate>
      <div className="space-y-2">
        <label htmlFor="nomeResponsavel" className="block text-sm font-medium text-zinc-200">
          Seu nome
        </label>
        <input
          id="nomeResponsavel"
          name="nomeResponsavel"
          type="text"
          className="h-11 w-full rounded-lg border border-zinc-700/80 bg-zinc-950/80 px-3 text-sm text-zinc-100 outline-none transition focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20"
          placeholder="Ex.: Carlos Silva"
          aria-invalid={Boolean(state.fieldErrors?.nomeResponsavel)}
        />
        {state.fieldErrors?.nomeResponsavel ? (
          <p className="text-sm text-amber-300">{state.fieldErrors.nomeResponsavel}</p>
        ) : null}
      </div>

      <div className="space-y-2">
        <label htmlFor="nomeEmpresa" className="block text-sm font-medium text-zinc-200">
          Nome da empresa
        </label>
        <input
          id="nomeEmpresa"
          name="nomeEmpresa"
          type="text"
          className="h-11 w-full rounded-lg border border-zinc-700/80 bg-zinc-950/80 px-3 text-sm text-zinc-100 outline-none transition focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20"
          placeholder="Ex.: Barbearia Premium"
          aria-invalid={Boolean(state.fieldErrors?.nomeEmpresa)}
        />
        {state.fieldErrors?.nomeEmpresa ? (
          <p className="text-sm text-amber-300">{state.fieldErrors.nomeEmpresa}</p>
        ) : null}
      </div>

      <div className="space-y-2">
        <label htmlFor="telefone" className="block text-sm font-medium text-zinc-200">
          Telefone (opcional)
        </label>
        <input
          id="telefone"
          name="telefone"
          type="tel"
          className="h-11 w-full rounded-lg border border-zinc-700/80 bg-zinc-950/80 px-3 text-sm text-zinc-100 outline-none transition focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20"
          placeholder="(11) 99999-9999"
        />
      </div>

      <div className="space-y-2">
        <label htmlFor="endereco" className="block text-sm font-medium text-zinc-200">
          Endereco (opcional)
        </label>
        <input
          id="endereco"
          name="endereco"
          type="text"
          className="h-11 w-full rounded-lg border border-zinc-700/80 bg-zinc-950/80 px-3 text-sm text-zinc-100 outline-none transition focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20"
          placeholder="Rua, numero e bairro"
        />
      </div>

      <SubmitButton />

      {state.message ? (
        <p className={`text-sm ${state.success ? "text-emerald-300" : "text-amber-300"}`}>{state.message}</p>
      ) : null}
    </form>
  );
}

```

### Arquivo: src/components/painel/agendamentos/appointment-item-form.tsx
```
"use client";

import { type FormEvent, useActionState, useMemo, useState } from "react";
import { useFormStatus } from "react-dom";

import { Button } from "@/components/ui/button";
import { deleteAppointmentAction, updateAppointmentAction } from "@/app/painel/agendamentos/actions";
import { calculateEndDateIso, hasEmployeeConflict, type AppointmentSlot } from "@/lib/appointments/conflict";

type AppointmentStatus = "agendado" | "concluido" | "cancelado";

type AppointmentItem = {
  id: string;
  customer_id: string | null;
  cliente_nome: string;
  cliente_telefone: string | null;
  employee_id: string;
  service_id: string;
  data_hora: string;
  data_hora_fim: string | null;
  status: AppointmentStatus;
  observacoes: string | null;
};

type OptionItem = {
  id: string;
  nome: string;
  duracao?: number;
};

type ActionState = {
  success: boolean;
  message: string;
};

type StatusMeta = {
  label: string;
  badgeClassName: string;
  cardClassName: string;
};

const INITIAL_STATE: ActionState = {
  success: false,
  message: "",
};

function getStatusMeta(status: AppointmentStatus): StatusMeta {
  if (status === "concluido") {
    return {
      label: "Concluido",
      badgeClassName: "border-emerald-500/50 bg-emerald-600/15 text-emerald-200",
      cardClassName: "border-emerald-500/35",
    };
  }

  if (status === "cancelado") {
    return {
      label: "Cancelado",
      badgeClassName: "border-rose-500/50 bg-rose-600/15 text-rose-200",
      cardClassName: "border-rose-500/35",
    };
  }

  return {
    label: "Agendado",
    badgeClassName: "border-amber-500/50 bg-amber-600/15 text-amber-200",
    cardClassName: "border-amber-500/35",
  };
}

function toDateTimeLocal(value: string): string {
  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return "";
  }

  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  const hours = String(date.getHours()).padStart(2, "0");
  const minutes = String(date.getMinutes()).padStart(2, "0");

  return `${year}-${month}-${day}T${hours}:${minutes}`;
}

function UpdateButton() {
  const { pending } = useFormStatus();

  return (
    <Button type="submit" className="h-9 bg-amber-400 text-zinc-950 hover:bg-amber-300" disabled={pending}>
      {pending ? "Salvando..." : "Salvar"}
    </Button>
  );
}

function DeleteButton() {
  const { pending } = useFormStatus();

  return (
    <Button type="submit" variant="outline" className="h-9 border-zinc-600 text-zinc-100" disabled={pending}>
      {pending ? "Excluindo..." : "Excluir"}
    </Button>
  );
}

export function AppointmentItemForm({
  appointment,
  employees,
  services,
  customers,
  appointmentSlots,
  canUpdate,
  canDelete,
}: {
  appointment: AppointmentItem;
  employees: OptionItem[];
  services: OptionItem[];
  customers: OptionItem[];
  appointmentSlots: AppointmentSlot[];
  canUpdate: boolean;
  canDelete: boolean;
}) {
  const [clientError, setClientError] = useState<string | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [updateState, updateAction] = useActionState<ActionState, FormData>(updateAppointmentAction, INITIAL_STATE);
  const [deleteState, deleteAction] = useActionState<ActionState, FormData>(deleteAppointmentAction, INITIAL_STATE);
  const statusMeta = getStatusMeta(appointment.status);
  const shouldShowEditForm = isEditing || (!updateState.success && Boolean(updateState.message));

  const serviceDurationsById = useMemo(() => {
    return new Map(services.map((service) => [service.id, Number(service.duracao ?? 0)]));
  }, [services]);

  function handleUpdateSubmit(event: FormEvent<HTMLFormElement>) {
    if (!canUpdate) {
      event.preventDefault();
      setClientError("Seu perfil nao tem permissao para atualizar agendamentos.");
      return;
    }

    const formData = new FormData(event.currentTarget);

    const employeeId = String(formData.get("employee_id") ?? "").trim();
    const serviceId = String(formData.get("service_id") ?? "").trim();
    const dataHoraInput = String(formData.get("data_hora") ?? "").trim();
    const statusInput = String(formData.get("status") ?? "").trim();

    if (!employeeId || !serviceId || !dataHoraInput || statusInput !== "agendado") {
      setClientError(null);
      return;
    }

    const durationMinutes = serviceDurationsById.get(serviceId) ?? 0;
    const startDate = new Date(dataHoraInput);

    if (Number.isNaN(startDate.getTime()) || durationMinutes <= 0) {
      setClientError(null);
      return;
    }

    const startIso = startDate.toISOString();
    const endIso = calculateEndDateIso(startIso, durationMinutes);

    const hasConflict = hasEmployeeConflict(appointmentSlots, {
      employeeId,
      newStartIso: startIso,
      newEndIso: endIso,
      ignoreAppointmentId: appointment.id,
    });

    if (hasConflict) {
      event.preventDefault();
      setClientError("O horario selecionado esta indisponivel para este funcionario.");
      return;
    }

    setClientError(null);
  }

  return (
    <article className={`rounded-xl border bg-zinc-950/60 p-4 ${statusMeta.cardClassName}`}>
      <div className="mb-3 flex items-center justify-between gap-3">
        <p className="text-xs uppercase tracking-[0.18em] text-zinc-400">Status atual</p>
        <span className={`rounded-full border px-3 py-1 text-xs font-semibold uppercase tracking-[0.08em] ${statusMeta.badgeClassName}`}>
          {statusMeta.label}
        </span>
      </div>

      {clientError ? (
        <div className="sticky top-3 z-20 mb-3 flex justify-center" aria-live="polite">
          <div className="w-full rounded-lg border border-amber-500/50 bg-amber-600/15 px-4 py-3 text-sm font-medium text-amber-200">
            {clientError}
          </div>
        </div>
      ) : null}

      {updateState.message ? (
        <div className="sticky top-3 z-20 mb-3 flex justify-center" aria-live="polite">
          <div
            className={`w-full rounded-lg border px-4 py-3 text-sm font-medium ${
              updateState.success
                ? "border-emerald-500/50 bg-emerald-600/15 text-emerald-200"
                : "border-amber-500/50 bg-amber-600/15 text-amber-200"
            }`}
            style={updateState.success ? { animation: "appointment-item-toast-fade 3.5s ease forwards" } : undefined}
          >
            {updateState.message}
          </div>
        </div>
      ) : null}

      {deleteState.message ? (
        <div className="sticky top-3 z-20 mb-3 flex justify-center" aria-live="polite">
          <div
            className={`w-full rounded-lg border px-4 py-3 text-sm font-medium ${
              deleteState.success
                ? "border-emerald-500/50 bg-emerald-600/15 text-emerald-200"
                : "border-amber-500/50 bg-amber-600/15 text-amber-200"
            }`}
            style={deleteState.success ? { animation: "appointment-item-toast-fade 3.5s ease forwards" } : undefined}
          >
            {deleteState.message}
          </div>
        </div>
      ) : null}

      {shouldShowEditForm ? (
        <form action={updateAction} onSubmit={handleUpdateSubmit} className="grid gap-3 md:grid-cols-2">
          <input type="hidden" name="id" value={appointment.id} />

          <div className="space-y-1 md:col-span-2">
            <label htmlFor={`agendamento-customer-${appointment.id}`} className="text-sm text-zinc-200">
              Cliente cadastrado (opcional)
            </label>
            <select
              id={`agendamento-customer-${appointment.id}`}
              name="customer_id"
              defaultValue={appointment.customer_id ?? ""}
              className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
            >
              <option value="">Nao vincular</option>
              {customers.map((customer) => (
                <option key={customer.id} value={customer.id}>
                  {customer.nome}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1 md:col-span-2">
            <label htmlFor={`agendamento-cliente-${appointment.id}`} className="text-sm text-zinc-200">
              Nome do cliente
            </label>
            <input
              id={`agendamento-cliente-${appointment.id}`}
              name="cliente_nome"
              type="text"
              defaultValue={appointment.cliente_nome}
              className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
              required
            />
          </div>

          <div className="space-y-1">
            <label htmlFor={`agendamento-telefone-${appointment.id}`} className="text-sm text-zinc-200">
              Telefone do cliente (manual)
            </label>
            <input
              id={`agendamento-telefone-${appointment.id}`}
              name="cliente_telefone"
              type="tel"
              defaultValue={appointment.cliente_telefone ?? ""}
              className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
            />
          </div>

          <div className="space-y-1">
            <label htmlFor={`agendamento-data-${appointment.id}`} className="text-sm text-zinc-200">
              Data e horario
            </label>
            <input
              id={`agendamento-data-${appointment.id}`}
              name="data_hora"
              type="datetime-local"
              defaultValue={toDateTimeLocal(appointment.data_hora)}
              className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
              required
            />
          </div>

          <div className="space-y-1">
            <label htmlFor={`agendamento-funcionario-${appointment.id}`} className="text-sm text-zinc-200">
              Funcionario
            </label>
            <select
              id={`agendamento-funcionario-${appointment.id}`}
              name="employee_id"
              defaultValue={appointment.employee_id}
              className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
              required
            >
              <option value="">Selecione</option>
              {employees.map((employee) => (
                <option key={employee.id} value={employee.id}>
                  {employee.nome}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1">
            <label htmlFor={`agendamento-servico-${appointment.id}`} className="text-sm text-zinc-200">
              Servico
            </label>
            <select
              id={`agendamento-servico-${appointment.id}`}
              name="service_id"
              defaultValue={appointment.service_id}
              className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
              required
            >
              <option value="">Selecione</option>
              {services.map((service) => (
                <option key={service.id} value={service.id}>
                  {service.nome}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1">
            <label htmlFor={`agendamento-status-${appointment.id}`} className="text-sm text-zinc-200">
              Status
            </label>
            <select
              id={`agendamento-status-${appointment.id}`}
              name="status"
              defaultValue={appointment.status}
              className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
              required
            >
              <option value="agendado">Agendado</option>
              <option value="concluido">Concluido</option>
              <option value="cancelado">Cancelado</option>
            </select>
          </div>

          <div className="space-y-1 md:col-span-2">
            <label htmlFor={`agendamento-observacoes-${appointment.id}`} className="text-sm text-zinc-200">
              Observacoes
            </label>
            <textarea
              id={`agendamento-observacoes-${appointment.id}`}
              name="observacoes"
              rows={3}
              defaultValue={appointment.observacoes ?? ""}
              className="w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-2 text-sm text-zinc-100 outline-none focus:border-amber-400"
            />
          </div>

          <div className="md:col-span-2 flex items-center justify-start gap-3">
            {canUpdate ? <UpdateButton /> : <p className="text-xs text-zinc-400">Sem permissao para atualizar este agendamento.</p>}
            <Button type="button" variant="outline" className="h-9 border-zinc-600 text-zinc-100" onClick={() => setIsEditing(false)}>
              Cancelar
            </Button>
          </div>
        </form>
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          <div className="space-y-1 md:col-span-2">
            <p className="text-xs text-zinc-400">Cliente</p>
            <p className="text-sm text-zinc-100">{appointment.cliente_nome}</p>
          </div>

          <div className="space-y-1">
            <p className="text-xs text-zinc-400">Telefone</p>
            <p className="text-sm text-zinc-100">{appointment.cliente_telefone?.trim() || "Nao informado"}</p>
          </div>

          <div className="space-y-1">
            <p className="text-xs text-zinc-400">Horario</p>
            <p className="text-sm text-zinc-100">{toDateTimeLocal(appointment.data_hora).replace("T", " ")}</p>
          </div>

          <div className="space-y-1">
            <p className="text-xs text-zinc-400">Funcionario</p>
            <p className="text-sm text-zinc-100">{employees.find((employee) => employee.id === appointment.employee_id)?.nome ?? "Nao informado"}</p>
          </div>

          <div className="space-y-1">
            <p className="text-xs text-zinc-400">Servico</p>
            <p className="text-sm text-zinc-100">{services.find((service) => service.id === appointment.service_id)?.nome ?? "Nao informado"}</p>
          </div>

          <div className="space-y-1 md:col-span-2">
            <p className="text-xs text-zinc-400">Observacoes</p>
            <p className="text-sm text-zinc-100">{appointment.observacoes?.trim() || "Sem observacoes"}</p>
          </div>

          <div className="md:col-span-2 flex items-center justify-start gap-3">
            {canUpdate ? (
              <Button type="button" className="h-9 bg-amber-400 text-zinc-950 hover:bg-amber-300" onClick={() => setIsEditing(true)}>
                Editar
              </Button>
            ) : null}
          </div>
        </div>
      )}

      {canDelete ? (
        <form action={deleteAction} className="mt-3 flex items-center justify-end gap-3">
          <input type="hidden" name="id" value={appointment.id} />
          <DeleteButton />
        </form>
      ) : (
        <p className="mt-3 text-right text-xs text-zinc-500">Seu perfil nao pode excluir agendamentos.</p>
      )}

      <style jsx>{`
        @keyframes appointment-item-toast-fade {
          0% {
            opacity: 1;
            transform: translateY(0);
          }
          80% {
            opacity: 1;
            transform: translateY(0);
          }
          100% {
            opacity: 0;
            transform: translateY(-8px);
          }
        }
      `}</style>
    </article>
  );
}

```

### Arquivo: src/components/painel/agendamentos/create-appointment-form.tsx
```
"use client";

import { type FormEvent, useActionState, useMemo, useState } from "react";
import { useFormStatus } from "react-dom";

import { Button } from "@/components/ui/button";
import { createAppointmentAction } from "@/app/painel/agendamentos/actions";
import { calculateEndDateIso, hasEmployeeConflict, type AppointmentSlot } from "@/lib/appointments/conflict";

type ActionState = {
  success: boolean;
  message: string;
};

type OptionItem = {
  id: string;
  nome: string;
  duracao?: number;
};

const INITIAL_STATE: ActionState = {
  success: false,
  message: "",
};

function SubmitButton() {
  const { pending } = useFormStatus();

  return (
    <Button type="submit" className="h-11 bg-amber-400 text-zinc-950 hover:bg-amber-300" disabled={pending}>
      {pending ? "Salvando..." : "Adicionar agendamento"}
    </Button>
  );
}

export function CreateAppointmentForm({
  employees,
  services,
  customers,
  appointmentSlots,
}: {
  employees: OptionItem[];
  services: OptionItem[];
  customers: OptionItem[];
  appointmentSlots: AppointmentSlot[];
}) {
  const [clientError, setClientError] = useState<string | null>(null);
  const [state, formAction] = useActionState<ActionState, FormData>(createAppointmentAction, INITIAL_STATE);

  const serviceDurationsById = useMemo(() => {
    return new Map(services.map((service) => [service.id, Number(service.duracao ?? 0)]));
  }, [services]);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    const formData = new FormData(event.currentTarget);

    const employeeId = String(formData.get("employee_id") ?? "").trim();
    const serviceId = String(formData.get("service_id") ?? "").trim();
    const dataHoraInput = String(formData.get("data_hora") ?? "").trim();
    const statusInput = String(formData.get("status") ?? "").trim();

    if (!employeeId || !serviceId || !dataHoraInput || statusInput !== "agendado") {
      setClientError(null);
      return;
    }

    const durationMinutes = serviceDurationsById.get(serviceId) ?? 0;
    const startDate = new Date(dataHoraInput);

    if (Number.isNaN(startDate.getTime()) || durationMinutes <= 0) {
      setClientError(null);
      return;
    }

    const startIso = startDate.toISOString();
    const endIso = calculateEndDateIso(startIso, durationMinutes);

    const hasConflict = hasEmployeeConflict(appointmentSlots, {
      employeeId,
      newStartIso: startIso,
      newEndIso: endIso,
    });

    if (hasConflict) {
      event.preventDefault();
      setClientError("Este funcionario ja possui um agendamento nesse horario.");
      return;
    }

    setClientError(null);
  }

  return (
    <>
      {clientError ? (
        <div className="sticky top-3 z-30 flex justify-center" aria-live="polite">
          <div className="w-full max-w-2xl rounded-lg border border-amber-500/50 bg-amber-600/15 px-4 py-3 text-sm font-medium text-amber-200 shadow-lg">
            {clientError}
          </div>
        </div>
      ) : null}

      {state.message ? (
        <div className="sticky top-3 z-30 flex justify-center" aria-live="polite">
          <div
            className={`w-full max-w-2xl rounded-lg border px-4 py-3 text-sm font-medium shadow-lg ${
              state.success
                ? "border-emerald-500/50 bg-emerald-600/15 text-emerald-200"
                : "border-amber-500/50 bg-amber-600/15 text-amber-200"
            }`}
            style={state.success ? { animation: "appointment-toast-fade 3.5s ease forwards" } : undefined}
          >
            {state.message}
          </div>
        </div>
      ) : null}

      <form
        action={formAction}
        onSubmit={handleSubmit}
        className="grid gap-3 rounded-xl border border-zinc-700/60 bg-zinc-950/60 p-4 md:grid-cols-2"
      >
        <div className="space-y-1 md:col-span-2">
          <label htmlFor="novo-agendamento-customer" className="text-sm text-zinc-200">
            Cliente cadastrado (opcional)
          </label>
          <select
            id="novo-agendamento-customer"
            name="customer_id"
            className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
            defaultValue=""
          >
            <option value="">Selecionar depois / nao vincular</option>
            {customers.map((customer) => (
              <option key={customer.id} value={customer.id}>
                {customer.nome}
              </option>
            ))}
          </select>
        </div>

        <div className="space-y-1 md:col-span-2">
          <label htmlFor="novo-agendamento-cliente" className="text-sm text-zinc-200">
            Nome do cliente
          </label>
          <input
            id="novo-agendamento-cliente"
            name="cliente_nome"
            type="text"
            className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
            placeholder="Ex.: Carlos"
            required
          />
        </div>

        <div className="space-y-1">
          <label htmlFor="novo-agendamento-telefone" className="text-sm text-zinc-200">
            Telefone do cliente (manual)
          </label>
          <input
            id="novo-agendamento-telefone"
            name="cliente_telefone"
            type="tel"
            className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
            placeholder="(11) 99999-9999"
          />
        </div>

        <div className="space-y-1">
          <label htmlFor="novo-agendamento-data-hora" className="text-sm text-zinc-200">
            Data e horario
          </label>
          <input
            id="novo-agendamento-data-hora"
            name="data_hora"
            type="datetime-local"
            className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
            required
          />
        </div>

        <div className="space-y-1">
          <label htmlFor="novo-agendamento-funcionario" className="text-sm text-zinc-200">
            Funcionario
          </label>
          <select
            id="novo-agendamento-funcionario"
            name="employee_id"
            className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
            required
          >
            <option value="">Selecione</option>
            {employees.map((employee) => (
              <option key={employee.id} value={employee.id}>
                {employee.nome}
              </option>
            ))}
          </select>
        </div>

        <div className="space-y-1">
          <label htmlFor="novo-agendamento-servico" className="text-sm text-zinc-200">
            Servico
          </label>
          <select
            id="novo-agendamento-servico"
            name="service_id"
            className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
            required
          >
            <option value="">Selecione</option>
            {services.map((service) => (
              <option key={service.id} value={service.id}>
                {service.nome}
              </option>
            ))}
          </select>
        </div>

        <div className="space-y-1">
          <label htmlFor="novo-agendamento-status" className="text-sm text-zinc-200">
            Status
          </label>
          <select
            id="novo-agendamento-status"
            name="status"
            defaultValue="agendado"
            className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
            required
          >
            <option value="agendado">Agendado</option>
            <option value="concluido">Concluido</option>
            <option value="cancelado">Cancelado</option>
          </select>
        </div>

        <div className="space-y-1 md:col-span-2">
          <label htmlFor="novo-agendamento-observacoes" className="text-sm text-zinc-200">
            Observacoes
          </label>
          <textarea
            id="novo-agendamento-observacoes"
            name="observacoes"
            rows={3}
            className="w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-2 text-sm text-zinc-100 outline-none focus:border-amber-400"
            placeholder="Detalhes adicionais do atendimento"
          />
        </div>

        <div className="md:col-span-2 flex items-center justify-start gap-3">
          <SubmitButton />
        </div>
      </form>

      <style jsx>{`
        @keyframes appointment-toast-fade {
          0% {
            opacity: 1;
            transform: translateY(0);
          }
          80% {
            opacity: 1;
            transform: translateY(0);
          }
          100% {
            opacity: 0;
            transform: translateY(-8px);
          }
        }
      `}</style>
    </>
  );
}

```

### Arquivo: src/components/painel/clientes/create-customer-form.tsx
```
"use client";

import { useActionState } from "react";
import { useFormStatus } from "react-dom";

import { createCustomerAction } from "@/app/painel/clientes/actions";
import { Button } from "@/components/ui/button";

type ActionState = {
  success: boolean;
  message: string;
};

const INITIAL_STATE: ActionState = {
  success: false,
  message: "",
};

function SubmitButton() {
  const { pending } = useFormStatus();

  return (
    <Button type="submit" className="h-11 bg-amber-400 text-zinc-950 hover:bg-amber-300" disabled={pending}>
      {pending ? "Salvando..." : "Adicionar cliente"}
    </Button>
  );
}

export function CreateCustomerForm() {
  const [state, formAction] = useActionState<ActionState, FormData>(createCustomerAction, INITIAL_STATE);

  return (
    <>
      {state.message ? (
        <div className="sticky top-3 z-30 flex justify-center" aria-live="polite">
          <div
            className={`w-full max-w-2xl rounded-lg border px-4 py-3 text-sm font-medium shadow-lg ${
              state.success
                ? "border-emerald-500/50 bg-emerald-600/15 text-emerald-200"
                : "border-amber-500/50 bg-amber-600/15 text-amber-200"
            }`}
            style={state.success ? { animation: "customer-toast-fade 3.5s ease forwards" } : undefined}
          >
            {state.message}
          </div>
        </div>
      ) : null}

      <form action={formAction} className="grid gap-3 rounded-xl border border-zinc-700/60 bg-zinc-950/60 p-4 md:grid-cols-2">
        <div className="space-y-1 md:col-span-2">
          <label htmlFor="novo-cliente-nome" className="text-sm text-zinc-200">
            Nome
          </label>
          <input
            id="novo-cliente-nome"
            name="nome"
            type="text"
            className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
            placeholder="Ex.: Joao Silva"
            required
          />
        </div>

        <div className="space-y-1">
          <label htmlFor="novo-cliente-telefone" className="text-sm text-zinc-200">
            Telefone
          </label>
          <input
            id="novo-cliente-telefone"
            name="telefone"
            type="text"
            className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
            placeholder="(11) 99999-9999"
          />
        </div>

        <div className="space-y-1">
          <label htmlFor="novo-cliente-email" className="text-sm text-zinc-200">
            E-mail
          </label>
          <input
            id="novo-cliente-email"
            name="email"
            type="email"
            className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
            placeholder="cliente@email.com"
          />
        </div>

        <div className="space-y-1 md:col-span-2">
          <label htmlFor="novo-cliente-observacoes" className="text-sm text-zinc-200">
            Observacoes
          </label>
          <textarea
            id="novo-cliente-observacoes"
            name="observacoes"
            rows={3}
            className="w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-2 text-sm text-zinc-100 outline-none focus:border-amber-400"
            placeholder="Preferencias, alergias, anotacoes importantes..."
          />
        </div>

        <label className="flex items-center gap-2 text-sm text-zinc-200 md:col-span-2">
          <input name="ativo" type="checkbox" defaultChecked className="h-4 w-4 accent-amber-400" />
          Cliente ativo
        </label>

        <div className="md:col-span-2 flex items-center justify-start gap-3">
          <SubmitButton />
        </div>
      </form>

      <style jsx>{`
        @keyframes customer-toast-fade {
          0% {
            opacity: 1;
            transform: translateY(0);
          }
          80% {
            opacity: 1;
            transform: translateY(0);
          }
          100% {
            opacity: 0;
            transform: translateY(-8px);
          }
        }
      `}</style>
    </>
  );
}

```

### Arquivo: src/components/painel/clientes/customer-item-form.tsx
```
"use client";

import Link from "next/link";
import { useActionState, useState } from "react";
import { useFormStatus } from "react-dom";

import { deleteCustomerAction, updateCustomerAction } from "@/app/painel/clientes/actions";
import { Button } from "@/components/ui/button";

type CustomerItem = {
  id: string;
  nome: string;
  telefone: string | null;
  email: string | null;
  observacoes: string | null;
  ativo: boolean;
};

type ActionState = {
  success: boolean;
  message: string;
};

const INITIAL_STATE: ActionState = {
  success: false,
  message: "",
};

function UpdateButton() {
  const { pending } = useFormStatus();

  return (
    <Button type="submit" className="h-9 bg-amber-400 text-zinc-950 hover:bg-amber-300" disabled={pending}>
      {pending ? "Salvando..." : "Salvar"}
    </Button>
  );
}

function DeleteButton() {
  const { pending } = useFormStatus();

  return (
    <Button type="submit" variant="outline" className="h-9 border-zinc-600 text-zinc-100" disabled={pending}>
      {pending ? "Excluindo..." : "Excluir"}
    </Button>
  );
}

export function CustomerItemForm({ customer }: { customer: CustomerItem }) {
  const [updateState, updateAction] = useActionState<ActionState, FormData>(updateCustomerAction, INITIAL_STATE);
  const [deleteState, deleteAction] = useActionState<ActionState, FormData>(deleteCustomerAction, INITIAL_STATE);
  const [isEditing, setIsEditing] = useState(false);
  const shouldShowEditForm = isEditing || (!updateState.success && Boolean(updateState.message));

  return (
    <article className="rounded-xl border border-zinc-700/60 bg-zinc-950/60 p-4">
      {updateState.message ? (
        <div className="sticky top-3 z-20 mb-3 flex justify-center" aria-live="polite">
          <div
            className={`w-full rounded-lg border px-4 py-3 text-sm font-medium ${
              updateState.success
                ? "border-emerald-500/50 bg-emerald-600/15 text-emerald-200"
                : "border-amber-500/50 bg-amber-600/15 text-amber-200"
            }`}
            style={updateState.success ? { animation: "customer-item-toast-fade 3.5s ease forwards" } : undefined}
          >
            {updateState.message}
          </div>
        </div>
      ) : null}

      {deleteState.message ? (
        <div className="sticky top-3 z-20 mb-3 flex justify-center" aria-live="polite">
          <div
            className={`w-full rounded-lg border px-4 py-3 text-sm font-medium ${
              deleteState.success
                ? "border-emerald-500/50 bg-emerald-600/15 text-emerald-200"
                : "border-amber-500/50 bg-amber-600/15 text-amber-200"
            }`}
            style={deleteState.success ? { animation: "customer-item-toast-fade 3.5s ease forwards" } : undefined}
          >
            {deleteState.message}
          </div>
        </div>
      ) : null}

      {shouldShowEditForm ? (
        <form action={updateAction} onSubmit={() => setIsEditing(false)} className="grid gap-3 md:grid-cols-2">
          <input type="hidden" name="id" value={customer.id} />

          <div className="space-y-1 md:col-span-2">
            <label htmlFor={`cliente-nome-${customer.id}`} className="text-sm text-zinc-200">
              Nome
            </label>
            <input
              id={`cliente-nome-${customer.id}`}
              name="nome"
              type="text"
              defaultValue={customer.nome}
              className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
              required
            />
          </div>

          <div className="space-y-1">
            <label htmlFor={`cliente-telefone-${customer.id}`} className="text-sm text-zinc-200">
              Telefone
            </label>
            <input
              id={`cliente-telefone-${customer.id}`}
              name="telefone"
              type="text"
              defaultValue={customer.telefone ?? ""}
              className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
            />
          </div>

          <div className="space-y-1">
            <label htmlFor={`cliente-email-${customer.id}`} className="text-sm text-zinc-200">
              E-mail
            </label>
            <input
              id={`cliente-email-${customer.id}`}
              name="email"
              type="email"
              defaultValue={customer.email ?? ""}
              className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
            />
          </div>

          <div className="space-y-1 md:col-span-2">
            <label htmlFor={`cliente-observacoes-${customer.id}`} className="text-sm text-zinc-200">
              Observacoes
            </label>
            <textarea
              id={`cliente-observacoes-${customer.id}`}
              name="observacoes"
              rows={3}
              defaultValue={customer.observacoes ?? ""}
              className="w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-2 text-sm text-zinc-100 outline-none focus:border-amber-400"
            />
          </div>

          <label className="flex items-center gap-2 text-sm text-zinc-200 md:col-span-2">
            <input name="ativo" type="checkbox" defaultChecked={customer.ativo} className="h-4 w-4 accent-amber-400" />
            Cliente ativo
          </label>

          <div className="md:col-span-2 flex items-center justify-start gap-3">
            <UpdateButton />
            <Button type="button" variant="outline" className="h-9 border-zinc-600 text-zinc-100" onClick={() => setIsEditing(false)}>
              Cancelar
            </Button>
          </div>
        </form>
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          <div className="space-y-1 md:col-span-2">
            <p className="text-xs text-zinc-400">Nome</p>
            <p className="text-sm text-zinc-100">{customer.nome}</p>
          </div>

          <div className="space-y-1">
            <p className="text-xs text-zinc-400">Telefone</p>
            <p className="text-sm text-zinc-100">{customer.telefone?.trim() || "Nao informado"}</p>
          </div>

          <div className="space-y-1">
            <p className="text-xs text-zinc-400">E-mail</p>
            <p className="text-sm text-zinc-100">{customer.email?.trim() || "Nao informado"}</p>
          </div>

          <div className="space-y-1 md:col-span-2">
            <p className="text-xs text-zinc-400">Observacoes</p>
            <p className="text-sm text-zinc-100">{customer.observacoes?.trim() || "Sem observacoes"}</p>
          </div>

          <div className="space-y-1 md:col-span-2">
            <p className="text-xs text-zinc-400">Status</p>
            <p className="text-sm text-zinc-100">{customer.ativo ? "Ativo" : "Inativo"}</p>
          </div>

          <div className="md:col-span-2 flex items-center justify-start gap-3">
            <Button type="button" className="h-9 bg-amber-400 text-zinc-950 hover:bg-amber-300" onClick={() => setIsEditing(true)}>
              Editar
            </Button>
          </div>
        </div>
      )}

      <form action={deleteAction} className="mt-3 flex items-center justify-end gap-3">
        <Link
          href={`/painel/clientes/${customer.id}`}
          className="inline-flex h-9 items-center rounded-md border border-zinc-600 px-3 text-sm text-zinc-100 transition hover:border-amber-400 hover:text-amber-300"
        >
          Ver historico
        </Link>
        <input type="hidden" name="id" value={customer.id} />
        <DeleteButton />
      </form>

      <style jsx>{`
        @keyframes customer-item-toast-fade {
          0% {
            opacity: 1;
            transform: translateY(0);
          }
          80% {
            opacity: 1;
            transform: translateY(0);
          }
          100% {
            opacity: 0;
            transform: translateY(-8px);
          }
        }
      `}</style>
    </article>
  );
}

```

### Arquivo: src/components/painel/equipe/create-team-invite-form.tsx
```
"use client";

import { useActionState } from "react";
import { useFormStatus } from "react-dom";

import { createTeamInviteAction } from "@/app/painel/equipe/actions";
import { Button } from "@/components/ui/button";

type ActionState = {
  success: boolean;
  message: string;
};

const INITIAL_STATE: ActionState = {
  success: false,
  message: "",
};

function SubmitButton() {
  const { pending } = useFormStatus();

  return (
    <Button type="submit" className="h-10 bg-amber-400 text-zinc-950 hover:bg-amber-300" disabled={pending}>
      {pending ? "Salvando..." : "Criar convite"}
    </Button>
  );
}

export function CreateTeamInviteForm() {
  const [state, formAction] = useActionState<ActionState, FormData>(createTeamInviteAction, INITIAL_STATE);

  return (
    <>
      {state.message ? (
        <div className="mb-3" aria-live="polite">
          <div
            className={`w-full rounded-lg border px-4 py-3 text-sm font-medium ${
              state.success
                ? "border-emerald-500/50 bg-emerald-600/15 text-emerald-200"
                : "border-amber-500/50 bg-amber-600/15 text-amber-200"
            }`}
          >
            {state.message}
          </div>
        </div>
      ) : null}

      <form action={formAction} className="grid gap-3 rounded-xl border border-zinc-700/60 bg-zinc-950/60 p-4 md:grid-cols-3">
        <div className="space-y-1 md:col-span-2">
          <label htmlFor="invite-email" className="text-sm text-zinc-200">
            E-mail do novo membro
          </label>
          <input
            id="invite-email"
            name="email"
            type="email"
            className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
            placeholder="usuario@empresa.com"
            required
          />
        </div>

        <div className="space-y-1">
          <label htmlFor="invite-role" className="text-sm text-zinc-200">
            Papel
          </label>
          <select
            id="invite-role"
            name="role"
            defaultValue="employee"
            className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
            required
          >
            <option value="employee">Equipe</option>
            <option value="admin">Administrador</option>
          </select>
        </div>

        <div className="md:col-span-3">
          <SubmitButton />
        </div>
      </form>
    </>
  );
}

```

### Arquivo: src/components/painel/equipe/team-invite-item.tsx
```
"use client";

import { useActionState } from "react";
import { useFormStatus } from "react-dom";

import { revokeTeamInviteAction } from "@/app/painel/equipe/actions";
import { Button } from "@/components/ui/button";
import { type UserRole } from "@/lib/auth/access";

type InviteStatus = "pending" | "accepted" | "revoked" | "expired";

type TeamInviteItem = {
  id: string;
  email: string;
  role: UserRole;
  status: InviteStatus;
  token: string;
  expiresAt: string;
};

type ActionState = {
  success: boolean;
  message: string;
};

const INITIAL_STATE: ActionState = {
  success: false,
  message: "",
};

function RevokeButton() {
  const { pending } = useFormStatus();

  return (
    <Button type="submit" variant="outline" className="h-9 border-zinc-600 text-zinc-100" disabled={pending}>
      {pending ? "Revogando..." : "Revogar"}
    </Button>
  );
}

function getStatusLabel(status: InviteStatus): string {
  if (status === "accepted") {
    return "Aceito";
  }

  if (status === "revoked") {
    return "Revogado";
  }

  if (status === "expired") {
    return "Expirado";
  }

  return "Pendente";
}

function formatDate(value: string): string {
  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return value;
  }

  return new Intl.DateTimeFormat("pt-BR", {
    dateStyle: "short",
    timeStyle: "short",
  }).format(date);
}

export function TeamInviteItem({ invite }: { invite: TeamInviteItem }) {
  const [state, revokeAction] = useActionState<ActionState, FormData>(revokeTeamInviteAction, INITIAL_STATE);
  const inviteLink = `/convites/${invite.token}`;

  async function handleCopyLink() {
    try {
      await navigator.clipboard.writeText(inviteLink);
    } catch {
      // Sem bloqueio de UX; o link continua visivel para copia manual.
    }
  }

  return (
    <article className="rounded-xl border border-zinc-700/60 bg-zinc-950/60 p-4">
      {state.message ? (
        <div className="mb-3" aria-live="polite">
          <div
            className={`w-full rounded-lg border px-4 py-3 text-sm font-medium ${
              state.success
                ? "border-emerald-500/50 bg-emerald-600/15 text-emerald-200"
                : "border-amber-500/50 bg-amber-600/15 text-amber-200"
            }`}
          >
            {state.message}
          </div>
        </div>
      ) : null}

      <div className="grid gap-3 md:grid-cols-[1fr_auto] md:items-start">
        <div className="space-y-1">
          <p className="text-sm font-semibold text-zinc-100">{invite.email}</p>
          <p className="text-xs text-zinc-400">Papel: {invite.role === "admin" ? "Administrador" : "Equipe"}</p>
          <p className="text-xs text-zinc-400">Status: {getStatusLabel(invite.status)}</p>
          <p className="text-xs text-zinc-400">Expira em: {formatDate(invite.expiresAt)}</p>

          <div className="rounded-lg border border-zinc-700/70 bg-zinc-900/70 px-3 py-2">
            <p className="text-[11px] text-zinc-400">Link do convite</p>
            <p className="mt-1 break-all text-xs text-zinc-200">{inviteLink}</p>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-end gap-2">
          <Button type="button" variant="outline" className="h-9 border-zinc-600 text-zinc-100" onClick={handleCopyLink}>
            Copiar link
          </Button>

          {invite.status === "pending" ? (
            <form action={revokeAction}>
              <input type="hidden" name="invite_id" value={invite.id} />
              <RevokeButton />
            </form>
          ) : null}
        </div>
      </div>
    </article>
  );
}

```

### Arquivo: src/components/painel/equipe/team-member-role-form.tsx
```
"use client";

import { useActionState, useState } from "react";
import { useFormStatus } from "react-dom";

import { updateMemberRoleAction } from "@/app/painel/equipe/actions";
import { type UserRole } from "@/lib/auth/access";
import { Button } from "@/components/ui/button";

type ActionState = {
  success: boolean;
  message: string;
};

type TeamMember = {
  id: string;
  nome: string;
  email: string;
  role: UserRole;
};

const INITIAL_STATE: ActionState = {
  success: false,
  message: "",
};

function SubmitButton() {
  const { pending } = useFormStatus();

  return (
    <Button type="submit" className="h-9 bg-amber-400 text-zinc-950 hover:bg-amber-300" disabled={pending}>
      {pending ? "Salvando..." : "Salvar papel"}
    </Button>
  );
}

export function TeamMemberRoleForm({
  member,
  isCurrentUser,
}: {
  member: TeamMember;
  isCurrentUser: boolean;
}) {
  const [state, formAction] = useActionState<ActionState, FormData>(updateMemberRoleAction, INITIAL_STATE);
  const [isEditing, setIsEditing] = useState(false);
  const shouldShowEditForm = isEditing || (!state.success && Boolean(state.message));

  return (
    <article className="rounded-xl border border-zinc-700/60 bg-zinc-950/60 p-4">
      {state.message ? (
        <div className="mb-3" aria-live="polite">
          <div
            className={`w-full rounded-lg border px-4 py-3 text-sm font-medium ${
              state.success
                ? "border-emerald-500/50 bg-emerald-600/15 text-emerald-200"
                : "border-amber-500/50 bg-amber-600/15 text-amber-200"
            }`}
          >
            {state.message}
          </div>
        </div>
      ) : null}

      <div className="mb-3">
        <p className="text-sm font-semibold text-zinc-100">{member.nome}</p>
        <p className="text-xs text-zinc-400">{member.email}</p>
      </div>

      {shouldShowEditForm ? (
        <form action={formAction} onSubmit={() => setIsEditing(false)} className="grid gap-3 md:grid-cols-[1fr_auto] md:items-end">
          <input type="hidden" name="member_id" value={member.id} />

          <div className="space-y-1">
            <label htmlFor={`membro-role-${member.id}`} className="text-sm text-zinc-200">
              Papel de acesso
            </label>
            <select
              id={`membro-role-${member.id}`}
              name="role"
              defaultValue={member.role}
              disabled={isCurrentUser}
              className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400 disabled:opacity-60"
            >
              <option value="admin">Administrador</option>
              <option value="employee">Equipe</option>
            </select>
            {isCurrentUser ? <p className="text-xs text-zinc-500">Seu proprio papel nao pode ser rebaixado.</p> : null}
          </div>

          <div className="flex items-center gap-2">
            <SubmitButton />
            <Button type="button" variant="outline" className="h-9 border-zinc-600 text-zinc-100" onClick={() => setIsEditing(false)}>
              Cancelar
            </Button>
          </div>
        </form>
      ) : (
        <div className="flex items-center justify-between gap-3">
          <div>
            <p className="text-xs text-zinc-400">Papel atual</p>
            <p className="text-sm text-zinc-100">{member.role === "admin" ? "Administrador" : "Equipe"}</p>
          </div>

          {!isCurrentUser ? (
            <Button type="button" className="h-9 bg-amber-400 text-zinc-950 hover:bg-amber-300" onClick={() => setIsEditing(true)}>
              Editar
            </Button>
          ) : (
            <p className="text-xs text-zinc-500">Este e seu proprio acesso.</p>
          )}
        </div>
      )}
    </article>
  );
}

```

### Arquivo: src/components/painel/financeiro/create-payment-form.tsx
```
"use client";

import { useActionState, useMemo, useState } from "react";
import { useFormStatus } from "react-dom";

import { Button } from "@/components/ui/button";
import { createPaymentAction } from "@/app/painel/financeiro/actions";

type ActionState = {
  success: boolean;
  message: string;
};

type AppointmentOption = {
  id: string;
  clienteNome: string;
  dataHora: string;
  valorSugerido: number;
  percentualComissaoSugerido: number;
};

const INITIAL_STATE: ActionState = {
  success: false,
  message: "",
};

function SubmitButton() {
  const { pending } = useFormStatus();

  return (
    <Button type="submit" className="h-11 bg-amber-400 text-zinc-950 hover:bg-amber-300" disabled={pending}>
      {pending ? "Salvando..." : "Registrar pagamento"}
    </Button>
  );
}

function formatDateTimeLabel(iso: string): string {
  const date = new Date(iso);

  if (Number.isNaN(date.getTime())) {
    return iso;
  }

  return new Intl.DateTimeFormat("pt-BR", {
    dateStyle: "short",
    timeStyle: "short",
  }).format(date);
}

export function CreatePaymentForm({ appointments }: { appointments: AppointmentOption[] }) {
  const [state, formAction] = useActionState<ActionState, FormData>(createPaymentAction, INITIAL_STATE);
  const [selectedAppointmentId, setSelectedAppointmentId] = useState<string>("");

  const appointmentById = useMemo(() => {
    return new Map(appointments.map((item) => [item.id, item]));
  }, [appointments]);

  const selectedAppointment = selectedAppointmentId ? appointmentById.get(selectedAppointmentId) : null;

  return (
    <>
      {state.message ? (
        <div className="sticky top-3 z-30 flex justify-center" aria-live="polite">
          <div
            className={`w-full max-w-2xl rounded-lg border px-4 py-3 text-sm font-medium shadow-lg ${
              state.success
                ? "border-emerald-500/50 bg-emerald-600/15 text-emerald-200"
                : "border-amber-500/50 bg-amber-600/15 text-amber-200"
            }`}
            style={state.success ? { animation: "payment-toast-fade 3.5s ease forwards" } : undefined}
          >
            {state.message}
          </div>
        </div>
      ) : null}

      <form action={formAction} className="grid gap-3 rounded-xl border border-zinc-700/60 bg-zinc-950/60 p-4 md:grid-cols-2">
        <div className="space-y-1 md:col-span-2">
          <label htmlFor="novo-pagamento-agendamento" className="text-sm text-zinc-200">
            Agendamento concluido
          </label>
          <select
            id="novo-pagamento-agendamento"
            name="appointment_id"
            value={selectedAppointmentId}
            onChange={(event) => setSelectedAppointmentId(event.target.value)}
            className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
            required
          >
            <option value="">Selecione</option>
            {appointments.map((appointment) => (
              <option key={appointment.id} value={appointment.id}>
                {appointment.clienteNome} - {formatDateTimeLabel(appointment.dataHora)}
              </option>
            ))}
          </select>
        </div>

        <div className="space-y-1">
          <label htmlFor="novo-pagamento-valor" className="text-sm text-zinc-200">
            Valor (R$)
          </label>
          <input
            id="novo-pagamento-valor"
            name="valor"
            type="number"
            min={0}
            step="0.01"
            defaultValue={selectedAppointment ? selectedAppointment.valorSugerido : undefined}
            key={`valor-${selectedAppointmentId}`}
            className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
            required
          />
        </div>

        <div className="space-y-1">
          <label htmlFor="novo-pagamento-comissao" className="text-sm text-zinc-200">
            Comissao (%)
          </label>
          <input
            id="novo-pagamento-comissao"
            name="percentual_comissao"
            type="number"
            min={0}
            max={100}
            step="0.01"
            defaultValue={selectedAppointment ? selectedAppointment.percentualComissaoSugerido : undefined}
            key={`comissao-${selectedAppointmentId}`}
            className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
            required
          />
        </div>

        <div className="space-y-1 md:col-span-2">
          <label htmlFor="novo-pagamento-forma" className="text-sm text-zinc-200">
            Forma de pagamento
          </label>
          <input
            id="novo-pagamento-forma"
            name="forma_pagamento"
            type="text"
            className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
            placeholder="Ex.: Pix, Cartao, Dinheiro"
            required
          />
        </div>

        <div className="md:col-span-2 flex items-center justify-start gap-3">
          <SubmitButton />
        </div>
      </form>

      <style jsx>{`
        @keyframes payment-toast-fade {
          0% {
            opacity: 1;
            transform: translateY(0);
          }
          80% {
            opacity: 1;
            transform: translateY(0);
          }
          100% {
            opacity: 0;
            transform: translateY(-8px);
          }
        }
      `}</style>
    </>
  );
}

```

### Arquivo: src/components/painel/financeiro/payment-item-form.tsx
```
"use client";

import { useActionState, useState } from "react";
import { useFormStatus } from "react-dom";

import { Button } from "@/components/ui/button";
import { deletePaymentAction, updatePaymentAction } from "@/app/painel/financeiro/actions";

type PaymentItem = {
  id: string;
  appointmentId: string;
  clienteNome: string;
  dataHora: string;
  valor: number;
  formaPagamento: string;
  percentualComissao: number;
  valorComissao: number;
};

type ActionState = {
  success: boolean;
  message: string;
};

const INITIAL_STATE: ActionState = {
  success: false,
  message: "",
};

function UpdateButton() {
  const { pending } = useFormStatus();

  return (
    <Button type="submit" className="h-9 bg-amber-400 text-zinc-950 hover:bg-amber-300" disabled={pending}>
      {pending ? "Salvando..." : "Salvar"}
    </Button>
  );
}

function DeleteButton() {
  const { pending } = useFormStatus();

  return (
    <Button type="submit" variant="outline" className="h-9 border-zinc-600 text-zinc-100" disabled={pending}>
      {pending ? "Excluindo..." : "Excluir"}
    </Button>
  );
}

function formatDateTimeLabel(iso: string): string {
  const date = new Date(iso);

  if (Number.isNaN(date.getTime())) {
    return iso;
  }

  return new Intl.DateTimeFormat("pt-BR", {
    dateStyle: "short",
    timeStyle: "short",
  }).format(date);
}

export function PaymentItemForm({ payment }: { payment: PaymentItem }) {
  const [updateState, updateAction] = useActionState<ActionState, FormData>(updatePaymentAction, INITIAL_STATE);
  const [deleteState, deleteAction] = useActionState<ActionState, FormData>(deletePaymentAction, INITIAL_STATE);
  const [isEditing, setIsEditing] = useState(false);
  const shouldShowEditForm = isEditing || (!updateState.success && Boolean(updateState.message));

  return (
    <article className="rounded-xl border border-zinc-700/60 bg-zinc-950/60 p-4">
      {updateState.message ? (
        <div className="sticky top-3 z-20 mb-3 flex justify-center" aria-live="polite">
          <div
            className={`w-full rounded-lg border px-4 py-3 text-sm font-medium ${
              updateState.success
                ? "border-emerald-500/50 bg-emerald-600/15 text-emerald-200"
                : "border-amber-500/50 bg-amber-600/15 text-amber-200"
            }`}
            style={updateState.success ? { animation: "payment-item-toast-fade 3.5s ease forwards" } : undefined}
          >
            {updateState.message}
          </div>
        </div>
      ) : null}

      {deleteState.message ? (
        <div className="sticky top-3 z-20 mb-3 flex justify-center" aria-live="polite">
          <div
            className={`w-full rounded-lg border px-4 py-3 text-sm font-medium ${
              deleteState.success
                ? "border-emerald-500/50 bg-emerald-600/15 text-emerald-200"
                : "border-amber-500/50 bg-amber-600/15 text-amber-200"
            }`}
            style={deleteState.success ? { animation: "payment-item-toast-fade 3.5s ease forwards" } : undefined}
          >
            {deleteState.message}
          </div>
        </div>
      ) : null}

      <div className="mb-3 rounded-lg border border-zinc-700/70 bg-zinc-900/60 p-3 text-sm text-zinc-200">
        <p>
          <span className="text-zinc-400">Cliente:</span> {payment.clienteNome}
        </p>
        <p>
          <span className="text-zinc-400">Horario:</span> {formatDateTimeLabel(payment.dataHora)}
        </p>
      </div>

      {shouldShowEditForm ? (
        <form action={updateAction} onSubmit={() => setIsEditing(false)} className="grid gap-3 md:grid-cols-2">
          <input type="hidden" name="id" value={payment.id} />

          <div className="space-y-1">
            <label htmlFor={`pagamento-valor-${payment.id}`} className="text-sm text-zinc-200">
              Valor (R$)
            </label>
            <input
              id={`pagamento-valor-${payment.id}`}
              name="valor"
              type="number"
              min={0}
              step="0.01"
              defaultValue={payment.valor}
              className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
              required
            />
          </div>

          <div className="space-y-1">
            <label htmlFor={`pagamento-comissao-${payment.id}`} className="text-sm text-zinc-200">
              Comissao (%)
            </label>
            <input
              id={`pagamento-comissao-${payment.id}`}
              name="percentual_comissao"
              type="number"
              min={0}
              max={100}
              step="0.01"
              defaultValue={payment.percentualComissao}
              className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
              required
            />
          </div>

          <div className="space-y-1 md:col-span-2">
            <label htmlFor={`pagamento-forma-${payment.id}`} className="text-sm text-zinc-200">
              Forma de pagamento
            </label>
            <input
              id={`pagamento-forma-${payment.id}`}
              name="forma_pagamento"
              type="text"
              defaultValue={payment.formaPagamento}
              className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
              required
            />
          </div>

          <div className="space-y-1 md:col-span-2">
            <label className="text-sm text-zinc-200">Comissao calculada atual</label>
            <p className="rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-2 text-sm text-zinc-100">
              R$ {payment.valorComissao.toFixed(2)}
            </p>
          </div>

          <div className="md:col-span-2 flex items-center justify-start gap-3">
            <UpdateButton />
            <Button type="button" variant="outline" className="h-9 border-zinc-600 text-zinc-100" onClick={() => setIsEditing(false)}>
              Cancelar
            </Button>
          </div>
        </form>
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          <div className="space-y-1">
            <p className="text-xs text-zinc-400">Valor</p>
            <p className="text-sm text-zinc-100">R$ {payment.valor.toFixed(2)}</p>
          </div>

          <div className="space-y-1">
            <p className="text-xs text-zinc-400">Comissao (%)</p>
            <p className="text-sm text-zinc-100">{payment.percentualComissao.toFixed(2)}%</p>
          </div>

          <div className="space-y-1 md:col-span-2">
            <p className="text-xs text-zinc-400">Forma de pagamento</p>
            <p className="text-sm text-zinc-100">{payment.formaPagamento}</p>
          </div>

          <div className="space-y-1 md:col-span-2">
            <p className="text-xs text-zinc-400">Comissao calculada atual</p>
            <p className="text-sm text-zinc-100">R$ {payment.valorComissao.toFixed(2)}</p>
          </div>

          <div className="md:col-span-2 flex items-center justify-start gap-3">
            <Button type="button" className="h-9 bg-amber-400 text-zinc-950 hover:bg-amber-300" onClick={() => setIsEditing(true)}>
              Editar
            </Button>
          </div>
        </div>
      )}

      <form action={deleteAction} className="mt-3 flex items-center justify-end gap-3">
        <input type="hidden" name="id" value={payment.id} />
        <DeleteButton />
      </form>

      <style jsx>{`
        @keyframes payment-item-toast-fade {
          0% {
            opacity: 1;
            transform: translateY(0);
          }
          80% {
            opacity: 1;
            transform: translateY(0);
          }
          100% {
            opacity: 0;
            transform: translateY(-8px);
          }
        }
      `}</style>
    </article>
  );
}

```

### Arquivo: src/components/painel/funcionarios/create-employee-form.tsx
```
"use client";

import { useActionState } from "react";
import { useFormStatus } from "react-dom";

import { Button } from "@/components/ui/button";
import { createEmployeeAction } from "@/app/painel/funcionarios/actions";

type ActionState = {
  success: boolean;
  message: string;
};

const INITIAL_STATE: ActionState = {
  success: false,
  message: "",
};

function SubmitButton() {
  const { pending } = useFormStatus();

  return (
    <Button type="submit" className="h-11 bg-amber-400 text-zinc-950 hover:bg-amber-300" disabled={pending}>
      {pending ? "Salvando..." : "Adicionar funcionario"}
    </Button>
  );
}

export function CreateEmployeeForm() {
  const [state, formAction] = useActionState<ActionState, FormData>(createEmployeeAction, INITIAL_STATE);

  return (
    <>
      {state.message ? (
        <div className="sticky top-3 z-30 flex justify-center" aria-live="polite">
          <div
            className={`w-full max-w-2xl rounded-lg border px-4 py-3 text-sm font-medium shadow-lg ${
              state.success
                ? "border-emerald-500/50 bg-emerald-600/15 text-emerald-200"
                : "border-amber-500/50 bg-amber-600/15 text-amber-200"
            }`}
            style={state.success ? { animation: "employee-toast-fade 3.5s ease forwards" } : undefined}
          >
            {state.message}
          </div>
        </div>
      ) : null}

      <form action={formAction} className="grid gap-3 rounded-xl border border-zinc-700/60 bg-zinc-950/60 p-4 md:grid-cols-2">
        <div className="space-y-1 md:col-span-2">
          <label htmlFor="novo-funcionario-nome" className="text-sm text-zinc-200">
            Nome
          </label>
          <input
            id="novo-funcionario-nome"
            name="nome"
            type="text"
            className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
            placeholder="Ex.: Joao"
            required
          />
        </div>

        <div className="space-y-1">
          <label htmlFor="novo-funcionario-telefone" className="text-sm text-zinc-200">
            Telefone
          </label>
          <input
            id="novo-funcionario-telefone"
            name="telefone"
            type="tel"
            className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
            placeholder="(11) 99999-9999"
          />
        </div>

        <div className="space-y-1">
          <label htmlFor="novo-funcionario-percentual" className="text-sm text-zinc-200">
            Comissao (%)
          </label>
          <input
            id="novo-funcionario-percentual"
            name="percentual_comissao"
            type="number"
            min={0}
            max={100}
            step="0.01"
            className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
            placeholder="40"
            required
          />
        </div>

        <label className="flex items-center gap-2 text-sm text-zinc-200 md:col-span-2">
          <input name="ativo" type="checkbox" defaultChecked className="h-4 w-4 accent-amber-400" />
          Funcionario ativo
        </label>

        <div className="md:col-span-2 flex items-center justify-start gap-3">
          <SubmitButton />
        </div>
      </form>

      <style jsx>{`
        @keyframes employee-toast-fade {
          0% {
            opacity: 1;
            transform: translateY(0);
          }
          80% {
            opacity: 1;
            transform: translateY(0);
          }
          100% {
            opacity: 0;
            transform: translateY(-8px);
          }
        }
      `}</style>
    </>
  );
}

```

### Arquivo: src/components/painel/funcionarios/employee-item-form.tsx
```
"use client";

import { useActionState, useState } from "react";
import { useFormStatus } from "react-dom";

import { Button } from "@/components/ui/button";
import { deleteEmployeeAction, updateEmployeeAction } from "@/app/painel/funcionarios/actions";

type EmployeeItem = {
  id: string;
  nome: string;
  telefone: string | null;
  percentual_comissao: number;
  ativo: boolean;
};

type ActionState = {
  success: boolean;
  message: string;
};

const INITIAL_STATE: ActionState = {
  success: false,
  message: "",
};

function UpdateButton() {
  const { pending } = useFormStatus();

  return (
    <Button type="submit" className="h-9 bg-amber-400 text-zinc-950 hover:bg-amber-300" disabled={pending}>
      {pending ? "Salvando..." : "Salvar"}
    </Button>
  );
}

function DeleteButton() {
  const { pending } = useFormStatus();

  return (
    <Button type="submit" variant="outline" className="h-9 border-zinc-600 text-zinc-100" disabled={pending}>
      {pending ? "Excluindo..." : "Excluir"}
    </Button>
  );
}

export function EmployeeItemForm({ employee }: { employee: EmployeeItem }) {
  const [updateState, updateAction] = useActionState<ActionState, FormData>(updateEmployeeAction, INITIAL_STATE);
  const [deleteState, deleteAction] = useActionState<ActionState, FormData>(deleteEmployeeAction, INITIAL_STATE);
  const [isEditing, setIsEditing] = useState(false);
  const shouldShowEditForm = isEditing || (!updateState.success && Boolean(updateState.message));

  return (
    <article className="rounded-xl border border-zinc-700/60 bg-zinc-950/60 p-4">
      {updateState.message ? (
        <div className="sticky top-3 z-20 mb-3 flex justify-center" aria-live="polite">
          <div
            className={`w-full rounded-lg border px-4 py-3 text-sm font-medium ${
              updateState.success
                ? "border-emerald-500/50 bg-emerald-600/15 text-emerald-200"
                : "border-amber-500/50 bg-amber-600/15 text-amber-200"
            }`}
            style={updateState.success ? { animation: "employee-item-toast-fade 3.5s ease forwards" } : undefined}
          >
            {updateState.message}
          </div>
        </div>
      ) : null}

      {deleteState.message ? (
        <div className="sticky top-3 z-20 mb-3 flex justify-center" aria-live="polite">
          <div
            className={`w-full rounded-lg border px-4 py-3 text-sm font-medium ${
              deleteState.success
                ? "border-emerald-500/50 bg-emerald-600/15 text-emerald-200"
                : "border-amber-500/50 bg-amber-600/15 text-amber-200"
            }`}
            style={deleteState.success ? { animation: "employee-item-toast-fade 3.5s ease forwards" } : undefined}
          >
            {deleteState.message}
          </div>
        </div>
      ) : null}

      {shouldShowEditForm ? (
        <form action={updateAction} onSubmit={() => setIsEditing(false)} className="grid gap-3 md:grid-cols-2">
          <input type="hidden" name="id" value={employee.id} />

          <div className="space-y-1 md:col-span-2">
            <label htmlFor={`funcionario-nome-${employee.id}`} className="text-sm text-zinc-200">
              Nome
            </label>
            <input
              id={`funcionario-nome-${employee.id}`}
              name="nome"
              type="text"
              defaultValue={employee.nome}
              className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
              required
            />
          </div>

          <div className="space-y-1">
            <label htmlFor={`funcionario-telefone-${employee.id}`} className="text-sm text-zinc-200">
              Telefone
            </label>
            <input
              id={`funcionario-telefone-${employee.id}`}
              name="telefone"
              type="tel"
              defaultValue={employee.telefone ?? ""}
              className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
            />
          </div>

          <div className="space-y-1">
            <label htmlFor={`funcionario-comissao-${employee.id}`} className="text-sm text-zinc-200">
              Comissao (%)
            </label>
            <input
              id={`funcionario-comissao-${employee.id}`}
              name="percentual_comissao"
              type="number"
              min={0}
              max={100}
              step="0.01"
              defaultValue={employee.percentual_comissao}
              className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
              required
            />
          </div>

          <label className="flex items-center gap-2 text-sm text-zinc-200 md:col-span-2">
            <input name="ativo" type="checkbox" defaultChecked={employee.ativo} className="h-4 w-4 accent-amber-400" />
            Funcionario ativo
          </label>

          <div className="md:col-span-2 flex items-center justify-start gap-3">
            <UpdateButton />
            <Button
              type="button"
              variant="outline"
              className="h-9 border-zinc-600 text-zinc-100"
              onClick={() => setIsEditing(false)}
            >
              Cancelar
            </Button>
          </div>
        </form>
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          <div className="space-y-1 md:col-span-2">
            <p className="text-xs text-zinc-400">Nome</p>
            <p className="text-sm text-zinc-100">{employee.nome}</p>
          </div>

          <div className="space-y-1">
            <p className="text-xs text-zinc-400">Telefone</p>
            <p className="text-sm text-zinc-100">{employee.telefone?.trim() || "Nao informado"}</p>
          </div>

          <div className="space-y-1">
            <p className="text-xs text-zinc-400">Comissao (%)</p>
            <p className="text-sm text-zinc-100">{employee.percentual_comissao}</p>
          </div>

          <div className="space-y-1 md:col-span-2">
            <p className="text-xs text-zinc-400">Status</p>
            <p className="text-sm text-zinc-100">{employee.ativo ? "Ativo" : "Inativo"}</p>
          </div>

          <div className="md:col-span-2 flex items-center justify-start gap-3">
            <Button type="button" className="h-9 bg-amber-400 text-zinc-950 hover:bg-amber-300" onClick={() => setIsEditing(true)}>
              Editar
            </Button>
          </div>
        </div>
      )}

      <form action={deleteAction} className="mt-3 flex items-center justify-end gap-3">
        <input type="hidden" name="id" value={employee.id} />
        <DeleteButton />
      </form>

      <style jsx>{`
        @keyframes employee-item-toast-fade {
          0% {
            opacity: 1;
            transform: translateY(0);
          }
          80% {
            opacity: 1;
            transform: translateY(0);
          }
          100% {
            opacity: 0;
            transform: translateY(-8px);
          }
        }
      `}</style>
    </article>
  );
}

```

### Arquivo: src/components/painel/mobile-sidebar-menu.tsx
```
"use client";

import { ChevronDown } from "lucide-react";
import { usePathname } from "next/navigation";

import { signOutAction } from "@/app/painel/actions";
import { SidebarNav, type SidebarNavItem } from "@/components/painel/sidebar-nav";

type MobileSidebarMenuProps = {
  companyName: string;
  userEmail: string;
  items: SidebarNavItem[];
};

function isActivePath(pathname: string, href: string): boolean {
  if (href === "/painel") {
    return pathname === "/painel";
  }

  return pathname === href || pathname.startsWith(`${href}/`);
}

export function MobileSidebarMenu({ companyName, userEmail, items }: MobileSidebarMenuProps) {
  const pathname = usePathname();
  const activeItem = items.find((item) => isActivePath(pathname, item.href)) ?? items[0];

  return (
    <details className="group mb-4 rounded-2xl border border-zinc-700/70 bg-zinc-900/85 p-3 backdrop-blur lg:hidden">
      <summary className="flex cursor-pointer list-none items-center justify-between gap-3">
        <div>
          <p className="text-[11px] font-semibold tracking-[0.22em] text-fuchsia-300 uppercase">Menu</p>
          <p className="text-sm text-zinc-200">{companyName}</p>
        </div>

        <div className="flex items-center gap-2">
          <span className="rounded-full border border-fuchsia-400/50 bg-fuchsia-500/15 px-2 py-1 text-[10px] font-semibold tracking-[0.08em] text-fuchsia-200 uppercase">
            {activeItem?.label ?? "Painel"}
          </span>
          <ChevronDown className="size-4 text-zinc-400 transition group-open:rotate-180" />
        </div>
      </summary>

      <div className="grid grid-rows-[0fr] opacity-0 transition-[grid-template-rows,opacity] duration-300 ease-out group-open:grid-rows-[1fr] group-open:opacity-100">
        <div className="overflow-hidden">
          <div className="mt-3 space-y-3 border-t border-zinc-700/70 pt-3">
            <SidebarNav items={items} orientation="vertical" closeOnNavigate />

            <div className="space-y-2 rounded-xl border border-zinc-700/70 bg-zinc-950/60 p-3">
              <p className="text-xs text-zinc-400">{userEmail}</p>
              <form action={signOutAction}>
                <button
                  type="submit"
                  className="w-full rounded-lg border border-zinc-600 px-3 py-2 text-sm font-medium text-zinc-200 transition hover:border-rose-400 hover:text-rose-300"
                >
                  Sair da conta
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </details>
  );
}

```

### Arquivo: src/components/painel/servicos/create-service-form.tsx
```
"use client";

import { useActionState } from "react";
import { useFormStatus } from "react-dom";

import { Button } from "@/components/ui/button";
import { createServiceAction } from "@/app/painel/servicos/actions";

type ActionState = {
  success: boolean;
  message: string;
};

const INITIAL_STATE: ActionState = {
  success: false,
  message: "",
};

function SubmitButton() {
  const { pending } = useFormStatus();

  return (
    <Button type="submit" className="h-11 bg-amber-400 text-zinc-950 hover:bg-amber-300" disabled={pending}>
      {pending ? "Salvando..." : "Adicionar servico"}
    </Button>
  );
}

export function CreateServiceForm() {
  const [state, formAction] = useActionState<ActionState, FormData>(createServiceAction, INITIAL_STATE);

  return (
    <>
      {state.message ? (
        <div className="sticky top-3 z-30 flex justify-center" aria-live="polite">
          <div
            className={`w-full max-w-2xl rounded-lg border px-4 py-3 text-sm font-medium shadow-lg ${
              state.success
                ? "border-emerald-500/50 bg-emerald-600/15 text-emerald-200"
                : "border-amber-500/50 bg-amber-600/15 text-amber-200"
            }`}
            style={state.success ? { animation: "service-toast-fade 3.5s ease forwards" } : undefined}
          >
            {state.message}
          </div>
        </div>
      ) : null}

      <form action={formAction} className="grid gap-3 rounded-xl border border-zinc-700/60 bg-zinc-950/60 p-4 md:grid-cols-2">
        <div className="space-y-1 md:col-span-2">
          <label htmlFor="novo-servico-nome" className="text-sm text-zinc-200">
            Nome
          </label>
          <input
            id="novo-servico-nome"
            name="nome"
            type="text"
            className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
            placeholder="Ex.: Corte masculino"
            required
          />
        </div>

        <div className="space-y-1">
          <label htmlFor="novo-servico-duracao" className="text-sm text-zinc-200">
            Duracao (min)
          </label>
          <input
            id="novo-servico-duracao"
            name="duracao"
            type="number"
            min={1}
            step={1}
            className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
            placeholder="45"
            required
          />
        </div>

        <div className="space-y-1">
          <label htmlFor="novo-servico-valor" className="text-sm text-zinc-200">
            Valor (R$)
          </label>
          <input
            id="novo-servico-valor"
            name="valor"
            type="number"
            min={0}
            step="0.01"
            className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
            placeholder="50"
            required
          />
        </div>

        <label className="flex items-center gap-2 text-sm text-zinc-200 md:col-span-2">
          <input name="ativo" type="checkbox" defaultChecked className="h-4 w-4 accent-amber-400" />
          Servico ativo
        </label>

        <div className="md:col-span-2 flex items-center justify-start gap-3">
          <SubmitButton />
        </div>
      </form>

      <style jsx>{`
        @keyframes service-toast-fade {
          0% {
            opacity: 1;
            transform: translateY(0);
          }
          80% {
            opacity: 1;
            transform: translateY(0);
          }
          100% {
            opacity: 0;
            transform: translateY(-8px);
          }
        }
      `}</style>
    </>
  );
}

```

### Arquivo: src/components/painel/servicos/service-item-form.tsx
```
"use client";

import { useActionState, useMemo, useState } from "react";
import { useFormStatus } from "react-dom";

import { Button } from "@/components/ui/button";
import { deleteServiceAction, updateServiceAction } from "@/app/painel/servicos/actions";

type ServiceItem = {
  id: string;
  nome: string;
  duracao: number;
  valor: number;
  ativo: boolean;
};

type ActionState = {
  success: boolean;
  message: string;
};

const INITIAL_STATE: ActionState = {
  success: false,
  message: "",
};

function UpdateButton() {
  const { pending } = useFormStatus();

  return (
    <Button type="submit" className="h-9 bg-amber-400 text-zinc-950 hover:bg-amber-300" disabled={pending}>
      {pending ? "Salvando..." : "Salvar"}
    </Button>
  );
}

function DeleteButton() {
  const { pending } = useFormStatus();

  return (
    <Button type="submit" variant="outline" className="h-9 border-zinc-600 text-zinc-100" disabled={pending}>
      {pending ? "Excluindo..." : "Excluir"}
    </Button>
  );
}

export function ServiceItemForm({ service }: { service: ServiceItem }) {
  const [updateState, updateAction] = useActionState<ActionState, FormData>(updateServiceAction, INITIAL_STATE);
  const [deleteState, deleteAction] = useActionState<ActionState, FormData>(deleteServiceAction, INITIAL_STATE);
  const [isEditing, setIsEditing] = useState(false);
  const shouldShowEditForm = isEditing || (!updateState.success && Boolean(updateState.message));

  const formattedValue = useMemo(
    () =>
      new Intl.NumberFormat("pt-BR", {
        style: "currency",
        currency: "BRL",
      }).format(Number(service.valor ?? 0)),
    [service.valor],
  );

  return (
    <article className="rounded-xl border border-zinc-700/60 bg-zinc-950/60 p-4">
      {updateState.message ? (
        <div className="sticky top-3 z-20 mb-3 flex justify-center" aria-live="polite">
          <div
            className={`w-full rounded-lg border px-4 py-3 text-sm font-medium ${
              updateState.success
                ? "border-emerald-500/50 bg-emerald-600/15 text-emerald-200"
                : "border-amber-500/50 bg-amber-600/15 text-amber-200"
            }`}
            style={updateState.success ? { animation: "service-item-toast-fade 3.5s ease forwards" } : undefined}
          >
            {updateState.message}
          </div>
        </div>
      ) : null}

      {deleteState.message ? (
        <div className="sticky top-3 z-20 mb-3 flex justify-center" aria-live="polite">
          <div
            className={`w-full rounded-lg border px-4 py-3 text-sm font-medium ${
              deleteState.success
                ? "border-emerald-500/50 bg-emerald-600/15 text-emerald-200"
                : "border-amber-500/50 bg-amber-600/15 text-amber-200"
            }`}
            style={deleteState.success ? { animation: "service-item-toast-fade 3.5s ease forwards" } : undefined}
          >
            {deleteState.message}
          </div>
        </div>
      ) : null}

      {shouldShowEditForm ? (
        <form action={updateAction} onSubmit={() => setIsEditing(false)} className="grid gap-3 md:grid-cols-2">
          <input type="hidden" name="id" value={service.id} />

          <div className="space-y-1 md:col-span-2">
            <label htmlFor={`servico-nome-${service.id}`} className="text-sm text-zinc-200">
              Nome
            </label>
            <input
              id={`servico-nome-${service.id}`}
              name="nome"
              type="text"
              defaultValue={service.nome}
              className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
              required
            />
          </div>

          <div className="space-y-1">
            <label htmlFor={`servico-duracao-${service.id}`} className="text-sm text-zinc-200">
              Duracao (min)
            </label>
            <input
              id={`servico-duracao-${service.id}`}
              name="duracao"
              type="number"
              min={1}
              step={1}
              defaultValue={service.duracao}
              className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
              required
            />
          </div>

          <div className="space-y-1">
            <label htmlFor={`servico-valor-${service.id}`} className="text-sm text-zinc-200">
              Valor (R$)
            </label>
            <input
              id={`servico-valor-${service.id}`}
              name="valor"
              type="number"
              min={0}
              step="0.01"
              defaultValue={service.valor}
              className="h-10 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus:border-amber-400"
              required
            />
          </div>

          <label className="flex items-center gap-2 text-sm text-zinc-200 md:col-span-2">
            <input name="ativo" type="checkbox" defaultChecked={service.ativo} className="h-4 w-4 accent-amber-400" />
            Servico ativo
          </label>

          <div className="md:col-span-2 flex items-center justify-start gap-3">
            <UpdateButton />
            <Button
              type="button"
              variant="outline"
              className="h-9 border-zinc-600 text-zinc-100"
              onClick={() => setIsEditing(false)}
            >
              Cancelar
            </Button>
          </div>
        </form>
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          <div className="space-y-1 md:col-span-2">
            <p className="text-xs text-zinc-400">Nome</p>
            <p className="text-sm text-zinc-100">{service.nome}</p>
          </div>

          <div className="space-y-1">
            <p className="text-xs text-zinc-400">Duracao</p>
            <p className="text-sm text-zinc-100">{service.duracao} min</p>
          </div>

          <div className="space-y-1">
            <p className="text-xs text-zinc-400">Valor</p>
            <p className="text-sm text-zinc-100">{formattedValue}</p>
          </div>

          <div className="space-y-1 md:col-span-2">
            <p className="text-xs text-zinc-400">Status</p>
            <p className="text-sm text-zinc-100">{service.ativo ? "Ativo" : "Inativo"}</p>
          </div>

          <div className="md:col-span-2 flex items-center justify-start gap-3">
            <Button type="button" className="h-9 bg-amber-400 text-zinc-950 hover:bg-amber-300" onClick={() => setIsEditing(true)}>
              Editar
            </Button>
          </div>
        </div>
      )}

      <form action={deleteAction} className="mt-3 flex items-center justify-end gap-3">
        <input type="hidden" name="id" value={service.id} />
        <DeleteButton />
      </form>

      <style jsx>{`
        @keyframes service-item-toast-fade {
          0% {
            opacity: 1;
            transform: translateY(0);
          }
          80% {
            opacity: 1;
            transform: translateY(0);
          }
          100% {
            opacity: 0;
            transform: translateY(-8px);
          }
        }
      `}</style>
    </article>
  );
}

```

### Arquivo: src/components/painel/sidebar-nav.tsx
```
"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { type MouseEvent } from "react";
import {
  BellRing,
  CalendarClock,
  FileBarChart2,
  LayoutDashboard,
  Scissors,
  Shield,
  UserRound,
  Users,
  Wallet,
} from "lucide-react";

export type SidebarNavItem = {
  href: string;
  label: string;
  section: string;
  icon:
    | "dashboard"
    | "agendamentos"
    | "relatorios"
    | "clientes"
    | "funcionarios"
    | "servicos"
    | "financeiro"
    | "equipe"
    | "auditoria"
    | "notificacoes";
};

type SidebarNavProps = {
  items: SidebarNavItem[];
  orientation?: "vertical" | "horizontal";
  closeOnNavigate?: boolean;
};

function isActivePath(pathname: string, href: string): boolean {
  if (href === "/painel") {
    return pathname === "/painel";
  }

  return pathname === href || pathname.startsWith(`${href}/`);
}

function getIcon(icon: SidebarNavItem["icon"]) {
  if (icon === "dashboard") {
    return LayoutDashboard;
  }

  if (icon === "agendamentos") {
    return CalendarClock;
  }

  if (icon === "relatorios") {
    return FileBarChart2;
  }

  if (icon === "clientes") {
    return Users;
  }

  if (icon === "funcionarios") {
    return UserRound;
  }

  if (icon === "servicos") {
    return Scissors;
  }

  if (icon === "financeiro") {
    return Wallet;
  }

  if (icon === "equipe") {
    return Users;
  }

  if (icon === "auditoria") {
    return Shield;
  }

  return BellRing;
}

export function SidebarNav({ items, orientation = "vertical", closeOnNavigate = false }: SidebarNavProps) {
  const pathname = usePathname();
  const isVertical = orientation === "vertical";
  const sections = [...new Set(items.map((item) => item.section))];

  function handleNavigate(event: MouseEvent<HTMLAnchorElement>) {
    if (!closeOnNavigate) {
      return;
    }

    const detailsElement = event.currentTarget.closest("details");

    if (detailsElement instanceof HTMLDetailsElement) {
      detailsElement.open = false;
    }
  }

  if (!isVertical) {
    return (
      <nav className="flex gap-2 overflow-x-auto pb-1" aria-label="Navegacao principal do painel">
        {items.map((item) => {
          const active = isActivePath(pathname, item.href);
          const Icon = getIcon(item.icon);

          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={handleNavigate}
              className={`shrink-0 rounded-lg border px-3 py-2 text-xs font-medium transition ${
                active
                  ? "border-fuchsia-400/70 bg-fuchsia-500/20 text-fuchsia-100"
                  : "border-zinc-700/70 bg-zinc-900/50 text-zinc-200 hover:border-zinc-500 hover:bg-zinc-800/70"
              }`}
            >
              <span className="inline-flex items-center gap-1.5">
                <Icon className="size-3.5" />
                {item.label}
              </span>
            </Link>
          );
        })}
      </nav>
    );
  }

  return (
    <nav className="space-y-4" aria-label="Navegacao principal do painel">
      {sections.map((section) => {
        const sectionItems = items.filter((item) => item.section === section);

        return (
          <div key={section} className="space-y-1.5">
            <p className="px-1 text-[10px] font-semibold tracking-[0.2em] text-zinc-500 uppercase">{section}</p>

            {sectionItems.map((item) => {
              const active = isActivePath(pathname, item.href);
              const Icon = getIcon(item.icon);

              return (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={handleNavigate}
                  className={`group block rounded-xl border px-3 py-2.5 text-sm font-medium transition ${
                    active
                      ? "border-fuchsia-400/70 bg-fuchsia-500/20 text-fuchsia-100 shadow-[0_10px_30px_-22px_rgba(217,70,239,0.9)]"
                      : "border-zinc-700/70 bg-zinc-900/50 text-zinc-200 hover:border-zinc-500 hover:bg-zinc-800/70"
                  }`}
                >
                  <span className="inline-flex items-center gap-2.5">
                    <Icon className={`size-4 ${active ? "text-fuchsia-200" : "text-zinc-400 group-hover:text-zinc-200"}`} />
                    {item.label}
                  </span>
                </Link>
              );
            })}
          </div>
        );
      })}
    </nav>
  );
}

```

### Arquivo: src/components/ui/button.tsx
```
import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"
import { Slot } from "radix-ui"

import { cn } from "@/lib/utils"

const buttonVariants = cva(
  "group/button inline-flex shrink-0 items-center justify-center rounded-xl border border-transparent bg-clip-padding text-sm font-semibold whitespace-nowrap transition-all duration-300 outline-none select-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 active:not-aria-[haspopup]:translate-y-px disabled:pointer-events-none disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-3 aria-invalid:ring-destructive/20 dark:aria-invalid:border-destructive/50 dark:aria-invalid:ring-destructive/40 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
  {
    variants: {
      variant: {
        default:
          "bg-gradient-to-r from-fuchsia-500 via-rose-500 to-orange-400 text-white shadow-[0_12px_30px_-18px_rgba(236,72,153,0.9)] hover:scale-[1.02] hover:brightness-110",
        outline:
          "border-fuchsia-400/45 bg-zinc-950/55 text-fuchsia-100 hover:border-fuchsia-300 hover:bg-fuchsia-500/15 hover:text-white aria-expanded:bg-fuchsia-500/15 aria-expanded:text-white",
        secondary:
          "bg-gradient-to-r from-sky-500/90 to-cyan-400/90 text-zinc-950 shadow-[0_12px_30px_-18px_rgba(56,189,248,0.85)] hover:scale-[1.02] hover:brightness-110 aria-expanded:brightness-110",
        ghost:
          "text-zinc-100 hover:bg-white/10 hover:text-white aria-expanded:bg-white/10 aria-expanded:text-white",
        destructive:
          "bg-rose-500/18 text-rose-200 hover:bg-rose-500/28 focus-visible:border-destructive/40 focus-visible:ring-destructive/20 dark:bg-rose-500/26 dark:hover:bg-rose-500/36 dark:focus-visible:ring-destructive/40",
        link: "text-primary underline-offset-4 hover:underline",
      },
      size: {
        default:
          "h-8 gap-1.5 px-2.5 has-data-[icon=inline-end]:pr-2 has-data-[icon=inline-start]:pl-2",
        xs: "h-6 gap-1 rounded-[min(var(--radius-md),10px)] px-2 text-xs in-data-[slot=button-group]:rounded-lg has-data-[icon=inline-end]:pr-1.5 has-data-[icon=inline-start]:pl-1.5 [&_svg:not([class*='size-'])]:size-3",
        sm: "h-7 gap-1 rounded-[min(var(--radius-md),12px)] px-2.5 text-[0.8rem] in-data-[slot=button-group]:rounded-lg has-data-[icon=inline-end]:pr-1.5 has-data-[icon=inline-start]:pl-1.5 [&_svg:not([class*='size-'])]:size-3.5",
        lg: "h-9 gap-1.5 px-2.5 has-data-[icon=inline-end]:pr-2 has-data-[icon=inline-start]:pl-2",
        icon: "size-8",
        "icon-xs":
          "size-6 rounded-[min(var(--radius-md),10px)] in-data-[slot=button-group]:rounded-lg [&_svg:not([class*='size-'])]:size-3",
        "icon-sm":
          "size-7 rounded-[min(var(--radius-md),12px)] in-data-[slot=button-group]:rounded-lg",
        "icon-lg": "size-9",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

function Button({
  className,
  variant = "default",
  size = "default",
  asChild = false,
  ...props
}: React.ComponentProps<"button"> &
  VariantProps<typeof buttonVariants> & {
    asChild?: boolean
  }) {
  const Comp = asChild ? Slot.Root : "button"

  return (
    <Comp
      data-slot="button"
      data-variant={variant}
      data-size={size}
      className={cn(buttonVariants({ variant, size, className }))}
      {...props}
    />
  )
}

export { Button, buttonVariants }

```

### Arquivo: src/lib/appointments/conflict.ts
```
export type AppointmentSlot = {
  id: string;
  employeeId: string;
  startIso: string;
  endIso: string;
  status: "agendado" | "concluido" | "cancelado";
};

export function calculateEndDateIso(startIso: string, durationMinutes: number): string {
  const startDate = new Date(startIso);

  if (Number.isNaN(startDate.getTime())) {
    throw new Error("Horario inicial invalido para calculo de termino.");
  }

  if (!Number.isFinite(durationMinutes) || durationMinutes <= 0) {
    throw new Error("Duracao do servico invalida para calculo de termino.");
  }

  const endDate = new Date(startDate.getTime() + durationMinutes * 60_000);
  return endDate.toISOString();
}

export function hasEmployeeConflict(
  slots: AppointmentSlot[],
  params: {
    employeeId: string;
    newStartIso: string;
    newEndIso: string;
    ignoreAppointmentId?: string;
  },
): boolean {
  const newStart = new Date(params.newStartIso).getTime();
  const newEnd = new Date(params.newEndIso).getTime();

  if (Number.isNaN(newStart) || Number.isNaN(newEnd)) {
    return false;
  }

  if (newEnd <= newStart) {
    return true;
  }

  return slots.some((slot) => {
    if (slot.status !== "agendado") {
      return false;
    }

    if (slot.employeeId !== params.employeeId) {
      return false;
    }

    if (params.ignoreAppointmentId && slot.id === params.ignoreAppointmentId) {
      return false;
    }

    const slotStart = new Date(slot.startIso).getTime();
    const slotEnd = new Date(slot.endIso).getTime();

    if (Number.isNaN(slotStart) || Number.isNaN(slotEnd)) {
      return false;
    }

    return newStart < slotEnd && newEnd > slotStart;
  });
}

```

### Arquivo: src/lib/auth/access.ts
```
import { createSupabaseServerClient } from "@/lib/supabase/server";

export type UserRole = "admin" | "employee";

type ModuleKey =
  | "funcionarios"
  | "servicos"
  | "agendamentos"
  | "financeiro"
  | "relatorios"
  | "equipe"
  | "auditoria"
  | "notificacoes"
  | "clientes";
type ModuleAction = "read" | "create" | "update" | "delete" | "export" | "manage";

type AccessContext = {
  supabase: Awaited<ReturnType<typeof createSupabaseServerClient>>;
  userId: string | null;
  companyId: string | null;
  role: UserRole | null;
  isPlatformAdmin: boolean;
  errorMessage: string | null;
  redirectTo: "/login" | "/onboarding" | "/painel" | "/master/empresas" | null;
};

type PlatformAccessContext = {
  supabase: Awaited<ReturnType<typeof createSupabaseServerClient>>;
  userId: string | null;
  isPlatformAdmin: boolean;
  errorMessage: string | null;
  redirectTo: "/login" | "/painel" | null;
};

export function canAccessModule(role: UserRole, moduleKey: ModuleKey): boolean {
  if (role === "admin") {
    return true;
  }

  return moduleKey === "agendamentos" || moduleKey === "relatorios";
}

export function canPerformAction(role: UserRole, moduleKey: ModuleKey, action: ModuleAction): boolean {
  if (role === "admin") {
    return true;
  }

  if (moduleKey === "agendamentos") {
    return action === "read" || action === "create" || action === "update";
  }

  if (moduleKey === "relatorios") {
    return action === "read" || action === "export";
  }

  return false;
}

export function isAdmin(role: UserRole | null): boolean {
  return role === "admin";
}

export async function getPlatformAccessContext(): Promise<PlatformAccessContext> {
  const supabase = await createSupabaseServerClient();
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser();

  if (userError || !user) {
    return {
      supabase,
      userId: null,
      isPlatformAdmin: false,
      errorMessage: "Sua sessao expirou. Faca login novamente.",
      redirectTo: "/login",
    };
  }

  const { data: isPlatformAdmin, error: platformAdminError } = await supabase.rpc("is_platform_admin");

  if (platformAdminError || !isPlatformAdmin) {
    return {
      supabase,
      userId: user.id,
      isPlatformAdmin: false,
      errorMessage: "Este usuario nao possui acesso master da plataforma.",
      redirectTo: "/painel",
    };
  }

  return {
    supabase,
    userId: user.id,
    isPlatformAdmin: true,
    errorMessage: null,
    redirectTo: null,
  };
}

export async function getAccessContext(): Promise<AccessContext> {
  const supabase = await createSupabaseServerClient();
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser();

  if (userError || !user) {
    return {
      supabase,
      userId: null,
      companyId: null,
      role: null,
      isPlatformAdmin: false,
      errorMessage: "Sua sessao expirou. Faca login novamente.",
      redirectTo: "/login",
    };
  }

  const { data: isPlatformAdmin, error: platformAdminError } = await supabase.rpc("is_platform_admin");
  const hasPlatformAdminAccess = !platformAdminError && Boolean(isPlatformAdmin);

  const { data: companyId, error: companyError } = await supabase.rpc("current_company_id");

  if (companyError || !companyId) {
    return {
      supabase,
      userId: user.id,
      companyId: null,
      role: null,
      isPlatformAdmin: hasPlatformAdminAccess,
      errorMessage: hasPlatformAdminAccess ? null : "Empresa nao encontrada para este usuario. Finalize o onboarding.",
      redirectTo: hasPlatformAdminAccess ? "/master/empresas" : "/onboarding",
    };
  }

  const { data: profile, error: profileError } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", user.id)
    .eq("company_id", companyId)
    .maybeSingle();

  if (profileError || !profile?.role) {
    return {
      supabase,
      userId: user.id,
      companyId,
      role: null,
      isPlatformAdmin: hasPlatformAdminAccess,
      errorMessage: hasPlatformAdminAccess ? null : "Perfil de acesso nao encontrado para este usuario.",
      redirectTo: hasPlatformAdminAccess ? "/master/empresas" : "/painel",
    };
  }

  return {
    supabase,
    userId: user.id,
    companyId,
    role: profile.role as UserRole,
    isPlatformAdmin: hasPlatformAdminAccess,
    errorMessage: null,
    redirectTo: null,
  };
}

```

### Arquivo: src/lib/notifications/sensitive-events.ts
```
import { createSupabaseServerClient } from "@/lib/supabase/server";

export type NotificationSeverity = "info" | "warning" | "critical";

type SupabaseServerClient = Awaited<ReturnType<typeof createSupabaseServerClient>>;

type NotifySensitiveEventParams = {
  supabase: SupabaseServerClient;
  companyId: string;
  actorId: string | null;
  eventKey: string;
  title: string;
  message: string;
  severity?: NotificationSeverity;
  metadata?: Record<string, unknown>;
};

export async function notifySensitiveEvent(params: NotifySensitiveEventParams): Promise<void> {
  const { data: admins, error: adminsError } = await params.supabase
    .from("profiles")
    .select("id")
    .eq("company_id", params.companyId)
    .eq("role", "admin");

  if (adminsError || !admins || admins.length === 0) {
    return;
  }

  const now = new Date().toISOString();

  const notifications = admins.map((admin) => ({
    company_id: params.companyId,
    recipient_id: admin.id,
    actor_id: params.actorId,
    event_key: params.eventKey,
    title: params.title,
    message: params.message,
    severity: params.severity ?? "warning",
    metadata: params.metadata ?? {},
    created_at: now,
  }));

  const { error } = await params.supabase.from("security_notifications").insert(notifications);

  if (error && !error.message.includes("security_notifications")) {
    // Evita quebrar fluxo principal quando a notificacao falha por motivo secundario.
  }
}

```

### Arquivo: src/lib/reports/pdf.ts
```
import { PDFDocument, StandardFonts } from "pdf-lib";

type PdfTablePayload = {
  title: string;
  periodLabel: string;
  columns: string[];
  rows: Array<Array<string | number | null | undefined>>;
};

function normalizeCell(value: string | number | null | undefined): string {
  if (value === null || value === undefined) {
    return "";
  }

  return String(value).replace(/\s+/g, " ").trim();
}

function formatRow(columns: string[], row: Array<string | number | null | undefined>): string {
  return columns
    .map((column, index) => {
      const value = normalizeCell(row[index]);
      const clipped = value.length > 40 ? `${value.slice(0, 37)}...` : value;
      return `${column}: ${clipped}`;
    })
    .join(" | ");
}

export async function generateReportPdf(payload: PdfTablePayload): Promise<Uint8Array> {
  const pdf = await PDFDocument.create();
  const font = await pdf.embedFont(StandardFonts.Courier);

  const pageWidth = 842;
  const pageHeight = 595;
  const marginX = 28;
  const marginTop = 24;
  const marginBottom = 24;
  const titleSize = 14;
  const metaSize = 10;
  const bodySize = 8;
  const bodyLineHeight = 12;

  let page = pdf.addPage([pageWidth, pageHeight]);
  let y = pageHeight - marginTop;

  const startNewPage = () => {
    page = pdf.addPage([pageWidth, pageHeight]);
    y = pageHeight - marginTop;
  };

  page.drawText(payload.title, { x: marginX, y, size: titleSize, font });
  y -= 18;
  page.drawText(`Periodo: ${payload.periodLabel}`, { x: marginX, y, size: metaSize, font });
  y -= 14;
  page.drawText(`Total de registros: ${payload.rows.length}`, { x: marginX, y, size: metaSize, font });
  y -= 18;

  if (payload.rows.length === 0) {
    page.drawText("Nenhum registro encontrado para o periodo informado.", {
      x: marginX,
      y,
      size: bodySize,
      font,
    });
    return pdf.save();
  }

  for (const row of payload.rows) {
    const line = formatRow(payload.columns, row);

    const chunks: string[] = [];
    const chunkSize = 150;
    for (let index = 0; index < line.length; index += chunkSize) {
      chunks.push(line.slice(index, index + chunkSize));
    }

    for (const chunk of chunks) {
      if (y < marginBottom + bodyLineHeight) {
        startNewPage();
      }

      page.drawText(chunk, {
        x: marginX,
        y,
        size: bodySize,
        font,
      });
      y -= bodyLineHeight;
    }

    y -= 2;
  }

  return pdf.save();
}

```

### Arquivo: src/lib/supabase/admin.ts
```
import { createClient } from "@supabase/supabase-js";

import { getSupabaseServiceRoleEnv } from "@/lib/supabase/env";

export function createSupabaseAdminClient() {
  const { supabaseUrl, supabaseServiceRoleKey } = getSupabaseServiceRoleEnv();

  return createClient(supabaseUrl, supabaseServiceRoleKey, {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  });
}

```

### Arquivo: src/lib/supabase/client.ts
```
"use client";

import { createBrowserClient } from "@supabase/ssr";

import { getSupabaseEnv } from "@/lib/supabase/env";

export function createSupabaseBrowserClient() {
  const { supabaseAnonKey, supabaseUrl } = getSupabaseEnv();

  return createBrowserClient(supabaseUrl, supabaseAnonKey);
}

```

### Arquivo: src/lib/supabase/env.ts
```
type SupabaseEnv = {
  supabaseUrl: string;
  supabaseAnonKey: string;
};

type SupabaseServiceRoleEnv = {
  supabaseUrl: string;
  supabaseServiceRoleKey: string;
};

export function getSupabaseEnv(): SupabaseEnv {
  const rawSupabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL?.trim();
  const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY?.trim();

  if (!rawSupabaseUrl) {
    throw new Error("Variavel de ambiente obrigatoria ausente: NEXT_PUBLIC_SUPABASE_URL");
  }

  if (!supabaseAnonKey) {
    throw new Error("Variavel de ambiente obrigatoria ausente: NEXT_PUBLIC_SUPABASE_ANON_KEY");
  }

  const normalizedSupabaseUrl = rawSupabaseUrl.replace(/\/$/, "");

  if (normalizedSupabaseUrl.endsWith("/rest/v1") || normalizedSupabaseUrl.endsWith("/auth/v1")) {
    throw new Error(
      "NEXT_PUBLIC_SUPABASE_URL invalida. Use apenas o dominio base do projeto (ex.: https://seu-projeto.supabase.co).",
    );
  }

  return {
    supabaseUrl: normalizedSupabaseUrl,
    supabaseAnonKey,
  };
}

export function getSupabaseServiceRoleEnv(): SupabaseServiceRoleEnv {
  const { supabaseUrl } = getSupabaseEnv();
  const supabaseServiceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY?.trim();

  if (!supabaseServiceRoleKey) {
    throw new Error("Variavel de ambiente obrigatoria ausente para area master: SUPABASE_SERVICE_ROLE_KEY");
  }

  return {
    supabaseUrl,
    supabaseServiceRoleKey,
  };
}

```

### Arquivo: src/lib/supabase/middleware.ts
```
import { createServerClient } from "@supabase/ssr";
import { type NextRequest, NextResponse } from "next/server";

import { getSupabaseEnv } from "@/lib/supabase/env";

export async function updateSession(request: NextRequest) {
  let response = NextResponse.next({
    request,
  });

  let supabaseUrl: string;
  let supabaseAnonKey: string;

  try {
    const env = getSupabaseEnv();
    supabaseUrl = env.supabaseUrl;
    supabaseAnonKey = env.supabaseAnonKey;
  } catch {
    // Em ambiente local sem .env configurado, nao bloqueia a aplicacao inteira.
    return response;
  }

  const supabase = createServerClient(supabaseUrl, supabaseAnonKey, {
    cookies: {
      getAll() {
        return request.cookies.getAll();
      },
      setAll(cookiesToSet) {
        cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value));

        response = NextResponse.next({
          request,
        });

        cookiesToSet.forEach(({ name, value, options }) => {
          response.cookies.set(name, value, options);
        });
      },
    },
  });

  // Valida sessao atual para aplicar regras de acesso.
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const isAuthPage = request.nextUrl.pathname === "/login" || request.nextUrl.pathname.startsWith("/auth/");
  const isProtectedPath =
    request.nextUrl.pathname.startsWith("/painel") ||
    request.nextUrl.pathname.startsWith("/master") ||
    request.nextUrl.pathname.startsWith("/onboarding") ||
    request.nextUrl.pathname.startsWith("/convites");

  if (!user && isProtectedPath) {
    const redirectUrl = request.nextUrl.clone();
    redirectUrl.pathname = "/login";
    redirectUrl.searchParams.set("next", request.nextUrl.pathname);
    return NextResponse.redirect(redirectUrl);
  }

  if (user && isAuthPage) {
    const redirectUrl = request.nextUrl.clone();
    const { data: isPlatformAdmin, error: platformAdminError } = await supabase.rpc("is_platform_admin");

    redirectUrl.pathname = !platformAdminError && isPlatformAdmin ? "/master/empresas" : "/painel";
    return NextResponse.redirect(redirectUrl);
  }

  return response;
}

```

### Arquivo: src/lib/supabase/server.ts
```
import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

import { getSupabaseEnv } from "@/lib/supabase/env";

export async function createSupabaseServerClient() {
  const cookieStore = await cookies();
  const { supabaseAnonKey, supabaseUrl } = getSupabaseEnv();

  return createServerClient(supabaseUrl, supabaseAnonKey, {
    cookies: {
      getAll() {
        return cookieStore.getAll();
      },
      setAll(cookiesToSet) {
        try {
          cookiesToSet.forEach(({ name, value, options }) => {
            cookieStore.set(name, value, options);
          });
        } catch {
          // Em Server Components, o Next.js nao permite alterar cookies.
          // O refresh de sessao segue pelo middleware e Server Actions.
        }
      },
    },
  });
}

```

### Arquivo: src/lib/utils.ts
```
import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

```

### Arquivo: src/types/appointments.ts
```
export type AppointmentStatus = "agendado" | "concluido" | "cancelado";

```

### Arquivo: src/types/customers.ts
```
export type CustomerRow = {
  id: string;
  nome: string;
  telefone: string | null;
  email: string | null;
  observacoes: string | null;
  ativo: boolean;
};

```

### Arquivo: src/types/index.ts
```
export * from "./appointments";
export * from "./customers";

```

### Arquivo: tsconfig.json
```
{
  "compilerOptions": {
    "target": "ES2017",
    "lib": ["dom", "dom.iterable", "esnext"],
    "allowJs": true,
    "skipLibCheck": true,
    "strict": true,
    "noEmit": true,
    "esModuleInterop": true,
    "module": "esnext",
    "moduleResolution": "bundler",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "jsx": "react-jsx",
    "incremental": true,
    "plugins": [
      {
        "name": "next"
      }
    ],
    "paths": {
      "@/*": ["./src/*"]
    }
  },
  "include": [
    "next-env.d.ts",
    "**/*.ts",
    "**/*.tsx",
    ".next/types/**/*.ts",
    ".next/dev/types/**/*.ts",
    "**/*.mts"
  ],
  "exclude": ["node_modules"]
}

```

