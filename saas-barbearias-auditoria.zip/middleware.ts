import { type NextRequest } from "next/server";

import { updateSession } from "@/lib/supabase/middleware";

export async function middleware(request: NextRequest) {
  return updateSession(request);
}

export const config = {
  matcher: ["/login", "/auth/:path*", "/painel/:path*", "/master/:path*", "/onboarding", "/convites/:path*"],
};
